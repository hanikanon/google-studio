import fs from 'fs';
const html = fs.readFileSync('test.html', 'utf8');
const regex = /<h1[^>]*>(.*?)<\/h1>/g;
let match;
while ((match = regex.exec(html)) !== null) {
  console.log('H1:', match[1]);
}
const h2regex = /<h2[^>]*>(.*?)<\/h2>/g;
while ((match = h2regex.exec(html)) !== null) {
  console.log('H2:', match[1]);
}
const h3regex = /<h3[^>]*>(.*?)<\/h3>/g;
while ((match = h3regex.exec(html)) !== null) {
  console.log('H3:', match[1]);
}
