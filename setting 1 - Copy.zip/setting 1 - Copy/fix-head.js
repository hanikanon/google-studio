import fs from 'fs';
const file = 'src/routes/__root.tsx';
let content = fs.readFileSync(file, 'utf8');

if (!content.includes('HeadContent')) {
  content = content.replace('import { ScrollRestoration, Scripts, Outlet }', 'import { ScrollRestoration, Scripts, Outlet, HeadContent }');
  content = content.replace('<title>Cryptvora Settings</title>', '<title>Cryptvora Settings</title>\n          <HeadContent />');
  fs.writeFileSync(file, content);
  console.log("Added HeadContent");
} else {
  console.log("HeadContent already present");
}
