import fs from 'fs';
const file = 'src/components/settings/SettingsContext.tsx';
let content = fs.readFileSync(file, 'utf8');

const newUseLocalStorage = `function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(initialValue);

  useEffect(() => {
    try {
      const item = window.localStorage.getItem(key);
      if (item) {
        setStoredValue(JSON.parse(item));
      }
    } catch (error) {
      console.warn(error);
    }
  }, [key]);`;

const oldUseLocalStorage = `function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === "undefined") {
      return initialValue;
    }
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.warn(error);
      return initialValue;
    }
  });`;

content = content.replace(newUseLocalStorage, oldUseLocalStorage);
fs.writeFileSync(file, content);
console.log("Reverted SettingsContext.tsx");
