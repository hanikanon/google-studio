import fs from 'fs';
const html = fs.readFileSync('test.html', 'utf8');

const getSection = (name) => {
  const startIdx = html.indexOf('>' + name + '<');
  if (startIdx === -1) return "Not found";
  const endIdx = html.indexOf('</section>', startIdx);
  return html.slice(startIdx - 100, endIdx).substring(0, 300) + '...';
};

console.log(getSection('Accent color'));
console.log(getSection('Theme'));
