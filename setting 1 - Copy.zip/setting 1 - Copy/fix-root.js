import fs from 'fs';
let content = fs.readFileSync('src/routes/__root.tsx', 'utf8');
content = content.replace('import { useSettings, themeStyle } from "../components/settings/SettingsContext";', 'import { useSettings } from "../components/settings/SettingsContext";\nimport { themeStyle } from "../config/themes";');
fs.writeFileSync('src/routes/__root.tsx', content);
