import fs from 'fs';
const html = fs.readFileSync('dev-output.html', 'utf8');
console.log('Includes <html:', html.includes('<html'));
console.log('Includes <body:', html.includes('<body'));
console.log('Includes id="root":', html.includes('id="root"'));
console.log('Total length:', html.length);
