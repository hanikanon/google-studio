import fs from 'fs';
let content = fs.readFileSync('src/components/settings/SettingsContext.tsx', 'utf8');

const toRemove = [
  /export type ThemeId[\s\S]*?export type AppIcon[^;]*;/g,
  /export const BADGES[\s\S]*?\];/g,
  /export const THEMES: Record<ThemeId, any>[\s\S]*?\};\n/g,
  /export const ACCENTS: Record<AccentId, any>[\s\S]*?\};\n/g,
  /export function themeStyle[\s\S]*?\n\}\n/g
];

toRemove.forEach(regex => {
  content = content.replace(regex, '');
});

const imports = `import { ThemeId, AccentId, BubbleStyle, FontSize, Motion, AppIcon } from "../../config/themes";\n`;
content = content.replace(/(import .*;\n)+/, (match) => match + '\n' + imports);

fs.writeFileSync('src/components/settings/SettingsContext.tsx', content);
