console.log("Just thinking");
