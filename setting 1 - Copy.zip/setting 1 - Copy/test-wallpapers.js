import fs from 'fs';
console.log(fs.readdirSync('src/assets/wallpapers'));
