import puppeteer from 'puppeteer';

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
  const page = await browser.newPage();
  
  const errors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') {
      errors.push(msg.text());
    }
  });
  
  await page.goto('http://localhost:3000/settings/chat-wallpapers', { waitUntil: 'networkidle2' });
  
  const rootContent = await page.evaluate(() => {
    return document.getElementById('root')?.innerHTML || 'NO_ROOT';
  });
  
  if (rootContent.length < 500) {
    console.log('Dev HTML:', rootContent);
  } else {
    console.log('Dev app rendered successfully! HTML length:', rootContent.length);
  }
  
  const hasVisible = await page.evaluate(() => document.body.innerText.trim().length > 0);
  console.log('Has visible text:', hasVisible);
  console.log('Errors:', errors);
  
  await browser.close();
})();
