const fs = require('fs');
let content = fs.readFileSync('src/components/MessageInput.tsx', 'utf8');

const targetStr = `            )}
          </AnimatePresence>
        </div>

        <div className="relative flex flex-col items-center justify-end shrink-0">`;

const replacement = `            )}
          </AnimatePresence>
        </div>
      </div>

        <div className="relative flex flex-col items-center justify-end shrink-0 bg-white dark:bg-[#1c1c1d] rounded-full shadow-sm border border-black/5 dark:border-white/10 w-[44px] h-[44px]">`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessageInput.tsx', content.replace(targetStr, replacement));
  console.log("Fixed button structure.");
} else {
  console.log("Could not find button structure!");
}
