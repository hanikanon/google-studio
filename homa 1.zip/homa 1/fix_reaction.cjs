const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

content = content.replace(
  'const [flyingEmojis, setFlyingEmojis] = useState<{id: number, emoji: string, x: number, y: number}[]>([]);',
  'const [flyingEmojis, setFlyingEmojis] = useState<{id: number, emoji: string, x: number, y: number, scale: number, offsetX: number}[]>([]);'
);

const oldReaction = `  const handleReaction = (msgId: string, emoji: string, event?: React.MouseEvent) => {
    if (event && event.target && (event.target as HTMLElement).getBoundingClientRect) {
       const rect = (event.target as HTMLElement).getBoundingClientRect();
       const id = Date.now();
       setFlyingEmojis(prev => [...prev, { id, emoji, x: rect.left + rect.width/2, y: rect.top + rect.height/2 }]);
       setTimeout(() => setFlyingEmojis(prev => prev.filter(e => e.id !== id)), 1500);
    }`;

const newReaction = `  const handleReaction = (msgId: string, emoji: string, event?: React.MouseEvent) => {
    if (event && event.target && (event.target as HTMLElement).getBoundingClientRect) {
       const rect = (event.target as HTMLElement).getBoundingClientRect();
       const basePathX = rect.left + rect.width / 2;
       const basePathY = rect.top + rect.height / 2;
       
       const newParticles = [];
       // Main pop emoji
       newParticles.push({ id: Date.now(), emoji, x: basePathX, y: basePathY, scale: 2, offsetX: 0 });
       
       // Celebration cluster for stars
       if (emoji === '⭐') {
         for(let i=0; i<6; i++) {
           newParticles.push({ 
             id: Date.now() + i + 1, 
             emoji: '⭐', 
             x: basePathX, 
             y: basePathY, 
             scale: 0.5 + Math.random() * 0.8,
             offsetX: (Math.random() - 0.5) * 100
           });
         }
       }
       
       setFlyingEmojis(prev => [...prev, ...newParticles]);
       setTimeout(() => {
         const idsToRemove = newParticles.map(p => p.id);
         setFlyingEmojis(prev => prev.filter(e => !idsToRemove.includes(e.id)));
       }, 2000);
    }`;

content = content.replace(oldReaction, newReaction);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Fixed handleReaction");
