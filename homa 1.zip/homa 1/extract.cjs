const fs = require('fs');

const c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

const badIdx = c.indexOf(")}port { motion");
if (badIdx !== -1) {
    // The top part is from 0 to badIdx + 2
    let topPart = c.substring(0, badIdx + 2);
    // Let's see if top part has duplicate states.
    fs.writeFileSync('topPart.tsx', topPart);
    
    let bottomPart = "im" + c.substring(badIdx + 2);
    fs.writeFileSync('bottomPart.tsx', bottomPart);
}
