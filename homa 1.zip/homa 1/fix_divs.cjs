const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

content = content.replace(`              </>
            )}
          </div>
        </div>
      </div>

      {/* Messages Area */}`, `              </>
            )}
        </div>
      </div>

      {/* Messages Area */}`);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Fixed divs");
