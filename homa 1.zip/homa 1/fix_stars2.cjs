const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

content = content.replace(
  'for(let i=0; i<6; i++) {',
  'for(let i=0; i<12; i++) {'
);

content = content.replace(
  'scale: 0.5 + Math.random() * 0.8,',
  'scale: 0.4 + Math.random() * 0.7,'
);

content = content.replace(
  'offsetX: (Math.random() - 0.5) * 100',
  'offsetX: (Math.random() - 0.5) * 140'
);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Updated star count");
