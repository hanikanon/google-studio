const fs = require('fs');
let content = fs.readFileSync('src/components/AttachmentMenu.tsx', 'utf8');

const targetStr = `<div className="w-full bg-white dark:bg-[#1c1c1d] pb-safe">
                <div className="flex overflow-x-auto hide-scrollbar px-2 py-4 gap-2">
                  {items.map((item, i) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03, type: 'spring', stiffness: 400, damping: 25 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        if (navigator.vibrate) navigator.vibrate(10);
                        onSelect(item.id);
                      }}
                      className="flex flex-col items-center gap-2 outline-none w-[72px] shrink-0"
                    >
                      <div className={cn("w-[52px] h-[52px] rounded-full flex items-center justify-center text-white", item.bg)}>
                        <item.icon className="w-[24px] h-[24px]" strokeWidth={2} />
                      </div>
                      <span className="text-[12px] font-medium text-gray-700 dark:text-gray-300 tracking-tight leading-none">{item.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>`;

const replacement = `<div className="w-full bg-white dark:bg-[#1c1c1d] pb-safe border-t border-black/5 dark:border-white/5 pt-1">
                <div className="flex overflow-x-auto hide-scrollbar px-3 py-3 gap-1">
                  {items.map((item, i) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.02, type: 'spring', stiffness: 400, damping: 25 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        if (navigator.vibrate) navigator.vibrate(10);
                        onSelect(item.id);
                      }}
                      className="flex flex-col items-center gap-1.5 outline-none w-[70px] shrink-0 active:bg-black/5 dark:active:bg-white/5 rounded-xl py-1.5 transition-colors"
                    >
                      <div className={cn("w-[50px] h-[50px] rounded-full flex items-center justify-center text-white shadow-sm", item.bg)}>
                        <item.icon className="w-[22px] h-[22px]" strokeWidth={2} />
                      </div>
                      <span className="text-[12px] font-medium text-gray-700 dark:text-gray-300 tracking-tight leading-none">{item.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>`;

if (content.includes("pb-safe")) {
  fs.writeFileSync('src/components/AttachmentMenu.tsx', content.replace(targetStr, replacement));
  console.log("Fixed Attachment layout again");
} else {
  console.log("Not found");
}
