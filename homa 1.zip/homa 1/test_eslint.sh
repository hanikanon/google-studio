npx eslint src/
