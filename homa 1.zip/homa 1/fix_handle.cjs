const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `  const [flyingEmojis, setFlyingEmojis] = useState<{id: number, emoji: string, x: number, y: number}[]>([]);`;

const replacement = `  const [flyingEmojis, setFlyingEmojis] = useState<{id: number, emoji: string, x: number, y: number}[]>([]);

  const handleTranslate = (id: string, text: string) => {
    // In a real app we'd translate the text. For now we just add a note.
    setMessages(prev => prev.map(m => m.id === id ? { ...m, text: m.text + '\n[Translated]: ' + text } : m));
  };`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed handleTranslate.");
} else {
  console.log("Could not find target string.");
}
