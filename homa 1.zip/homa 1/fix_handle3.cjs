const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `                             if (action === 'theme') {
                               // Just toggle a class on the body for demonstration or show an alert
                               alert("Theme settings would open here.");
                             }`;

const replacement = `                             if (action === 'theme') {
                               document.documentElement.classList.toggle('dark');
                             }`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed theme.");
} else {
  console.log("Could not find target string.");
}
