const fs = require('fs');
let content = fs.readFileSync('src/components/messages/MessageMenu.tsx', 'utf8');

const targetStr = `      <AnimatePresence mode="popLayout" initial={false}>
        <motion.div
          key={isMoreOpen ? 'more' : 'main'}
          initial={{ x: isMoreOpen ? 20 : -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: isMoreOpen ? -20 : 20, opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 400 }}
          className="flex flex-col"
        >
          {actions.map((item: any, i) => (
            <button
              key={item.id}
              className={cn(
                "w-full flex items-center gap-4 px-4 py-2.5 transition-colors active:bg-black/5 dark:active:bg-white/5", 
                item.isRemove ? "text-[#FF3B30]" : "text-gray-900 dark:text-[#E5E5EA]"
              )}
              onClick={(e) => { 
                e.stopPropagation(); 
                if (item.id === 'more') {
                  setIsMoreOpen(true);
                } else if (item.id === 'back') {
                  setIsMoreOpen(false);
                } else {
                  onAction(item.id); 
                }
              }}
            >
              <div className="shrink-0">{item.icon}</div>
              <span className="text-[15px] font-medium leading-none">{item.label}</span>
            </button>
          ))}
        </motion.div>
      </AnimatePresence>`;

const replacement = `      <AnimatePresence mode="popLayout" initial={false}>
        <motion.div
          key={isMoreOpen ? 'more' : 'main'}
          initial={{ x: isMoreOpen ? 20 : -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: isMoreOpen ? -20 : 20, opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 400 }}
          className="flex flex-col py-1"
        >
          {actions.map((item: any, i) => (
            <button
              key={item.id}
              className={cn(
                "w-full flex items-center justify-between px-4 py-[11px] transition-colors active:bg-black/5 dark:active:bg-white/5", 
                item.isRemove ? "text-[#FF3B30]" : "text-gray-900 dark:text-gray-200"
              )}
              onClick={(e) => { 
                e.stopPropagation(); 
                if (item.id === 'more') {
                  setIsMoreOpen(true);
                } else if (item.id === 'back') {
                  setIsMoreOpen(false);
                } else {
                  onAction(item.id); 
                }
              }}
            >
              <span className="text-[15px] font-medium leading-none">{item.label}</span>
              <div className="shrink-0 opacity-80">{item.icon}</div>
            </button>
          ))}
        </motion.div>
      </AnimatePresence>`;

if (content.includes("AnimatePresence mode")) {
  let newContent = content.replace(targetStr, replacement);
  // Also fix the wrapper
  newContent = newContent.replace(
    `className="w-56 bg-white/95 dark:bg-[#232324]/95 backdrop-blur-xl border border-black/5 dark:border-white/10 rounded-[16px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_16px_40px_rgba(0,0,0,0.3)] flex flex-col overflow-hidden py-1.5"`,
    `className="w-[220px] bg-white dark:bg-[#1c1c1d] rounded-[14px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_32px_rgba(0,0,0,0.4)] flex flex-col overflow-hidden"`
  );
  fs.writeFileSync('src/components/messages/MessageMenu.tsx', newContent);
  console.log("Fixed MessageMenu");
}
