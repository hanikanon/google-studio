const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `      {/* Native Telegram-style App Bar */}
      <div className="z-50 shrink-0 relative flex items-center justify-between w-full h-[52px] bg-white dark:bg-[#1c1c1d]">
          {showSearch ? (
            <div className="flex items-center w-full px-1 gap-2 h-full">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors shrink-0 text-gray-500 dark:text-gray-400">
                <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[17px] font-medium text-gray-900 dark:text-white placeholder:text-gray-400"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-1.5 flex-1 min-w-0 h-full">
                <button 
                  onClick={onBack}
                  className="w-[42px] h-[42px] ml-0.5 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors shrink-0 text-gray-600 dark:text-gray-300"
                >
                  <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
                </button>
                
                <div className="flex items-center gap-2.5 flex-1 min-w-0 h-[44px] cursor-pointer rounded-full hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors pr-3 pl-1" onClick={() => setShowProfile(true)}>
                  <div className="relative shrink-0">
                    <div className={cn(
                      "w-[38px] h-[38px] rounded-full overflow-hidden flex items-center justify-center relative",
                      chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200 dark:bg-gray-700"
                    )}>
                      {chat.avatarType === 'image' ? (
                        <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                      ) : null}
                    </div>
                    {chat.isOnline && (
                      <div className="absolute bottom-[-1px] right-[-1px] w-[13px] h-[13px] bg-[#22c55e] border-[2.5px] border-white dark:border-[#1c1c1d] rounded-full z-20"></div>
                    )}
                  </div>
                  
                  <div className="flex flex-col justify-center min-w-0">
                    <span className="font-semibold text-[17px] text-gray-900 dark:text-white leading-[20px] tracking-tight flex items-center gap-1.5 truncate">
                      <span className="truncate">{chat.name}</span>
                      {isMuted && <BellOff className="w-[14px] h-[14px] text-gray-400 shrink-0" />}
                      {isPinned && <Pin className="w-[14px] h-[14px] text-gray-400 fill-gray-400 shrink-0" />}
                    </span>
                    <span className="text-[13.5px] text-gray-500 dark:text-gray-400 leading-[16px] truncate tracking-wide mt-0.5">
                      {isTyping ? <span className="text-[#007AFF] font-medium">typing...</span> : (chat.isOnline ? <span className="text-[#007AFF]">online</span> : 'last seen recently')}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center shrink-0 pr-0.5 gap-0.5">
                <button onClick={() => handleCall(true)} className={cn("w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors text-gray-600 dark:text-gray-300", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[24px] h-[24px]" strokeWidth={1.8} />
                </button>
                <button onClick={() => handleCall(false)} className={cn("w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors text-gray-600 dark:text-gray-300", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[22px] h-[22px]" strokeWidth={1.8} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors text-gray-600 dark:text-gray-300">
                    <MoreVertical className="w-[24px] h-[24px]" strokeWidth={1.8} />
                  </button>`;

const replacement = `      {/* Native Telegram-style App Bar */}
      <div className="z-50 shrink-0 relative flex items-center justify-between w-full pt-2 px-2 pb-2 bg-transparent pointer-events-none">
          {showSearch ? (
            <div className="flex items-center w-full px-1 gap-2 h-[44px] bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-md rounded-[24px] shadow-sm border border-black/5 dark:border-white/5 pointer-events-auto">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors shrink-0 text-gray-500 dark:text-gray-400">
                <ArrowLeft className="w-[22px] h-[22px]" strokeWidth={2.5} />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[16px] font-medium text-gray-900 dark:text-white placeholder:text-gray-400"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 flex-1 min-w-0">
                {/* Independent Back Button */}
                <button 
                  onClick={onBack}
                  className="w-[42px] h-[42px] rounded-full flex items-center justify-center bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-md shadow-sm border border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all shrink-0 text-gray-700 dark:text-gray-200 pointer-events-auto"
                >
                  <ArrowLeft className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                
                {/* Independent Profile Area */}
                <div 
                  className="flex items-center gap-2.5 flex-1 min-w-0 h-[42px] cursor-pointer rounded-[24px] bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-md shadow-sm border border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all pr-4 pl-1 py-1 pointer-events-auto" 
                  onClick={() => setShowProfile(true)}
                >
                  <div className="relative shrink-0">
                    <div className={cn(
                      "w-[34px] h-[34px] rounded-full overflow-hidden flex items-center justify-center relative",
                      chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200 dark:bg-gray-700"
                    )}>
                      {chat.avatarType === 'image' ? (
                        <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                      ) : null}
                    </div>
                    {chat.isOnline && (
                      <div className="absolute bottom-[0px] right-[0px] w-[11px] h-[11px] bg-[#22c55e] border-[2px] border-white dark:border-[#1c1c1d] rounded-full z-20"></div>
                    )}
                  </div>
                  
                  <div className="flex flex-col justify-center min-w-0">
                    <span className="font-semibold text-[15px] text-gray-900 dark:text-white leading-[18px] tracking-tight flex items-center gap-1.5 truncate">
                      <span className="truncate">{chat.name}</span>
                      {isMuted && <BellOff className="w-[12px] h-[12px] text-gray-400 shrink-0" />}
                      {isPinned && <Pin className="w-[12px] h-[12px] text-gray-400 fill-gray-400 shrink-0" />}
                    </span>
                    <span className="text-[12px] text-gray-500 dark:text-gray-400 leading-[14px] truncate tracking-wide mt-[1px]">
                      {isTyping ? <span className="text-[#007AFF] font-medium">typing...</span> : (chat.isOnline ? <span className="text-[#007AFF]">online</span> : 'last seen recently')}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center shrink-0 gap-1.5 ml-1">
                {/* Independent Call Button */}
                <button onClick={() => handleCall(true)} className={cn("w-[42px] h-[42px] rounded-full flex items-center justify-center bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-md shadow-sm border border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all text-gray-700 dark:text-gray-200 pointer-events-auto", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[20px] h-[20px]" strokeWidth={2.2} />
                </button>
                {/* Independent Phone Button */}
                <button onClick={() => handleCall(false)} className={cn("w-[42px] h-[42px] rounded-full flex items-center justify-center bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-md shadow-sm border border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all text-gray-700 dark:text-gray-200 pointer-events-auto", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[18px] h-[18px]" strokeWidth={2.2} />
                </button>
                {/* Independent Menu Button */}
                <div className="relative pointer-events-auto">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="w-[42px] h-[42px] rounded-full flex items-center justify-center bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-md shadow-sm border border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all text-gray-700 dark:text-gray-200">
                    <MoreVertical className="w-[20px] h-[20px]" strokeWidth={2.2} />
                  </button>`;

if (content.includes("Native Telegram-style App Bar")) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed floating App Bar structure");
} else {
  console.log("Not found");
}
