const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const target = `    setMessages(prev => prev.map(m => {
        if (m.id === msgId) {
             const existing = m.reactions || [];
             const reactionIdx = existing.findIndex(r => r.emoji === emoji);
             if (reactionIdx !== -1) {
                  const newReactions = existing.map((r, i) => i === reactionIdx ? { ...r } : r);
                  if (newReactions[reactionIdx].userReacted) {
                      newReactions[reactionIdx].count--;
                      newReactions[reactionIdx].userReacted = false;
                      if (newReactions[reactionIdx].count <= 0) {
                          newReactions.splice(reactionIdx, 1);
                      }
                  } else {
                      newReactions[reactionIdx].count++;
                      newReactions[reactionIdx].userReacted = true;
                  }
                  if (window.navigator && window.navigator.vibrate) window.navigator.vibrate(10);
                  return { ...m, reactions: newReactions };
             } else {
                  if (window.navigator && window.navigator.vibrate) window.navigator.vibrate(10);
                  return { ...m, reactions: [...existing, { emoji, count: 1, userReacted: true }] };
             }
        }
        return m;
    }));`;

const replacement = `    setMessages(prev => prev.map(m => {
        if (m.id === msgId) {
             if (window.navigator && window.navigator.vibrate) window.navigator.vibrate(10);
             const currentReaction = m.reactions?.[0];
             if (currentReaction && currentReaction.emoji === emoji && currentReaction.userReacted) {
                 return { ...m, reactions: [] };
             }
             return { ...m, reactions: [{ emoji, count: 1, userReacted: true }] };
        }
        return m;
    }));`;

if (content.includes(target)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(target, replacement));
  console.log("Reaction replaced successfully.");
} else {
  console.log("Could not find reaction block to replace!");
}
