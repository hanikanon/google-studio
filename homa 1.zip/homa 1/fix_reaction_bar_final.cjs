const fs = require('fs');
let content = fs.readFileSync('src/components/messages/ReactionBar.tsx', 'utf8');

content = content.replace(
  `className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-[#1c1c1d] rounded-[24px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_32px_rgba(0,0,0,0.4)] max-w-[280px] overflow-x-auto hide-scrollbar shrink-0"`,
  `className="flex items-center gap-1 px-2 py-1.5 bg-white dark:bg-[#1c1c1d] rounded-[24px] shadow-[0_4px_20px_rgba(0,0,0,0.12)] dark:shadow-[0_4px_20px_rgba(0,0,0,0.4)] max-w-[280px] overflow-x-auto hide-scrollbar shrink-0"`
);

content = content.replace(
  `className="text-[26px] shrink-0 origin-bottom flex items-center justify-center p-1 hover:bg-black/5 dark:hover:bg-white/5 rounded-full"`,
  `className="text-[24px] shrink-0 origin-bottom flex items-center justify-center p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-full"`
);

fs.writeFileSync('src/components/messages/ReactionBar.tsx', content);
console.log("Fixed reaction bar");
