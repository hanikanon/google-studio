const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const regex = /<\/AnimatePresence>\s*<\/div>\s*<\/div>\s*<\/>\s*<\/div>\s*<\/div>\s*{\/\* Messages Area \*\//;
console.log(regex.test(content));
