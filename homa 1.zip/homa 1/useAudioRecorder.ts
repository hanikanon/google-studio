import { useState, useRef, useCallback } from 'react';

export function useAudioRecorder() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [liveWaveform, setLiveWaveform] = useState<number[]>([]);

  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  const timerInterval = useRef<any>(null);
  const wfInterval = useRef<any>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const waveformRef = useRef<number[]>([]);
  const isCancelledRef = useRef(false);

  const cleanupAudio = () => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
        streamRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(console.error);
      }
    } catch (e) {
      console.error("Error during audio cleanup", e);
    }
  };

  const startRecording = useCallback(async () => {
    try {
      isCancelledRef.current = false;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (isCancelledRef.current) {
        stream.getTracks().forEach(t => t.stop());
        return;
      }
      
      streamRef.current = stream;
      
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          audioContextRef.current = new AudioContextClass();
          const source = audioContextRef.current.createMediaStreamSource(stream);
          const analyser = audioContextRef.current.createAnalyser();
          analyser.fftSize = 256;
          source.connect(analyser);
          analyserRef.current = analyser;
        }
      } catch (e) {
        console.warn("AudioContext visualization failed, continuing without waveform", e);
      }

      mediaRecorder.current = new MediaRecorder(stream);
      audioChunks.current = [];
      waveformRef.current = [];
      setLiveWaveform([]);
      
      mediaRecorder.current.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) audioChunks.current.push(e.data);
      };

      mediaRecorder.current.start(100);
      setIsRecording(true);
      setIsPaused(false);
      setRecordingDuration(0);

      timerInterval.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
      
      wfInterval.current = setInterval(() => {
        if (mediaRecorder.current?.state === 'paused') return;
        let norm = 2;
        if (analyserRef.current) {
          try {
            const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
            analyserRef.current.getByteTimeDomainData(dataArray);
            let sum = 0;
            for(let i=0; i<dataArray.length; i++){
              sum += Math.abs(dataArray[i] - 128);
            }
            let avg = sum / dataArray.length;
            norm = Math.min(24, Math.max(2, Math.floor(avg / 1.5) + 2)); 
          } catch(e) {}
        } else {
            // Fake waveform if AudioContext failed
            norm = Math.floor(Math.random() * 8) + 2;
        }
        waveformRef.current.push(norm);
        setLiveWaveform(prev => {
           const next = [...prev, norm];
           if (next.length > 40) return next.slice(next.length - 40);
           return next;
        });
      }, 100);

    } catch (e: any) {
      console.error("Failed to start recording:", e);
      window.dispatchEvent(new CustomEvent("AUDIO_RECORD_ERROR", { detail: e.message || "Microphone permission denied" }));
    }
  }, []);

  const pauseRecording = useCallback(() => {
    if (mediaRecorder.current && mediaRecorder.current.state === 'recording') {
      mediaRecorder.current.pause();
      setIsPaused(true);
      clearInterval(timerInterval.current);
    }
  }, []);

  const resumeRecording = useCallback(() => {
    if (mediaRecorder.current && mediaRecorder.current.state === 'paused') {
      mediaRecorder.current.resume();
      setIsPaused(false);
      timerInterval.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    }
  }, []);

  const stopRecording = useCallback((): Promise<{ url: string, duration: number, waveform: number[] } | null> => {
    return new Promise((resolve) => {
      if (!mediaRecorder.current || mediaRecorder.current.state === 'inactive') {
        resolve(null);
        return;
      }
      
      mediaRecorder.current.onstop = () => {
        try {
          const mimeType = audioChunks.current[0]?.type || mediaRecorder.current?.mimeType || 'audio/webm';
          if (audioChunks.current.length === 0) {
            resolve(null);
            return;
          }
          const audioBlob = new Blob(audioChunks.current, { type: mimeType });
          const url = URL.createObjectURL(audioBlob);
          
          let wf = [...waveformRef.current];
          if (wf.length > 40) {
              const step = wf.length / 40;
              wf = Array.from({ length: 40 }, (_, i) => wf[Math.floor(i * step)]);
          }
          
          const finalDur = recordingDuration;
          cleanupAudio();
          
          clearInterval(timerInterval.current);
          clearInterval(wfInterval.current);
          setIsRecording(false);
          setIsPaused(false);
          setLiveWaveform([]);
          resolve({ url, duration: finalDur, waveform: wf });
        } catch (e) {
          console.error("Error in onstop", e);
          resolve(null);
        }
      };
      
      try {
        mediaRecorder.current.stop();
      } catch(e) {
        console.error("Error calling stop()", e);
        resolve(null);
      }
    });
  }, [recordingDuration]);
  
  const cancelRecording = useCallback(() => {
    isCancelledRef.current = true;
    try {
      if (mediaRecorder.current && mediaRecorder.current.state !== 'inactive') {
        mediaRecorder.current.onstop = null;
        mediaRecorder.current.stop();
      }
    } catch (e) {
      console.error("Error cancelling", e);
    }
    
    cleanupAudio();
    clearInterval(timerInterval.current);
    clearInterval(wfInterval.current);
    setIsRecording(false);
    setIsPaused(false);
    setLiveWaveform([]);
  }, []);

  return { isRecording, isPaused, recordingDuration, liveWaveform, startRecording, pauseRecording, resumeRecording, stopRecording, cancelRecording };
}
