const fs = require('fs');
let content = fs.readFileSync('src/components/MessageInput.tsx', 'utf8');

const targetStr = `      </div>
      </div>
    </div>
  );
};`;

const replacement = `      </div>
    </div>
  );
};`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessageInput.tsx', content.replace(targetStr, replacement));
  console.log("Removed extra div.");
} else {
  console.log("Could not find extra div!");
}
