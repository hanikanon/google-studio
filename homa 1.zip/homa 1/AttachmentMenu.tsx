import React, { useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, Image as ImageIcon, Video, FileText, Music, MapPin, User, BarChart2, Smile, Sticker } from 'lucide-react';
import { cn } from '../utils';

interface AttachmentMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (type: string) => void;
}

export const AttachmentMenu: React.FC<AttachmentMenuProps> = ({ isOpen, onClose, onSelect }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  const items = [
    { id: 'gallery', icon: ImageIcon, label: 'Gallery', bg: 'bg-[#40A7E3]' },
    { id: 'camera', icon: Camera, label: 'Camera', bg: 'bg-[#50B2ED]' },
    { id: 'video', icon: Video, label: 'Videos', bg: 'bg-[#ED6454]' },
    { id: 'document', icon: FileText, label: 'File', bg: 'bg-[#54C164]' },
    { id: 'location', icon: MapPin, label: 'Location', bg: 'bg-[#55B059]' },
    { id: 'contact', icon: User, label: 'Contact', bg: 'bg-[#54C3EB]' },
    { id: 'audio', icon: Music, label: 'Audio', bg: 'bg-[#F28236]' },
    { id: 'poll', icon: BarChart2, label: 'Poll', bg: 'bg-[#FFBA34]' },
    { id: 'gif', icon: Smile, label: 'GIF', bg: 'bg-[#ED6454]' },
    { id: 'sticker', icon: Sticker, label: 'Sticker', bg: 'bg-[#FFBA34]' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="absolute inset-0 z-[55] bg-black/40 dark:bg-black/60 cursor-default"
          />
          <motion.div
            ref={containerRef}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 1 }}
            onDragEnd={(e, info) => {
              if (info.offset.y > 100 || info.velocity.y > 500) {
                onClose();
              }
            }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 300, mass: 0.8 }}
            className="absolute bottom-0 left-0 right-0 z-[60] bg-white dark:bg-[#1c1c1d] rounded-t-[16px] pt-3 pb-8 shadow-[0_-10px_40px_rgba(0,0,0,0.15)] flex flex-col touch-pan-y"
          >
            <div className="w-9 h-1 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-5 shrink-0" />
            
            <div className="w-full flex flex-col">
              {/* Fake Gallery area */}
              <div className="w-full px-1 overflow-hidden flex flex-col mb-1">
                <div className="flex items-center justify-between px-3 mb-2">
                  <span className="text-[14px] font-semibold text-gray-800 dark:text-gray-200">Recent Media</span>
                </div>
                <div className="w-full flex gap-1.5 overflow-x-auto hide-scrollbar px-3 pb-2">
                  {[1,2,3,4,5,6].map((img, idx) => (
                    <div key={idx} className="w-[100px] h-[140px] shrink-0 bg-gray-100 dark:bg-gray-800/50 rounded-[8px] overflow-hidden flex flex-col items-center justify-center relative border border-black/5 dark:border-white/5">
                      <ImageIcon className="w-8 h-8 text-gray-400 dark:text-gray-600 opacity-50 mb-1" />
                      <span className="text-[10px] text-gray-400 font-medium">Image {idx+1}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="w-full bg-white dark:bg-[#1c1c1d] border-t border-black/5 dark:border-white/5 pt-3 pb-2">
                <div className="flex flex-wrap justify-center gap-x-3 gap-y-3 px-4">
                  {items.map((item, i) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.02, type: 'spring', stiffness: 400, damping: 25 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        if (navigator.vibrate) navigator.vibrate(10);
                        onSelect(item.id);
                      }}
                      className="flex flex-col items-center gap-1.5 outline-none w-[64px] shrink-0 active:opacity-70 transition-opacity"
                    >
                      <div className={cn("w-[48px] h-[48px] rounded-full flex items-center justify-center text-white shadow-sm", item.bg)}>
                        <item.icon className="w-[22px] h-[22px]" strokeWidth={2} />
                      </div>
                      <span className="text-[11px] font-medium text-gray-700 dark:text-gray-300 tracking-tight leading-none">{item.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
