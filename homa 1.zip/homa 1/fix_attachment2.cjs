const fs = require('fs');
let content = fs.readFileSync('src/components/AttachmentMenu.tsx', 'utf8');

const targetStr = `<div className="overflow-y-auto no-scrollbar pb-safe max-h-[60vh] px-4">
              <div className="grid grid-cols-4 gap-y-5 gap-x-2 w-full">
                {items.map((item, i) => (
                  <motion.button
                    key={item.id}
                    initial={{ opacity: 0, scale: 0.9, y: 15 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ delay: i * 0.02, type: 'spring', stiffness: 400, damping: 25 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => {
                      if (navigator.vibrate) navigator.vibrate(10);
                      onSelect(item.id);
                    }}
                    className="flex flex-col items-center gap-1.5 outline-none group"
                  >
                    <div className={cn("w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-sm text-white", item.bg)}>
                      <item.icon className="w-[26px] h-[26px]" strokeWidth={1.5} />
                    </div>
                    <span className="text-[12px] font-medium text-gray-800 dark:text-gray-300 tracking-tight leading-tight">{item.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>`;

const replacement = `<div className="w-full flex-1 flex flex-col h-[320px]">
              {/* Fake Gallery area */}
              <div className="flex-1 px-2 pb-4 overflow-hidden flex flex-col">
                <div className="flex items-center justify-between px-2 mb-2">
                  <span className="text-[15px] font-medium text-gray-800 dark:text-gray-200">Recent</span>
                </div>
                <div className="flex-1 flex gap-1 overflow-x-auto hide-scrollbar px-2 pb-2">
                  {[1,2,3,4,5].map((img, idx) => (
                    <div key={idx} className="w-[110px] shrink-0 h-full bg-gray-200 dark:bg-gray-800 rounded-[10px] overflow-hidden flex items-center justify-center relative">
                      <ImageIcon className="w-8 h-8 text-gray-400 dark:text-gray-600 opacity-50" />
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="w-full bg-white dark:bg-[#1c1c1d] pb-safe">
                <div className="flex overflow-x-auto hide-scrollbar px-2 py-4 gap-2">
                  {items.map((item, i) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03, type: 'spring', stiffness: 400, damping: 25 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        if (navigator.vibrate) navigator.vibrate(10);
                        onSelect(item.id);
                      }}
                      className="flex flex-col items-center gap-2 outline-none w-[72px] shrink-0"
                    >
                      <div className={cn("w-[52px] h-[52px] rounded-full flex items-center justify-center text-white", item.bg)}>
                        <item.icon className="w-[24px] h-[24px]" strokeWidth={2} />
                      </div>
                      <span className="text-[12px] font-medium text-gray-700 dark:text-gray-300 tracking-tight leading-none">{item.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>`;

if (content.includes("grid-cols-4")) {
  fs.writeFileSync('src/components/AttachmentMenu.tsx', content.replace(targetStr, replacement));
  console.log("Fixed Attachment Menu");
} else {
  console.log("Not found");
}
