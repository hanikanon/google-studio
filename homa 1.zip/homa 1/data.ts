export type MessageType = 'text' | 'image' | 'video' | 'audio' | 'file' | 'sticker' | 'media' | 'poll';

export type Message = {
  id: string;
  type?: MessageType;
  text?: string;
  senderId: string;
  time: string;
  isRead: boolean;
  readStatus?: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
  // Media properties
  imageUrl?: string;
  mediaGroup?: { url: string; type: 'image' | 'video' }[];
  audioDuration?: string;
  audioUrl?: string;
  waveform?: number[];
  fileName?: string;
  fileSize?: string;
  fileType?: string;
  stickerUrl?: string;
  pollData?: { question: string; options: { text: string; votes: number }[] };
  isPinned?: boolean;
  isSaved?: boolean;
  replyTo?: Message;
  reactions?: { emoji: string; count: number; userReacted?: boolean }[];
};

export type Chat = {
  id: string;
  name: string;
  avatar: string;
  avatarType?: 'image' | 'icon' | 'color';
  avatarColor?: string;
  iconName?: string;
  isVerified?: boolean;
  time?: string;
  preview: string;
  previewPrefix?: string;
  unreadCount?: number;
  isPinned?: boolean;
  isStarred?: boolean;
  isMuted?: boolean;
  isBlocked?: boolean;
  isArchived?: boolean;
  badge?: { text: string; color: string };
  actionButton?: string;
  isOnline?: boolean;
  isTyping?: boolean;
  readStatus?: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
  messages?: Message[];
  type?: 'private' | 'channel' | 'bot' | 'group';
  subscriberCount?: string;
  memberCount?: string;
};

export const chats: Chat[] = [
  {
    id: '0',
    name: 'Elena Rostova',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150&q=80',
    avatarType: 'image',
    isVerified: false,
    time: '17:34',
    preview: 'Just sent the assets over. Let me...',
    previewPrefix: 'You: ',
    isPinned: true,
    isStarred: true,
    isTyping: true,
    isOnline: true,
    type: 'private',
    readStatus: 'read',
    messages: []
  },
  {
    id: '1',
    name: 'Tech News',
    avatar: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=150&h=150&q=80',
    avatarType: 'image',
    type: 'channel',
    subscriberCount: '1.2M subscribers',
    preview: 'Breaking: New AI model released today with unprecedented capabilities...',
    unreadCount: 5,
    isMuted: true,
    time: '16:00'
  },
  {
    id: '2',
    name: 'Project Team',
    avatar: '',
    avatarType: 'icon',
    avatarColor: 'bg-emerald-600',
    iconName: 'users',
    type: 'group',
    memberCount: '15 members',
    time: '14:20',
    preview: 'John: Let\'s start the meeting',
    unreadCount: 12,
    isPinned: true
  },
  {
    id: '3',
    name: 'Trading Assistant',
    avatar: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=150&h=150&q=80',
    avatarType: 'image',
    type: 'bot',
    time: '12:45',
    preview: 'BTC has just crossed the $65,000 resistance level.',
    isOnline: true,
    isStarred: true
  },
  {
    id: '4',
    name: 'Spam User',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
    avatarType: 'image',
    time: '24 mars',
    preview: 'Buy crypto now!!!',
    isBlocked: true,
    isOnline: false,
    type: 'private'
  },
  {
    id: '5',
    name: 'Archived Group',
    avatar: '',
    avatarType: 'icon',
    avatarColor: 'bg-gray-600',
    iconName: 'users',
    time: 'Jan 1',
    preview: 'Happy New Year!',
    isArchived: true,
    type: 'group'
  },
  {
    id: '6',
    name: 'Mes notes',
    avatar: '',
    avatarType: 'icon',
    avatarColor: 'bg-blue-600',
    iconName: 'bookmark',
    time: '10:30',
    preview: '📊 Plan de trading hebdomadaire',
    previewPrefix: 'Vous : ',
    readStatus: 'read',
    isStarred: true,
    type: 'private'
  },
  {
    id: '7',
    name: 'Rakuten Viber',
    avatar: '',
    avatarType: 'icon',
    avatarColor: 'bg-indigo-600',
    iconName: 'phone',
    isVerified: true,
    time: 'mars 25',
    preview: 'Les conditions et la politique de confidentialité...',
    unreadCount: 4,
    type: 'channel',
    isMuted: false
  }
];