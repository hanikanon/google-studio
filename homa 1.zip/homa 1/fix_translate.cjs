const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const target = `{ icon: <Globe className="w-[18px] h-[18px]" />, label: 'Translate', action: () => setSelectedMessageId(null) }`;
const replacement = `{ icon: <Globe className="w-[18px] h-[18px]" />, label: 'Translate', action: () => { handleTranslate(msg.id, msg.text); setSelectedMessageId(null); } }`;

if (content.includes(target)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(target, replacement));
  console.log("Replaced successfully.");
} else {
  console.log("Could not find target block to replace!");
}
