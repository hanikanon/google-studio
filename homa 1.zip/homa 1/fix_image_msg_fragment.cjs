const fs = require('fs');
let content = fs.readFileSync('src/components/messages/ImageMessage.tsx', 'utf8');

const targetStr = `                  <img 
                    src={img.url || img} 
                    alt="" 
                    loading="lazy"
                    onLoad={(e) => {
                      (e.target as HTMLImageElement).classList.remove('opacity-0');
                    }}
                    className="w-full h-full object-cover select-none pointer-events-none opacity-0 transition-opacity duration-300" 
                  />
                  <div className="absolute inset-0 bg-black/5 flex items-center justify-center -z-10 animate-pulse" />`;

const replacement = `                  <>
                    <img 
                      src={img.url || img} 
                      alt="" 
                      loading="lazy"
                      onLoad={(e) => {
                        (e.target as HTMLImageElement).classList.remove('opacity-0');
                      }}
                      className="w-full h-full object-cover select-none pointer-events-none opacity-0 transition-opacity duration-300" 
                    />
                    <div className="absolute inset-0 bg-black/5 flex items-center justify-center -z-10 animate-pulse" />
                  </>`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/messages/ImageMessage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed ImageMessage fragment.");
} else {
  console.log("Could not find target in ImageMessage for fragment!");
}
