const fs = require('fs');
let content = fs.readFileSync('src/components/MessageInput.tsx', 'utf8');

const targetStr = `      <div className="px-3 py-2 flex items-end gap-1 relative z-10">
      <div className={cn("w-full bg-white rounded-[24px] flex items-end px-1 shadow-[0_2px_8px_rgba(0,0,0,0.08)] border border-gray-200/50 min-h-[44px] transition-all relative overflow-visible", (isRecording || isLocked) ? "bg-[#f5f6f8]" : "")}>`;

const replacement = `      <div className="px-2 py-1.5 flex items-end gap-1.5 relative z-10">
      <div className={cn("flex-1 bg-white dark:bg-[#1c1c1d] rounded-[24px] flex items-end px-1 shadow-sm border border-black/5 dark:border-white/10 min-h-[44px] transition-all relative overflow-visible", (isRecording || isLocked) ? "bg-[#f5f6f8] dark:bg-white/5" : "")}>`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessageInput.tsx', content.replace(targetStr, replacement));
  console.log("Fixed input container.");
} else {
  console.log("Could not find input container!");
}
