import { JSDOM, VirtualConsole } from 'jsdom';
import fs from 'fs';

let html = fs.readFileSync('./dist/index.html', 'utf8');
html = html.replace(/type="module"/g, 'type="text/javascript"');

const virtualConsole = new VirtualConsole();
virtualConsole.on("error", (...args) => { console.error("JSDOM ERROR:", ...args); });
virtualConsole.on("warn", (...args) => { console.warn("JSDOM WARN:", ...args); });
virtualConsole.on("info", (...args) => { console.info("JSDOM INFO:", ...args); });
virtualConsole.on("dir", (...args) => { console.info("JSDOM DIR:", ...args); });
virtualConsole.on("log", (...args) => { console.log("JSDOM LOG:", ...args); });
virtualConsole.on("jsdomError", (e) => { console.error("JSDOM UNCAUGHT:", e.message, e.stack); });

const dom = new JSDOM(html, { 
  runScripts: "dangerously", 
  url: "http://localhost/",
  virtualConsole
});

Object.defineProperty(dom.window, 'ResizeObserver', { value: class { observe(){} unobserve(){} disconnect(){} } });
Object.defineProperty(dom.window, 'IntersectionObserver', { value: class { observe(){} unobserve(){} disconnect(){} } });
Object.defineProperty(dom.window, 'matchMedia', { value: () => ({ matches: false, addListener: () => {}, removeListener: () => {} }) });

setTimeout(() => {
  console.log("Root HTML:", dom.window.document.getElementById('root').innerHTML.substring(0, 500));
  process.exit(0);
}, 2000);
