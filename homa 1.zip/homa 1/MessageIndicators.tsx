import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, CheckCheck, Clock, AlertCircle, Pin, Star } from 'lucide-react';
import { cn } from '../utils';

interface MessageIndicatorsProps {
  isMe: boolean;
  status?: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
  isRead?: boolean;
  isSaved?: boolean;
  isPinned?: boolean;
  className?: string;
  isImageOverlay?: boolean;
}

export const MessageIndicators: React.FC<MessageIndicatorsProps> = ({
  isMe, status, isRead, isSaved, isPinned, className, isImageOverlay
}) => {
  const currentStatus = status || (isRead ? 'read' : 'sent');

  return (
    <div className={cn("flex items-center gap-1 shrink-0 overflow-visible ml-1", className)}>
      <AnimatePresence>
                {isSaved && (
          <motion.div
            key="saved"
            initial={{ scale: 0.2, rotate: -30, opacity: 0 }}
            animate={{ scale: 1, rotate: 0, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 450, damping: 15, mass: 0.8 }}
            exit={{ scale: 0, opacity: 0, transition: { duration: 0.15 } }}
            className={cn("flex items-center justify-center relative origin-center", isImageOverlay ? "text-white drop-shadow-md" : "text-amber-500")}
          >
            <Star className={cn("fill-current z-10", isImageOverlay ? "w-3 h-3" : "w-[13px] h-[13px]")} strokeWidth={1.5} />
          </motion.div>
        )}
        {isPinned && (
          <motion.div
            key="pinned"
            initial={{ scale: 0, y: -10, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1, transition: { type: 'spring', stiffness: 400, damping: 15 } }}
            exit={{ scale: 0, opacity: 0, y: -10, transition: { duration: 0.15 } }}
            className={cn("flex items-center justify-center", isImageOverlay ? "text-white drop-shadow-md" : (isMe ? "text-white" : "text-blue-500"))}
          >
            <Pin className={cn("fill-current rotate-45", isImageOverlay ? "w-3 h-3" : "w-[12px] h-[12px]")} strokeWidth={1.5} />
          </motion.div>
        )}
      </AnimatePresence>

      {isMe && (
        <div className="relative w-[16px] h-[16px] flex items-center justify-center">
          <AnimatePresence mode="wait">
            {currentStatus === 'sending' && (
              <motion.div
                key="sending"
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.5, opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <Clock className={cn("w-[12px] h-[12px]", isImageOverlay ? "text-white drop-shadow-md" : (isMe ? "text-white/70" : "text-gray-400"))} strokeWidth={2.5} />
              </motion.div>
            )}
            {currentStatus === 'sent' && (
              <motion.div
                key="sent"
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.5, opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <Check className={cn("w-[14px] h-[14px]", isImageOverlay ? "text-white drop-shadow-md" : (isMe ? "text-white/70" : "text-gray-400"))} strokeWidth={2.5} />
              </motion.div>
            )}
            {currentStatus === 'delivered' && (
              <motion.div
                key="delivered"
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.5, opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <CheckCheck className={cn("w-[15px] h-[15px]", isImageOverlay ? "text-white drop-shadow-md" : "text-gray-400")} strokeWidth={2.5} />
              </motion.div>
            )}
            {currentStatus === 'read' && (
              <motion.div
                key="read"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <CheckCheck className={cn("w-[15px] h-[15px]", isImageOverlay ? "text-white drop-shadow-md" : "text-blue-500")} strokeWidth={2.5} />
              </motion.div>
            )}
            {currentStatus === 'failed' && (
              <motion.div
                key="failed"
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.5, opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <AlertCircle className="w-[13px] h-[13px] text-red-500 drop-shadow-sm" strokeWidth={2.5} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};
