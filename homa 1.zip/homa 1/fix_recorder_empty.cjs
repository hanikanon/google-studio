const fs = require('fs');
let content = fs.readFileSync('src/useAudioRecorder.ts', 'utf8');

content = content.replace(
  '          const audioBlob = new Blob(audioChunks.current, { type: mimeType });',
  `          if (audioChunks.current.length === 0) {
            resolve(null);
            return;
          }
          const audioBlob = new Blob(audioChunks.current, { type: mimeType });`
);

fs.writeFileSync('src/useAudioRecorder.ts', content);
console.log('Fixed empty chunks');
