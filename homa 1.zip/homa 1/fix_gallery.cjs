const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const oldGalleryBlock = `            <div className="flex-1 relative flex items-center justify-center overflow-hidden"
              onClick={() => setMediaViewer(null)}
            >
              <motion.div
                key={mediaViewer.index}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                className="relative w-full h-full flex items-center justify-center"
                onClick={(e) => e.stopPropagation()}
              >
                {(() => {
                  const item = mediaViewer.msg.mediaGroup ? mediaViewer.msg.mediaGroup[mediaViewer.index] : mediaViewer.msg.imageUrl;
                  const isVideo = item && typeof item !== 'string' && (item as any).type === 'video';
                  const url = typeof item === 'string' ? item : (item as any)?.url || mediaViewer.msg.imageUrl;
                  
                  if (isVideo) {
                     return <video src={url} controls autoPlay className="max-w-full max-h-full object-contain" />;
                  }
                  return <img src={url} alt="fullscreen media" className="max-w-full max-h-full object-contain" />;
                })()}
              </motion.div>
              
              {mediaViewer.msg.mediaGroup && mediaViewer.msg.mediaGroup.length > 1 && (
                <>
                  <button 
                    onClick={(e) => { e.stopPropagation(); setMediaViewer(prev => prev && prev.index > 0 ? { ...prev, index: prev.index - 1 } : prev); }}
                    className={cn("absolute left-4 p-3 rounded-full bg-black/30 backdrop-blur-md text-white transition-opacity", mediaViewer.index === 0 ? "opacity-0 pointer-events-none" : "opacity-100 hover:bg-black/50")}
                  >
                    <ArrowLeft className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); setMediaViewer(prev => prev && prev.msg.mediaGroup && prev.index < prev.msg.mediaGroup.length - 1 ? { ...prev, index: prev.index + 1 } : prev); }}
                    className={cn("absolute right-4 p-3 rounded-full bg-black/30 backdrop-blur-md text-white transition-opacity", mediaViewer.msg.mediaGroup && mediaViewer.index === mediaViewer.msg.mediaGroup.length - 1 ? "opacity-0 pointer-events-none" : "opacity-100 hover:bg-black/50")}
                  >
                    <ArrowLeft className="w-6 h-6 rotate-180" />
                  </button>
                </>
              )}
            </div>`;

const newGalleryBlock = `            <div className="flex-1 relative flex items-center justify-center overflow-hidden"
              onClick={() => setMediaViewer(null)}
            >
              <AnimatePresence initial={false} custom={mediaViewer.index}>
                <motion.div
                  key={mediaViewer.index}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={1}
                  onDragEnd={(e, { offset, velocity }) => {
                    const swipe = swipePower(offset.x, velocity.x);
                    if (swipe < -swipeConfidenceThreshold) {
                      setMediaViewer(prev => prev && prev.msg.mediaGroup && prev.index < prev.msg.mediaGroup.length - 1 ? { ...prev, index: prev.index + 1 } : prev);
                    } else if (swipe > swipeConfidenceThreshold) {
                      setMediaViewer(prev => prev && prev.index > 0 ? { ...prev, index: prev.index - 1 } : prev);
                    }
                  }}
                  className="absolute inset-0 w-full h-full flex items-center justify-center touch-pan-y"
                  onClick={(e) => e.stopPropagation()}
                >
                  {(() => {
                    const item = mediaViewer.msg.mediaGroup ? mediaViewer.msg.mediaGroup[mediaViewer.index] : mediaViewer.msg.imageUrl;
                    const isVideo = item && typeof item !== 'string' && (item as any).type === 'video';
                    const url = typeof item === 'string' ? item : (item as any)?.url || mediaViewer.msg.imageUrl;
                    
                    if (isVideo) {
                       return <video src={url} controls autoPlay className="max-w-full max-h-full object-contain pointer-events-none" />;
                    }
                    return <img src={url} alt="fullscreen media" className="max-w-full max-h-full object-contain pointer-events-none" />;
                  })()}
                </motion.div>
              </AnimatePresence>
            </div>`;

if (content.includes(oldGalleryBlock)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(oldGalleryBlock, newGalleryBlock));
  console.log("Fixed gallery.");
} else {
  console.log("Could not find gallery block!");
}
