const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const oldHeaderRegex = /\{\/\* Native Telegram-style App Bar \*\/\}([\s\S]*?)<div className="flex-1 overflow-y-auto relative z-10"/;

const newHeader = `{/* Native Telegram-style App Bar */}
      <div className="z-50 shrink-0 relative flex flex-col w-full bg-white/95 dark:bg-[#1c1c1d]/95 backdrop-blur-md shadow-sm border-b border-black/5 dark:border-white/5">
        <div className="flex items-center h-[56px] px-1 gap-1">
          {showSearch ? (
            <div className="flex-1 flex items-center px-2">
              <div className="flex-1 flex items-center bg-gray-100 dark:bg-gray-800 rounded-lg px-3 py-1.5 h-[36px]">
                <Search className="w-4 h-4 text-gray-500 mr-2 shrink-0" />
                <input 
                  autoFocus
                  type="text" 
                  placeholder="Search in chat" 
                  className="flex-1 bg-transparent border-none outline-none text-[15px] dark:text-white"
                />
              </div>
              <button 
                onClick={() => setShowSearch(false)}
                className="ml-3 text-[#007AFF] text-[16px] font-medium"
              >
                Cancel
              </button>
            </div>
          ) : (
            <>
              {/* Back Button */}
              <button 
                onClick={onBack}
                className="w-[44px] h-[44px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 shrink-0 text-[#007AFF] dark:text-white transition-colors"
              >
                <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
              </button>
              
              {/* Profile Block */}
              <div className="flex items-center gap-2.5 flex-1 min-w-0 h-[48px] cursor-pointer rounded-xl hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 px-1 transition-colors" onClick={() => setShowProfile(true)}>
                <div className="relative shrink-0">
                  <div className={cn(
                    "w-10 h-10 rounded-full overflow-hidden flex items-center justify-center relative",
                    chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200 dark:bg-gray-700"
                  )}>
                    {chat.avatarType === 'image' ? (
                      <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                    ) : null}
                  </div>
                  {chat.isOnline && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#22c55e] border-[2px] border-white dark:border-[#1c1c1d] rounded-full z-20"></div>
                  )}
                </div>
                
                <div className="flex flex-col justify-center min-w-0 pb-0.5">
                  <span className="font-semibold text-[17px] text-gray-900 dark:text-white leading-[20px] tracking-tight flex items-center gap-1.5 truncate">
                    <span className="truncate">{chat.name}</span>
                    {isMuted && <BellOff className="w-[14px] h-[14px] text-gray-400 shrink-0" />}
                    {isPinned && <Pin className="w-[14px] h-[14px] text-gray-400 fill-gray-400 shrink-0" />}
                  </span>
                  <span className="text-[13px] text-gray-500 dark:text-gray-400 leading-[16px] truncate tracking-wide mt-[2px]">
                    {isTyping ? <span className="text-[#007AFF] font-medium">typing...</span> : (chat.isOnline ? <span className="text-[#007AFF]">online</span> : 'last seen recently')}
                  </span>
                </div>
              </div>
              
              {/* Actions */}
              <div className="flex items-center shrink-0 pr-1 text-[#007AFF] dark:text-white">
                <button onClick={() => handleCall(true)} className={cn("w-[40px] h-[40px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[24px] h-[24px]" strokeWidth={1.8} />
                </button>
                <button onClick={() => handleCall(false)} className={cn("w-[40px] h-[40px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[22px] h-[22px]" strokeWidth={1.8} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="w-[40px] h-[40px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors">
                    <MoreVertical className="w-[24px] h-[24px]" strokeWidth={1.8} />
                  </button>
                  <AnimatePresence>
                    {isMenuOpen && (
                      <ChatHeaderMenu 
                        isOpen={isMenuOpen} 
                        onClose={() => setIsMenuOpen(false)} 
                        chat={chat} 
                        isMuted={isMuted} 
                        setIsMuted={setIsMuted} 
                        onSearchClick={() => { setIsMenuOpen(false); setShowSearch(true); }}
                        onClearHistory={() => { setMessages([]); setIsMenuOpen(false); }}
                        onBlock={() => { setIsBlocked(!isBlocked); setIsMenuOpen(false); }}
                        isBlocked={isBlocked}
                      />
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto relative z-10"`;

content = content.replace(oldHeaderRegex, newHeader);
fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log('Fixed header');
