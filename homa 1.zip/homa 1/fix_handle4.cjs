const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `    setMessages(prev => prev.map(m => m.id === id ? { ...m, text: m.text + '
[Translated]: ' + text } : m));`;

const replacementStr = `    setMessages(prev => prev.map(m => m.id === id ? { ...m, text: m.text + '\\n[Translated]: ' + text } : m));`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacementStr));
  console.log("Fixed string literal.");
} else {
  console.log("Could not find string literal!");
}
