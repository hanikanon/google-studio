const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

if (!content.includes('ChatHeaderMenu')) {
    console.log('Not found at all??');
} else {
    content = content.replace("import { MessageMenu } from './messages/MessageMenu';", "import { MessageMenu } from './messages/MessageMenu';\nimport { ChatHeaderMenu } from './messages/ChatHeaderMenu';");
    fs.writeFileSync('src/components/MessagesPage.tsx', content);
    console.log("Added import.");
}
