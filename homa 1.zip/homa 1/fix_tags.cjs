const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const regex = /}\s*<\/div>\s*<\/div>\s*{\/\* Messages Area \*\//g;
content = content.replace(regex, `}
      </div>
      {/* Messages Area */}`);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Fixed");
