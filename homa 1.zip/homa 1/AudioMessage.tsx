import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause } from 'lucide-react';
import { MessageIndicators } from './MessageIndicators';
import { cn } from '../utils';

const AUDIO_PLAY_EVENT = 'AUDIO_MESSAGE_PLAY';

interface AudioMessageProps {
  msg: {
    id: string;
    audioDuration?: string;
    audioUrl?: string;
    waveform?: number[];
    time: string;
    isRead: boolean;
    readStatus?: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
    isPinned?: boolean;
    isSaved?: boolean;
  };
  isMe: boolean;
}

export const AudioMessage: React.FC<AudioMessageProps> = ({ msg, isMe }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0); 
  const [currentTime, setCurrentTime] = useState('0:00');
  const [playbackRate, setPlaybackRate] = useState(1);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const waveformRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>();
  
  const defaultWaveform = [2, 4, 3, 5, 8, 4, 2, 5, 7, 4, 3, 2, 4, 6, 8, 5, 3, 2, 4, 3, 5, 7, 6, 4, 3, 2];
  const waveform = msg.waveform || defaultWaveform;
  
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  useEffect(() => {
    if (!msg.audioUrl) return;
    const audio = new Audio(msg.audioUrl);
    audioRef.current = audio;
    
    const setAudioTime = () => {
      if (!audio.duration) return;
      const curr = audio.currentTime;
      const dur = audio.duration;
      setProgress(curr / dur);
      
      const mins = Math.floor(curr / 60);
      const secs = Math.floor(curr % 60);
      setCurrentTime(`${mins}:${secs.toString().padStart(2, '0')}`);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setProgress(0);
      setCurrentTime('0:00');
    };

    const animate = () => {
      if (isPlaying && audio) {
        setAudioTime();
        animationRef.current = requestAnimationFrame(animate);
      }
    };

    if (isPlaying) {
      animationRef.current = requestAnimationFrame(animate);
    } else {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    }

    audio.addEventListener('timeupdate', setAudioTime);
    audio.addEventListener('ended', handleEnded);
    audio.playbackRate = playbackRate;

    const handleGlobalPlay = (e: any) => {
      if (e.detail.id !== msg.id && !audio.paused) {
        audio.pause();
        setIsPlaying(false);
      }
    };
    
    window.addEventListener(AUDIO_PLAY_EVENT, handleGlobalPlay);

    return () => {
      audio.removeEventListener('timeupdate', setAudioTime);
      audio.removeEventListener('ended', handleEnded);
      window.removeEventListener(AUDIO_PLAY_EVENT, handleGlobalPlay);
      audio.pause();
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [msg.id, msg.audioUrl, playbackRate, isPlaying]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio || !msg.audioUrl) return; 
    
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      window.dispatchEvent(new CustomEvent(AUDIO_PLAY_EVENT, { detail: { id: msg.id } }));
      audio.play().catch(e => {
        console.error('Audio playback failed:', e);
        setIsPlaying(false);
      });
      setIsPlaying(true);
    }
  };

  const toggleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPlaybackRate(prev => {
      if (prev === 1) return 1.5;
      if (prev === 1.5) return 2;
      return 1;
    });
  };

  const handleSeek = (e: React.PointerEvent) => {
    if (!audioRef.current || !waveformRef.current) return;
    const rect = waveformRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const pct = x / rect.width;
    
    audioRef.current.currentTime = pct * (audioRef.current.duration || 0);
    setProgress(pct);
  };
  
  return (
    <div className="px-2 py-1.5 min-w-[200px] max-w-[260px] flex gap-2.5 items-center relative">
      <button 
        onClick={togglePlay}
        className={cn(
          "w-[38px] h-[38px] rounded-full flex items-center justify-center flex-shrink-0 transition-all active:scale-90",
          isMe ? "bg-white text-[#4FA953]" : "bg-[#007AFF] text-white"
        )}
      >
        {isPlaying ? (
          <Pause className="w-[18px] h-[18px] fill-current" />
        ) : (
          <Play className="w-[18px] h-[18px] ml-0.5 fill-current" />
        )}
      </button>
      
      <div className="flex-1 flex flex-col justify-center min-w-0 pt-[2px]">
        <div 
          ref={waveformRef}
          onPointerDown={handleSeek}
          className="flex items-end gap-[1.5px] h-[20px] cursor-pointer touch-none opacity-90 transition-opacity hover:opacity-100 mb-0.5"
        >
          {waveform.map((h, i) => {
            const barProgress = i / waveform.length;
            const isPlayed = barProgress <= progress;
            return (
              <motion.div 
                key={i} 
                initial={false}
                animate={{ 
                   height: `${Math.max(12, h * 10)}%`,
                   backgroundColor: isPlayed 
                      ? (isMe ? "#ffffff" : "#007AFF") 
                      : (isMe ? "rgba(255,255,255,0.4)" : "rgba(0,122,255,0.2)")
                }}
                transition={{ duration: 0.1 }}
                className="flex-1 rounded-full min-w-[2px]"
              />
            );
          })}
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className={cn(
              "text-[11px] font-medium tracking-wide tabular-nums",
              isMe ? "text-white/90" : "text-gray-500"
            )}>
              {isPlaying ? currentTime : (msg.audioDuration || '0:00')}
            </span>
            {isPlaying && (
              <button 
                onClick={toggleSpeed}
                className={cn(
                  "text-[9px] font-bold px-1.5 py-[1px] rounded-full transition-colors",
                  isMe ? "bg-white/20 text-white" : "bg-blue-50 text-blue-600"
                )}
              >
                {playbackRate}x
              </button>
            )}
          </div>
          
          <div className={cn("flex items-center justify-end gap-1 select-none", isMe ? "text-white/80" : "text-gray-400")}>
            <span className="text-[10px] font-medium leading-none tabular-nums">{msg.time}</span>
            <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} />
          </div>
        </div>
      </div>
    </div>
  );
};
