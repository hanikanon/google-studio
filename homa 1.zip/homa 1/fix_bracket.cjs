const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const target = `                    </div>\n                  {/* Image Message */}`;
const replacement = `                    </div>\n                  )}\n                  {/* Image Message */}`;

if (content.includes(target)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(target, replacement));
  console.log("Fixed bracket.");
} else {
  console.log("Could not find target block to replace!");
}
