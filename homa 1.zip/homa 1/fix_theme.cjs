const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

content = content.replace(`className={cn("absolute inset-0 z-50 flex flex-col w-full h-full", chatTheme === "dark" ? "bg-gray-900" : (chatWallpaper || "bg-[#e4e2de]"))}`, `className={cn("absolute inset-0 z-50 flex flex-col w-full h-full dark:bg-black", chatWallpaper || "bg-[#e4e2de]")}`);
content = content.replace(`        chatTheme === 'dark' ? 'bg-[#1c1c1d] border-b border-gray-800' : 'bg-white border-b border-black/5'`, `        'bg-white dark:bg-[#1c1c1d] border-b border-black/5 dark:border-gray-800'`);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Fixed MessagesPage theme classes");
