const fs = require('fs');
let content = fs.readFileSync('src/useAudioRecorder.ts', 'utf8');

content = content.replace(
  `          let mimeType = mediaRecorder.current?.mimeType;
          if (!mimeType) {
              mimeType = typeof MediaRecorder.isTypeSupported === 'function' && MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4';
          }
          const audioBlob = new Blob(audioChunks.current, { type: mimeType });`,
  `          const mimeType = audioChunks.current[0]?.type || mediaRecorder.current?.mimeType || 'audio/webm';
          const audioBlob = new Blob(audioChunks.current, { type: mimeType });`
);

fs.writeFileSync('src/useAudioRecorder.ts', content);
console.log('Fixed useAudioRecorder');
