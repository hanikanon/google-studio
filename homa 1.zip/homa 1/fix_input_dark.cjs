const fs = require('fs');
let content = fs.readFileSync('src/components/MessageInput.tsx', 'utf8');

const targetStr = `                  className="flex-1 bg-transparent border-none outline-none text-[16px] text-gray-900 placeholder-gray-400 py-[11px] px-1 resize-none max-h-32 overflow-y-auto leading-tight"`;
const replacement = `                  className="flex-1 bg-transparent border-none outline-none text-[16px] text-gray-900 dark:text-white placeholder-gray-400 py-[11px] px-1 resize-none max-h-32 overflow-y-auto leading-tight"`;

content = content.replace(targetStr, replacement);

const targetStr2 = `                  <span className="text-[15px] font-medium text-gray-900 tabular-nums min-w-[36px]">`;
const replacement2 = `                  <span className="text-[15px] font-medium text-gray-900 dark:text-white tabular-nums min-w-[36px]">`;

content = content.replace(targetStr2, replacement2);

fs.writeFileSync('src/components/MessageInput.tsx', content);
console.log("Fixed Input Dark Mode");
