const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

content = content.replace(
  '<div className="bg-transparent shrink-0 relative z-20 pb-[calc(env(safe-area-inset-bottom)+8px)]">',
  '<div className="bg-transparent shrink-0 relative z-20 pb-[env(safe-area-inset-bottom)]">'
);

content = content.replace(
  '<div className="flex flex-col z-30 relative px-2 py-1.5">',
  '<div className="flex flex-col z-30 relative">'
);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Fixed Composer Padding");
