const fs = require('fs');
let content = fs.readFileSync('src/components/MessageInput.tsx', 'utf8');

const oldStructure = `      <div className="px-2 py-1.5 flex items-end gap-1.5 relative z-10">
      <div className={cn("flex-1 bg-white dark:bg-[#1c1c1d] rounded-[24px] flex items-end px-1 shadow-sm border border-black/5 dark:border-white/10 min-h-[44px] transition-all relative overflow-visible", (isRecording || isLocked) ? "bg-[#f5f6f8] dark:bg-white/5" : "")}>
        <div className="flex-1 flex items-end relative overflow-hidden h-full">`;

// I will look at where the second div closes. 
// It closes around line 310.
