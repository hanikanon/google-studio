const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const oldBlock = `                </motion.div>
                                  {msg.reactions && msg.reactions.length > 0 && (
                    <div className={cn("absolute -bottom-3 flex flex-wrap gap-1 z-30 px-2 pointer-events-none", isMe ? "right-0 justify-end" : "left-0 justify-start")}>
                      <AnimatePresence>
                      {msg.reactions.map((r) => (
                        <motion.button 
                           key={r.emoji}
                           
                           initial={{ scale: 0.3, opacity: 0, y: 15 }}
                           animate={{ scale: 1, opacity: 1, y: 0, transition: { type: 'spring', stiffness: 450, damping: 18, mass: 0.8 } }}
                           exit={{ scale: 0.6, opacity: 0, y: 10, transition: { duration: 0.15 } }}
                           whileTap={{ scale: 0.9 }}
                           onClick={(e) => { e.stopPropagation(); handleReaction(msg.id, r.emoji, e); }}
                           className={cn("pointer-events-auto px-1.5 py-[3px] rounded-full flex items-center gap-1 text-[12px] font-medium shadow-[0_2px_4px_rgba(0,0,0,0.12)] border backdrop-blur-md active:scale-95 hover:shadow-[0_4px_8px_rgba(0,0,0,0.1)] transition-all", r.userReacted ? (isMe ? "bg-[#3390ec] border-white text-white" : "bg-blue-50 border-blue-100 text-blue-600") : "bg-white/95 border-gray-100 text-gray-700")}
                        >
                           <motion.span 
                              key={r.count + (r.userReacted ? 'u' : 'n')}
                              initial={{ scale: 0.5 }}
                              animate={{ scale: 1 }}
                              transition={{ type: 'spring', stiffness: 500, damping: 12, mass: 0.5 }}
                              className="mt-[1px] inline-block origin-center"
                           >
                             {r.emoji}
                           </motion.span>
                           {r.count > 1 && <span className="text-[11px] font-semibold">{r.count}</span>}
                        </motion.button>
                      ))}
                      </AnimatePresence>
                    </div>
                  )}
              </motion.div>`;

const newBlock = `                  {msg.reactions && msg.reactions.length > 0 && (
                    <div className={cn("absolute -bottom-3 flex flex-wrap gap-1 z-30 px-2 pointer-events-none", isMe ? "right-0 justify-end" : "left-0 justify-start")}>
                      <AnimatePresence>
                      {msg.reactions.map((r) => (
                        <motion.button 
                           key={r.emoji}
                           
                           initial={{ scale: 0.3, opacity: 0, y: 15 }}
                           animate={{ scale: 1, opacity: 1, y: 0, transition: { type: 'spring', stiffness: 450, damping: 18, mass: 0.8 } }}
                           exit={{ scale: 0.6, opacity: 0, y: 10, transition: { duration: 0.15 } }}
                           whileTap={{ scale: 0.9 }}
                           onClick={(e) => { e.stopPropagation(); handleReaction(msg.id, r.emoji, e); }}
                           className={cn("pointer-events-auto px-1.5 py-[3px] rounded-full flex items-center gap-1 text-[12px] font-medium shadow-[0_2px_4px_rgba(0,0,0,0.12)] border backdrop-blur-md active:scale-95 hover:shadow-[0_4px_8px_rgba(0,0,0,0.1)] transition-all", r.userReacted ? (isMe ? "bg-[#3390ec] border-white text-white" : "bg-blue-50 border-blue-100 text-blue-600") : "bg-white/95 border-gray-100 text-gray-700")}
                        >
                           <motion.span 
                              key={r.count + (r.userReacted ? 'u' : 'n')}
                              initial={{ scale: 0.5 }}
                              animate={{ scale: 1 }}
                              transition={{ type: 'spring', stiffness: 500, damping: 12, mass: 0.5 }}
                              className="mt-[1px] inline-block origin-center"
                           >
                             {r.emoji}
                           </motion.span>
                           {r.count > 1 && <span className="text-[11px] font-semibold">{r.count}</span>}
                        </motion.button>
                      ))}
                      </AnimatePresence>
                    </div>
                  )}
                </motion.div>
              </motion.div>`;

if (content.includes(oldBlock)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(oldBlock, newBlock));
  console.log("Fixed reactions position.");
} else {
  console.log("Could not find old block!");
}
