const fs = require('fs');
let content = fs.readFileSync('src/components/messages/MessageMenu.tsx', 'utf8');

const targetStr = `    <motion.div 
      layout 
      className="w-48 bg-white/95 dark:bg-[#1c1c1d]/95 backdrop-blur-xl border border-black/5 dark:border-white/10 rounded-[14px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_16px_40px_rgba(0,0,0,0.3)] flex flex-col overflow-hidden py-1"
    >`;
    
const replacement = `    <motion.div 
      layout 
      className="w-56 bg-white/95 dark:bg-[#232324]/95 backdrop-blur-xl border border-black/5 dark:border-white/10 rounded-[16px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_16px_40px_rgba(0,0,0,0.3)] flex flex-col overflow-hidden py-1.5"
    >`;

content = content.replace(targetStr, replacement);

const targetStr2 = `              className={cn(
                "w-full flex items-center gap-3 px-3.5 py-2 transition-colors active:bg-black/5 dark:active:bg-white/5", 
                item.isRemove ? "text-[#FF453A]" : "text-gray-900 dark:text-white"
              )}`;

const replacement2 = `              className={cn(
                "w-full flex items-center gap-4 px-4 py-2.5 transition-colors active:bg-black/5 dark:active:bg-white/5", 
                item.isRemove ? "text-[#FF3B30]" : "text-gray-900 dark:text-[#E5E5EA]"
              )}`;

content = content.replace(targetStr2, replacement2);

const targetStr3 = `<span className="text-[14px] font-medium leading-none">{item.label}</span>`;
const replacement3 = `<span className="text-[15px] font-medium leading-none">{item.label}</span>`;
content = content.replace(targetStr3, replacement3);

const targetStr4 = `    { id: 'more', icon: <MoreHorizontal className="w-[18px] h-[18px]" />, label: 'More' }`;
const replacement4 = `    { id: 'more', icon: <MoreHorizontal className="w-[20px] h-[20px]" />, label: 'More' }`;
content = content.replace(targetStr4, replacement4);

const targetStr5 = `className="w-[18px] h-[18px]"`;
const replacement5 = `className="w-[20px] h-[20px]"`;
content = content.replaceAll(targetStr5, replacement5);

fs.writeFileSync('src/components/messages/MessageMenu.tsx', content);
console.log("Fixed MessageMenu");
