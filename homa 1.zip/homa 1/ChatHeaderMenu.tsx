import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Search, BellOff, Bell, Pin, Star, Image as ImageIcon, Video, FileText, Mic, Link2, Folder, Palette, Settings, MoreHorizontal, ArrowLeft } from 'lucide-react';
import { cn } from '../../utils';

interface ChatHeaderMenuProps {
  isMuted: boolean;
  isPinned: boolean;
  onAction: (action: string) => void;
  onClose: () => void;
}

export const ChatHeaderMenu: React.FC<ChatHeaderMenuProps> = ({ isMuted, isPinned, onAction, onClose }) => {
  const [isMore, setIsMore] = useState(false);

  const primaryActions = [
    { id: 'profile', icon: <User className="w-[18px] h-[18px]" />, label: 'View Profile' },
    { id: 'search', icon: <Search className="w-[18px] h-[18px]" />, label: 'Search' },
    { id: 'mute', icon: isMuted ? <BellOff className="w-[18px] h-[18px]" /> : <Bell className="w-[18px] h-[18px]" />, label: isMuted ? 'Unmute' : 'Mute' },
    { id: 'pin', icon: <Pin className="w-[18px] h-[18px]" />, label: isPinned ? 'Unpin Chat' : 'Pin Chat' },
    { id: 'favorites', icon: <Star className="w-[18px] h-[18px]" />, label: 'Favorites' },
    { id: 'more', icon: <MoreHorizontal className="w-[18px] h-[18px]" />, label: 'More' }
  ];

  const moreActions = [
    { id: 'photos', icon: <ImageIcon className="w-[18px] h-[18px]" />, label: 'Photos' },
    { id: 'videos', icon: <Video className="w-[18px] h-[18px]" />, label: 'Videos' },
    { id: 'documents', icon: <FileText className="w-[18px] h-[18px]" />, label: 'Documents' },
    { id: 'voice', icon: <Mic className="w-[18px] h-[18px]" />, label: 'Voice' },
    { id: 'links', icon: <Link2 className="w-[18px] h-[18px]" />, label: 'Links' },
    { id: 'files', icon: <Folder className="w-[18px] h-[18px]" />, label: 'Shared Files' },
    { id: 'wallpaper', icon: <ImageIcon className="w-[18px] h-[18px]" />, label: 'Wallpaper' },
    { id: 'theme', icon: <Settings className="w-[18px] h-[18px]" />, label: 'Theme' },
    { id: 'back', icon: <ArrowLeft className="w-[18px] h-[18px]" />, label: 'Back' }
  ];

  const actions = isMore ? moreActions : primaryActions;

  return (
    <>
      <motion.div 
        initial={{opacity:0}} 
        animate={{opacity:1}} 
        exit={{opacity:0}} 
        className="fixed inset-0 w-screen h-screen z-40 cursor-default touch-none" 
        onClick={onClose} 
      />
      <motion.div
        layout
        initial={{ opacity: 0, scale: 0.95, transformOrigin: 'top right' }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.15 }}
        className="absolute right-0 top-12 w-52 bg-[#1c1c1d]/95 backdrop-blur-xl rounded-[20px] shadow-[0_16px_40px_rgba(0,0,0,0.3)] py-1 z-50 border border-white/10 overflow-hidden flex flex-col"
      >
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={isMore ? 'more' : 'main'}
            initial={{ x: isMore ? 20 : -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: isMore ? -20 : 20, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 400 }}
            className="flex flex-col"
          >
            {actions.map((item: any, i) => (
              <button
                key={item.id}
                className="w-full flex items-center justify-between px-4 py-[9px] text-white hover:bg-white/5 transition-colors"
                onClick={(e) => { 
                  e.stopPropagation();
                  if (item.id === 'more') {
                    setIsMore(true);
                  } else if (item.id === 'back') {
                    setIsMore(false);
                  } else {
                    onAction(item.id);
                  }
                }}
              >
                <span className="text-[15px] font-medium">{item.label}</span>
                <div>{item.icon}</div>
              </button>
            ))}
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </>
  );
};
