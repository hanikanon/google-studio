const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(`className="relative w-full h-screen bg-black overflow-hidden text-gray-900 font-sans selection:bg-transparent"`, `className="relative w-full h-screen bg-black overflow-hidden text-gray-900 dark:text-gray-100 font-sans selection:bg-transparent"`);
content = content.replace(`className="w-full h-full absolute inset-0 bg-white z-10"`, `className="w-full h-full absolute inset-0 bg-white dark:bg-[#111111] z-10"`);

fs.writeFileSync('src/App.tsx', content);
console.log("Fixed App theme classes");
