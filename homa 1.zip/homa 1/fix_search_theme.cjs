const fs = require('fs');
let content = fs.readFileSync('src/components/SearchOverlay.tsx', 'utf8');

content = content.replace(
  `bg-white flex flex-col`,
  `bg-white dark:bg-[#111111] flex flex-col`
);

content = content.replace(
  `border-b border-gray-100 shadow-sm`,
  `border-b border-gray-100 dark:border-white/5 shadow-sm`
);

content = content.replace(
  `hover:text-indigo-600 hover:bg-gray-100`,
  `hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-100 dark:hover:bg-gray-800`
);

content = content.replace(
  `bg-gray-100 rounded-full px-4 h-10`,
  `bg-gray-100 dark:bg-[#1c1c1d] rounded-full px-4 h-10`
);

content = content.replace(
  `text-[15px] text-gray-900 placeholder-gray-500`,
  `text-[15px] text-gray-900 dark:text-gray-100 placeholder-gray-500`
);

content = content.replace(
  `hover:bg-gray-200 rounded-full text-gray-500`,
  `hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full text-gray-500 dark:text-gray-400`
);

content = content.replace(
  `bg-gray-100 rounded-full flex items-center justify-center mb-3`,
  `bg-gray-100 dark:bg-[#1c1c1d] rounded-full flex items-center justify-center mb-3`
);

content = content.replace(
  `text-[17px] font-semibold text-gray-900`,
  `text-[17px] font-semibold text-gray-900 dark:text-gray-100`
);

fs.writeFileSync('src/components/SearchOverlay.tsx', content);
console.log("Fixed SearchOverlay theme classes");
