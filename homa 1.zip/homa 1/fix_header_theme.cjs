const fs = require('fs');
let content = fs.readFileSync('src/components/Header.tsx', 'utf8');

content = content.replace(
  `"absolute top-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-xl pt-[max(env(safe-area-inset-top),8px)] shadow-[0_1px_4px_rgba(0,0,0,0.03)]"`, 
  `"absolute top-0 left-0 right-0 z-30 bg-white/95 dark:bg-[#111111]/95 backdrop-blur-xl pt-[max(env(safe-area-inset-top),8px)] shadow-[0_1px_4px_rgba(0,0,0,0.03)] dark:border-b dark:border-white/5"`
);

content = content.replace(
  `text-[#262626]`, 
  `text-[#262626] dark:text-gray-100`
);

content = content.replace(
  `"text-gray-500 hover:bg-gray-100/80 bg-gray-50/50"`,
  `"text-gray-500 dark:text-gray-400 hover:bg-gray-100/80 dark:hover:bg-gray-800/80 bg-gray-50/50 dark:bg-gray-800/50"`
);

content = content.replace(
  `"bg-gray-200/60 text-gray-500"`,
  `"bg-gray-200/60 dark:bg-gray-700/60 text-gray-500 dark:text-gray-400"`
);

fs.writeFileSync('src/components/Header.tsx', content);
console.log("Fixed Header theme classes");
