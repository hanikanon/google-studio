const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

content = content.replace(
  '                <motion.div \n                  drag="x"',
  '                <motion.div \n                  id={`msg-${msg.id}`}\n                  drag="x"'
);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log('Fixed message id');
