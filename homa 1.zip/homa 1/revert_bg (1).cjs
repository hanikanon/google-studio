const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

// Revert the background change
content = content.replace(
  `className={cn("absolute inset-0 z-50 flex flex-col w-full h-full dark:bg-black", chatWallpaper || "bg-[#e4e2de]")}`,
  `className={cn("absolute inset-0 z-50 flex flex-col w-full h-full", chatTheme === "dark" ? "bg-[#0f0f0f]" : (chatWallpaper || "bg-[#e4e2de]"))}`
);

// Also revert the top bar theme to use chatTheme if needed, or stick to dark classes if they want system theme?
// Wait, the user said "6. Dark Mode and Light Mode: The UI must automatically follow the phone system theme: If the phone is in dark mode, use a professional dark interface."
// So relying on `dark:` classes (which follow the system preference if configured so) is good, BUT they also have a "Theme" button in the menu. 
// If they have a theme button, we should respect \`chatTheme\` or \`dark:\` properly. Let's stick to their existing \`chatTheme\` for the background.

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Reverted background");
