const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `      {/* Native Telegram-style App Bar */}
      <div className={cn(
        "z-50 shrink-0 relative flex flex-col w-full",
        'bg-white dark:bg-[#1c1c1d]'
      )}>
        <div className="flex items-center h-[56px] px-1 gap-1">
          {showSearch ? (
            <div className="flex items-center w-full px-2 gap-2 h-full">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-gray-500 dark:text-gray-400">
                <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[17px] font-medium text-gray-900 dark:text-white placeholder:text-gray-400"
              />
            </div>
          ) : (
            <>
              <button 
                onClick={onBack}
                className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors active:bg-black/10 shrink-0 text-gray-600 dark:text-gray-300"
              >
                <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
              </button>
              
              <div className="flex items-center gap-2.5 flex-1 min-w-0 h-[48px] py-1 cursor-pointer rounded-xl hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 px-1.5 transition-colors" onClick={() => setShowProfile(true)}>
                <div className="relative shrink-0">
                  <div className={cn(
                    "w-10 h-10 rounded-full overflow-hidden flex items-center justify-center relative",
                    chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200 dark:bg-gray-700"
                  )}>
                    {chat.avatarType === 'image' ? (
                      <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                    ) : null}
                  </div>
                  {chat.isOnline && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#22c55e] border-[2px] border-white dark:border-[#1c1c1d] rounded-full z-20"></div>
                  )}
                </div>
                
                <div className="flex flex-col justify-center min-w-0 pb-0.5">
                  <span className="font-semibold text-[17px] text-gray-900 dark:text-white leading-[1.2] tracking-tight flex items-center gap-1.5 truncate">
                    <span className="truncate">{chat.name}</span>
                    {isMuted && <BellOff className="w-[14px] h-[14px] text-gray-400 shrink-0" />}
                    {isPinned && <Pin className="w-[14px] h-[14px] text-gray-400 fill-gray-400 shrink-0" />}
                  </span>
                  <span className="text-[13px] text-gray-500 dark:text-gray-400 leading-[1.2] mt-[2px] tracking-wide truncate">
                    {isTyping ? <span className="text-[#007AFF] font-medium">typing...</span> : (chat.isOnline ? <span className="text-[#007AFF]">online</span> : 'last seen recently')}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center shrink-0 pr-1">
                <button onClick={() => handleCall(true)} className={cn("w-10 h-10 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors active:bg-black/10 text-gray-600 dark:text-gray-300", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[22px] h-[22px]" strokeWidth={2} />
                </button>
                <button onClick={() => handleCall(false)} className={cn("w-10 h-10 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors active:bg-black/10 text-gray-600 dark:text-gray-300", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[22px] h-[22px]" strokeWidth={2} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors active:bg-black/10 text-gray-600 dark:text-gray-300">
                    <MoreVertical className="w-[22px] h-[22px]" strokeWidth={2} />
                  </button>`;

const replacement = `      {/* Native Telegram-style App Bar */}
      <div className="z-50 shrink-0 relative flex items-center justify-between w-full h-[52px] bg-white dark:bg-[#1c1c1d]">
          {showSearch ? (
            <div className="flex items-center w-full px-1 gap-2 h-full">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors shrink-0 text-gray-500 dark:text-gray-400">
                <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[17px] font-medium text-gray-900 dark:text-white placeholder:text-gray-400"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-1.5 flex-1 min-w-0 h-full">
                <button 
                  onClick={onBack}
                  className="w-[42px] h-[42px] ml-0.5 rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors shrink-0 text-gray-600 dark:text-gray-300"
                >
                  <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
                </button>
                
                <div className="flex items-center gap-2.5 flex-1 min-w-0 h-[44px] cursor-pointer rounded-full hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors pr-3 pl-1" onClick={() => setShowProfile(true)}>
                  <div className="relative shrink-0">
                    <div className={cn(
                      "w-[38px] h-[38px] rounded-full overflow-hidden flex items-center justify-center relative",
                      chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200 dark:bg-gray-700"
                    )}>
                      {chat.avatarType === 'image' ? (
                        <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                      ) : null}
                    </div>
                    {chat.isOnline && (
                      <div className="absolute bottom-[-1px] right-[-1px] w-[13px] h-[13px] bg-[#22c55e] border-[2.5px] border-white dark:border-[#1c1c1d] rounded-full z-20"></div>
                    )}
                  </div>
                  
                  <div className="flex flex-col justify-center min-w-0">
                    <span className="font-semibold text-[17px] text-gray-900 dark:text-white leading-[20px] tracking-tight flex items-center gap-1.5 truncate">
                      <span className="truncate">{chat.name}</span>
                      {isMuted && <BellOff className="w-[14px] h-[14px] text-gray-400 shrink-0" />}
                      {isPinned && <Pin className="w-[14px] h-[14px] text-gray-400 fill-gray-400 shrink-0" />}
                    </span>
                    <span className="text-[13.5px] text-gray-500 dark:text-gray-400 leading-[16px] truncate tracking-wide mt-0.5">
                      {isTyping ? <span className="text-[#007AFF] font-medium">typing...</span> : (chat.isOnline ? <span className="text-[#007AFF]">online</span> : 'last seen recently')}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center shrink-0 pr-0.5 gap-0.5">
                <button onClick={() => handleCall(true)} className={cn("w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors text-gray-600 dark:text-gray-300", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[24px] h-[24px]" strokeWidth={1.8} />
                </button>
                <button onClick={() => handleCall(false)} className={cn("w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors text-gray-600 dark:text-gray-300", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[22px] h-[22px]" strokeWidth={1.8} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="w-[42px] h-[42px] rounded-full flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 transition-colors text-gray-600 dark:text-gray-300">
                    <MoreVertical className="w-[24px] h-[24px]" strokeWidth={1.8} />
                  </button>`;

if (content.includes("Native Telegram-style App Bar")) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed App Bar");
} else {
  console.log("Not found");
}
