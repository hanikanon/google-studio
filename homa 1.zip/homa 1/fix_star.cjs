const fs = require('fs');
let content = fs.readFileSync('src/components/MessageIndicators.tsx', 'utf8');

const targetStr = `        {isSaved && (
          <motion.div
            key="saved"
            initial={{ scale: 0, rotate: -45, opacity: 0, filter: 'drop-shadow(0 0 0px rgba(245,158,11,0))' }}
            animate={{ 
               scale: [0, 1.4, 1], 
               rotate: [-45, 10, 0], 
               opacity: 1,
              filter: [
                'drop-shadow(0 0 0px rgba(245,158,11,0))', 
                'drop-shadow(0 0 12px rgba(245,158,11,0.9))', 
                'drop-shadow(0 0 2px rgba(245,158,11,0.3))'
              ]
            }}
            transition={{ duration: 0.5, times: [0, 0.6, 1], ease: "easeOut" }}
            exit={{ scale: 0, rotate: 45, opacity: 0, transition: { duration: 0.2 } }}
            className={cn("flex items-center justify-center relative origin-center", isImageOverlay ? "text-white drop-shadow-md" : "text-amber-500")}
          >
            <Star className={cn("fill-current z-10", isImageOverlay ? "w-3 h-3" : "w-[13px] h-[13px]")} strokeWidth={1.5} />
          </motion.div>
        )}`;

const newBlock = `        {isSaved && (
          <motion.div
            key="saved"
            initial={{ scale: 0.2, rotate: -30, opacity: 0 }}
            animate={{ scale: 1, rotate: 0, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 450, damping: 15, mass: 0.8 }}
            exit={{ scale: 0, opacity: 0, transition: { duration: 0.15 } }}
            className={cn("flex items-center justify-center relative origin-center", isImageOverlay ? "text-white drop-shadow-md" : "text-amber-500")}
          >
            <Star className={cn("fill-current z-10", isImageOverlay ? "w-3 h-3" : "w-[13px] h-[13px]")} strokeWidth={1.5} />
          </motion.div>
        )}`;

if (content.indexOf("key=\"saved\"") > -1) {
    // Just find and replace the block
    let startIndex = content.indexOf("{isSaved && (");
    let endIndex = content.indexOf(")}", content.indexOf("</motion.div>", startIndex)) + 2;
    content = content.substring(0, startIndex) + newBlock + content.substring(endIndex);
    fs.writeFileSync('src/components/MessageIndicators.tsx', content);
    console.log("Replaced star!");
}
