import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Paperclip, Mic, Send, Smile, Trash2, ArrowLeft, ArrowRight, Lock, X } from 'lucide-react';
import { cn } from '../utils';
import { useAudioRecorder } from '../useAudioRecorder';

interface MessageInputProps {
  selectedFiles: File[];
  setSelectedFiles: React.Dispatch<React.SetStateAction<File[]>>;
  onSendText: (text: string) => void;
  onSendAudio: (url: string, duration: number, waveform: number[]) => void;
  onSendMedia: (files: File[], caption?: string) => void;
  onAttachmentClick: () => void;
}

export const MessageInput: React.FC<MessageInputProps> = ({
  onSendText,
  onSendAudio,
  onSendMedia,
  onAttachmentClick,
  selectedFiles,
  setSelectedFiles,
}) => {
  const [inputText, setInputText] = useState('');
  const { isRecording, recordingDuration, liveWaveform, startRecording, stopRecording, cancelRecording } = useAudioRecorder();
  
  const [isHoldingMic, setIsHoldingMic] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const pointerStartX = useRef<number | null>(null);
  const pointerStartY = useRef<number | null>(null);
  const [slideOffsetX, setSlideOffsetX] = useState(0);
  const [slideOffsetY, setSlideOffsetY] = useState(0);

  const formatTime = (time: number) => {
    const m = Math.floor(time / 60);
    const s = Math.floor(time % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleSend = () => {
    if (selectedFiles.length > 0) {
      if (navigator.vibrate) navigator.vibrate(10);
      onSendMedia(selectedFiles, inputText.trim() || undefined);
      setSelectedFiles([]);
      setInputText('');
      return;
    }
    if (inputText.trim()) {
      if (navigator.vibrate) navigator.vibrate(10);
      onSendText(inputText.trim());
      setInputText('');
    }
  };
  
  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };
  const moveFile = (index: number, direction: 'left' | 'right') => {
    setSelectedFiles(prev => {
      const next = [...prev];
      if (direction === 'left' && index > 0) {
        [next[index - 1], next[index]] = [next[index], next[index - 1]];
      } else if (direction === 'right' && index < next.length - 1) {
        [next[index + 1], next[index]] = [next[index], next[index + 1]];
      }
      return next;
    });
  };

  const handleMicPointerDown = (e: React.PointerEvent) => {
    if (inputText.trim()) return; 
    e.preventDefault();
    e.stopPropagation();
    setIsHoldingMic(true);
    setIsLocked(false);
    setSlideOffsetX(0);
    setSlideOffsetY(0);
    pointerStartX.current = e.clientX;
    pointerStartY.current = e.clientY;
    
    if (navigator.vibrate) navigator.vibrate(15);
    startRecording();
  };

  const handleMicPointerMove = (e: React.PointerEvent) => {
    if (!isHoldingMic || isLocked) return;
    
    if (pointerStartX.current !== null && pointerStartY.current !== null) {
      const deltaX = e.clientX - pointerStartX.current;
      const deltaY = e.clientY - pointerStartY.current;
      
      if (deltaX < 0) {
        setSlideOffsetX(Math.max(deltaX, -150));
      }
      
      if (deltaY < 0) {
        setSlideOffsetY(Math.max(deltaY, -100));
      }
      
      if (deltaX < -100) {
        if (navigator.vibrate) navigator.vibrate([10, 50, 10]);
        cancelRecording();
        setIsHoldingMic(false);
        setSlideOffsetX(0);
        setSlideOffsetY(0);
        pointerStartX.current = null;
        pointerStartY.current = null;
        return;
      }
      
      if (deltaY < -80) {
        if (navigator.vibrate) navigator.vibrate(20);
        setIsLocked(true);
        setIsHoldingMic(false);
        setSlideOffsetX(0);
        setSlideOffsetY(0);
        pointerStartX.current = null;
        pointerStartY.current = null;
      }
    }
  };

  const handleMicPointerUp = async () => {
    if (isLocked) return;
    if (isHoldingMic) {
      setIsHoldingMic(false);
      setSlideOffsetX(0);
      setSlideOffsetY(0);
      pointerStartX.current = null;
      pointerStartY.current = null;
      
      const result = await stopRecording();
      if (result) {
        onSendAudio(result.url, result.duration, result.waveform);
      }
    }
  };

  const handleLockedSend = async () => {
    if (navigator.vibrate) navigator.vibrate(10);
    const result = await stopRecording();
    if (result) {
      onSendAudio(result.url, result.duration, result.waveform);
    }
    setIsLocked(false);
  };

  const handleLockedCancel = () => {
    if (navigator.vibrate) navigator.vibrate(10);
    cancelRecording();
    setIsLocked(false);
  };

  const isTextMode = inputText.trim().length > 0 || selectedFiles.length > 0;

  return (
    <div className="bg-transparent">
      <AnimatePresence>
        {selectedFiles.length > 0 && (
          <motion.div 
             initial={{ height: 0, opacity: 0 }} 
             animate={{ height: 'auto', opacity: 1 }} 
             exit={{ height: 0, opacity: 0 }}
             className="px-3 pt-3 pb-1 flex gap-2 overflow-x-auto no-scrollbar"
          >
            {selectedFiles.map((f, i) => (
              <div key={i + f.name} className="relative w-20 h-20 flex-shrink-0 rounded-xl overflow-hidden border border-gray-200 bg-white group">
                 {f.type.startsWith('image/') ? (
                   <img src={URL.createObjectURL(f)} alt="" className="w-full h-full object-cover" />
                 ) : (
                   <div className="w-full h-full bg-blue-50 flex items-center justify-center">
                     <span className="text-blue-500 text-[11px] font-medium">{f.type.startsWith('video/') ? 'Video' : 'File'}</span>
                   </div>
                 )}
                 <button onClick={() => removeFile(i)} className="absolute top-1 right-1 bg-black/50 hover:bg-black/70 rounded-full p-1 text-white transition-colors">
                   <X className="w-3 h-3" />
                 </button>
                 <div className="absolute bottom-0 inset-x-0 h-6 bg-gradient-to-t from-black/50 to-transparent flex items-end justify-between px-1 pb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => moveFile(i, 'left')} disabled={i === 0} className="text-white disabled:opacity-30"><ArrowLeft className="w-4 h-4" /></button>
                    <button onClick={() => moveFile(i, 'right')} disabled={i === selectedFiles.length - 1} className="text-white disabled:opacity-30"><ArrowRight className="w-4 h-4" /></button>
                 </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="px-2 py-1.5 flex items-end gap-1.5 relative z-10">
      <div className={cn("flex-1 bg-white dark:bg-[#1c1c1d] rounded-[24px] flex items-end px-1 shadow-sm border border-black/5 dark:border-white/10 min-h-[44px] transition-all relative overflow-visible", (isRecording || isLocked) ? "bg-[#f5f6f8] dark:bg-white/5" : "")}>
        <div className="flex-1 flex items-end relative overflow-hidden h-full">
          <AnimatePresence mode="wait">
            {(isRecording || isLocked) ? (
              <motion.div 
                key="recording"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="w-full flex items-center justify-between px-3 py-2.5 h-[44px]"
              >
                <div className="flex items-center gap-2">
                  <motion.div 
                    animate={{ opacity: [1, 0, 1] }} 
                    transition={{ repeat: Infinity, duration: 1.5 }}
                    className="w-2.5 h-2.5 rounded-full bg-red-500" 
                  />
                  <span className="text-[15px] font-medium text-gray-900 dark:text-white tabular-nums min-w-[36px]">
                    {formatTime(recordingDuration)}
                  </span>
                </div>
                
                {isLocked ? (
                  <div className="flex-1 flex items-center justify-end px-2 gap-[2px] h-full overflow-hidden mask-image-left">
                    {liveWaveform.map((w, i) => (
                      <motion.div key={i} className="w-[2px] rounded-full bg-blue-500" style={{ height: Math.max(4, w) + 'px' }} />
                    ))}
                  </div>
                ) : (
                  <motion.div animate={{ x: slideOffsetX }} className="flex items-center gap-1.5 text-gray-400 mr-2 opacity-70">
                    <ArrowLeft className="w-4 h-4" />
                    <span className="text-[14px]">Slide to cancel</span>
                  </motion.div>
                )}
                
                {isLocked && (
                  <button onClick={handleLockedCancel} className="p-1.5 text-red-500 hover:bg-red-50 rounded-full transition-colors shrink-0">
                    <Trash2 className="w-[18px] h-[18px]" />
                  </button>
                )}
              </motion.div>
            ) : (
              <motion.div key="input" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full flex items-end">
                <button className="p-2.5 mb-[1px] text-gray-400 hover:text-blue-500 transition-colors shrink-0">
                  <Smile className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                <textarea 
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Message"
                  rows={1}
                  className="flex-1 bg-transparent border-none outline-none text-[16px] text-gray-900 dark:text-white placeholder-gray-400 py-[11px] px-1 resize-none max-h-32 overflow-y-auto leading-tight"
                />
                <button onClick={onAttachmentClick} className="p-2.5 mb-[1px] text-gray-400 hover:text-blue-500 transition-colors shrink-0">
                  <Paperclip className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

        <div className="relative flex flex-col items-center justify-end shrink-0 bg-white dark:bg-[#1c1c1d] rounded-full shadow-sm border border-black/5 dark:border-white/10 w-[44px] h-[44px]">
          <AnimatePresence>
            {isHoldingMic && !isLocked && (
               <motion.div
                 initial={{ opacity: 0, y: 10 }}
                 animate={{ opacity: 1, y: slideOffsetY }}
                 exit={{ opacity: 0, scale: 0.8 }}
                 className="absolute bottom-[64px] bg-white rounded-full p-3 shadow-lg border border-gray-100 text-gray-400 flex flex-col items-center gap-1.5"
               >
                 <Lock className="w-4 h-4" />
               </motion.div>
            )}
          </AnimatePresence>
          <button 
            type="button"
            onPointerDown={isTextMode ? undefined : handleMicPointerDown}
            onPointerMove={isTextMode ? undefined : handleMicPointerMove}
            onPointerUp={isTextMode ? undefined : handleMicPointerUp}
            onPointerCancel={isTextMode ? undefined : handleMicPointerUp}
            onClick={(isTextMode || isLocked) ? (isLocked ? handleLockedSend : handleSend) : undefined}
            className={cn(
              "w-[44px] h-[44px] flex items-center justify-center transition-all touch-none select-none z-20 relative overflow-hidden",
              (isTextMode || isLocked) ? "text-[#007AFF] hover:opacity-80 active:scale-95" : "text-gray-400 hover:text-gray-600",
              (isHoldingMic && !isLocked) && "scale-[1.5] bg-[#007AFF] rounded-full text-white shadow-[0_8px_24px_rgba(0,122,255,0.4)] translate-y-[-20px]"
            )}
          >
            <AnimatePresence mode="popLayout" initial={false}>
              {(isTextMode || isLocked) ? (
                <motion.div
                  key="send"
                  initial={{ scale: 0.5, y: 10, opacity: 0 }}
                  animate={{ scale: 1, y: 0, opacity: 1 }}
                  exit={{ scale: 0.5, y: -10, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                  className="absolute inset-0 flex items-center justify-center origin-bottom"
                >
                  <Send className="w-[24px] h-[24px]" strokeWidth={2.2} />
                </motion.div>
              ) : (
                <motion.div
                  key="mic"
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.5, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                  className="absolute inset-0 flex items-center justify-center origin-bottom"
                >
                  <Mic className="w-[24px] h-[24px]" strokeWidth={2.2} />
                </motion.div>
              )}
            </AnimatePresence>
          </button>
        </div>
      </div>
    </div>
  );
};
