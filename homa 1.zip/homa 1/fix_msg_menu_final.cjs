const fs = require('fs');
let content = fs.readFileSync('src/components/messages/MessageMenu.tsx', 'utf8');

const replacement = `import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Copy, CornerUpLeft, CornerUpRight, Pin, Edit2, CheckSquare, Info, Trash2, MoreHorizontal, Globe, Image as ImageIcon, FileText, Settings, ArrowLeft } from 'lucide-react';
import { cn } from '../../utils';
import { Message } from '../../data';

interface MessageMenuProps {
  msg: Message;
  isMe: boolean;
  position: 'top' | 'bottom';
  onAction: (action: string) => void;
  onClose: () => void;
}

export const MessageMenu: React.FC<MessageMenuProps> = ({ msg, isMe, position, onAction, onClose }) => {
  const [isMoreOpen, setIsMoreOpen] = useState(false);

  const mainActions = [
    { id: 'reply', icon: <CornerUpLeft className="w-[18px] h-[18px]" />, label: 'Reply' },
    { id: 'forward', icon: <CornerUpRight className="w-[18px] h-[18px]" />, label: 'Forward' },
    { id: 'copy', icon: <Copy className="w-[18px] h-[18px]" />, label: 'Copy' },
    ...(isMe ? [{ id: 'edit', icon: <Edit2 className="w-[18px] h-[18px]" />, label: 'Edit' }] : []),
    { id: 'pin', icon: <Pin className="w-[18px] h-[18px]" />, label: msg.isPinned ? 'Unpin' : 'Pin' },
    { id: 'save', icon: <Star className="w-[18px] h-[18px]" />, label: msg.isSaved ? 'Unsave' : 'Save' },
    { id: 'select', icon: <CheckSquare className="w-[18px] h-[18px]" />, label: 'Select' },
    { id: 'delete', icon: <Trash2 className="w-[18px] h-[18px]" />, label: 'Delete', isRemove: true },
    { id: 'more', icon: <MoreHorizontal className="w-[18px] h-[18px]" />, label: 'More' }
  ];

  const moreActions = [
    { id: 'info', icon: <Info className="w-[18px] h-[18px]" />, label: 'Info' },
    { id: 'translate', icon: <Globe className="w-[18px] h-[18px]" />, label: 'Translate' },
    { id: 'media', icon: <ImageIcon className="w-[18px] h-[18px]" />, label: 'Media' },
    { id: 'files', icon: <FileText className="w-[18px] h-[18px]" />, label: 'Files' },
    { id: 'back', icon: <ArrowLeft className="w-[18px] h-[18px]" />, label: 'Back' }
  ];

  const actions = isMoreOpen ? moreActions : mainActions;

  return (
    <motion.div 
      layout 
      className="w-[180px] bg-white dark:bg-[#1c1c1d] rounded-[12px] shadow-[0_4px_24px_rgba(0,0,0,0.15)] dark:shadow-[0_4px_24px_rgba(0,0,0,0.4)] flex flex-col overflow-hidden"
    >
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.div
          key={isMoreOpen ? 'more' : 'main'}
          initial={{ x: isMoreOpen ? 20 : -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: isMoreOpen ? -20 : 20, opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 400 }}
          className="flex flex-col py-1"
        >
          {actions.map((item: any) => (
            <button
              key={item.id}
              className={cn(
                "w-full flex items-center justify-between px-3 py-2 transition-colors active:bg-black/5 dark:active:bg-white/5", 
                item.isRemove ? "text-[#FF3B30]" : "text-gray-900 dark:text-gray-200"
              )}
              onClick={(e) => { 
                e.stopPropagation(); 
                if (item.id === 'more') {
                  setIsMoreOpen(true);
                } else if (item.id === 'back') {
                  setIsMoreOpen(false);
                } else {
                  onAction(item.id); 
                }
              }}
            >
              <span className="text-[14px] font-medium leading-none">{item.label}</span>
              <div className="shrink-0 opacity-70">{item.icon}</div>
            </button>
          ))}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
};`;

fs.writeFileSync('src/components/messages/MessageMenu.tsx', replacement);
console.log("Fixed msg menu");
