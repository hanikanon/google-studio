const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const oldSaveAction = /if \(action === 'save'\) setMessages\(messages\.map\(m => m\.id === msg\.id \? \{ \.\.\.m, isSaved: !m\.isSaved \} : m\)\);/g;

const newSaveAction = `if (action === 'save') {
                             const isSaving = !msg.isSaved;
                             setMessages(messages.map(m => m.id === msg.id ? { ...m, isSaved: !m.isSaved } : m));
                             if (isSaving) {
                               const el = document.getElementById(\`msg-\${msg.id}\`);
                               if (el) {
                                  const rect = el.getBoundingClientRect();
                                  const basePathX = rect.left + rect.width / 2;
                                  const basePathY = rect.top + rect.height / 2;
                                  
                                  const newParticles = [];
                                  newParticles.push({ id: Date.now(), emoji: '⭐', x: basePathX, y: basePathY, scale: 2.5, offsetX: 0 });
                                  for(let i=0; i<12; i++) {
                                    newParticles.push({ 
                                      id: Date.now() + i + 1, 
                                      emoji: '⭐', 
                                      x: basePathX, 
                                      y: basePathY, 
                                      scale: 0.5 + Math.random() * 0.8,
                                      offsetX: (Math.random() - 0.5) * 160
                                    });
                                  }
                                  setFlyingEmojis(prev => [...prev, ...newParticles]);
                                  setTimeout(() => {
                                    const idsToRemove = newParticles.map(p => p.id);
                                    setFlyingEmojis(prev => prev.filter(e => !idsToRemove.includes(e.id)));
                                  }, 2000);
                               }
                             }
                           }`;

if (content.includes("if (action === 'save') setMessages(messages.map(m => m.id === msg.id ? { ...m, isSaved: !m.isSaved } : m));")) {
    content = content.replace(oldSaveAction, newSaveAction);
    fs.writeFileSync('src/components/MessagesPage.tsx', content);
    console.log('Fixed save star');
} else {
    console.log('Could not find old save action to replace. Found:');
    const match = content.match(/if \(action === 'save'\).*?\n/);
    if (match) {
        console.log(match[0]);
    } else {
        console.log("No save action found");
    }
}
