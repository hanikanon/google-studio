const fs = require('fs');
let content = fs.readFileSync('src/components/AttachmentMenu.tsx', 'utf8');

const targetStr = `<div className="w-full flex-1 flex flex-col h-[320px]">
              {/* Fake Gallery area */}
              <div className="flex-1 px-2 pb-4 overflow-hidden flex flex-col">
                <div className="flex items-center justify-between px-2 mb-2">
                  <span className="text-[15px] font-medium text-gray-800 dark:text-gray-200">Recent</span>
                </div>
                <div className="flex-1 flex gap-1 overflow-x-auto hide-scrollbar px-2 pb-2">
                  {[1,2,3,4,5].map((img, idx) => (
                    <div key={idx} className="w-[110px] shrink-0 h-full bg-gray-200 dark:bg-gray-800 rounded-[10px] overflow-hidden flex items-center justify-center relative">
                      <ImageIcon className="w-8 h-8 text-gray-400 dark:text-gray-600 opacity-50" />
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="w-full bg-white dark:bg-[#1c1c1d] pb-safe border-t border-black/5 dark:border-white/5 pt-1">
                <div className="flex overflow-x-auto hide-scrollbar px-3 py-3 gap-1">
                  {items.map((item, i) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.02, type: 'spring', stiffness: 400, damping: 25 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        if (navigator.vibrate) navigator.vibrate(10);
                        onSelect(item.id);
                      }}
                      className="flex flex-col items-center gap-1.5 outline-none w-[70px] shrink-0 active:bg-black/5 dark:active:bg-white/5 rounded-xl py-1.5 transition-colors"
                    >
                      <div className={cn("w-[50px] h-[50px] rounded-full flex items-center justify-center text-white shadow-sm", item.bg)}>
                        <item.icon className="w-[22px] h-[22px]" strokeWidth={2} />
                      </div>
                      <span className="text-[12px] font-medium text-gray-700 dark:text-gray-300 tracking-tight leading-none">{item.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>`;

const replacement = `<div className="w-full flex flex-col">
              {/* Fake Gallery area */}
              <div className="w-full px-1 overflow-hidden flex flex-col mb-1">
                <div className="flex items-center justify-between px-3 mb-2">
                  <span className="text-[14px] font-semibold text-gray-800 dark:text-gray-200">Recent Media</span>
                </div>
                <div className="w-full flex gap-1.5 overflow-x-auto hide-scrollbar px-3 pb-2">
                  {[1,2,3,4,5,6].map((img, idx) => (
                    <div key={idx} className="w-[100px] h-[140px] shrink-0 bg-gray-100 dark:bg-gray-800/50 rounded-[8px] overflow-hidden flex flex-col items-center justify-center relative border border-black/5 dark:border-white/5">
                      <ImageIcon className="w-8 h-8 text-gray-400 dark:text-gray-600 opacity-50 mb-1" />
                      <span className="text-[10px] text-gray-400 font-medium">Image {idx+1}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="w-full bg-white dark:bg-[#1c1c1d] border-t border-black/5 dark:border-white/5 pt-3 pb-2">
                <div className="flex flex-wrap justify-center gap-x-3 gap-y-3 px-4">
                  {items.map((item, i) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.02, type: 'spring', stiffness: 400, damping: 25 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        if (navigator.vibrate) navigator.vibrate(10);
                        onSelect(item.id);
                      }}
                      className="flex flex-col items-center gap-1.5 outline-none w-[64px] shrink-0 active:opacity-70 transition-opacity"
                    >
                      <div className={cn("w-[48px] h-[48px] rounded-full flex items-center justify-center text-white shadow-sm", item.bg)}>
                        <item.icon className="w-[22px] h-[22px]" strokeWidth={2} />
                      </div>
                      <span className="text-[11px] font-medium text-gray-700 dark:text-gray-300 tracking-tight leading-none">{item.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>`;

if (content.includes("w-full flex-1 flex flex-col h-[320px]")) {
  fs.writeFileSync('src/components/AttachmentMenu.tsx', content.replace(targetStr, replacement));
  console.log("Fixed Attachment layout");
} else {
  console.log("Not found");
}
