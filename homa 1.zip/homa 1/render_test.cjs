require('ts-node').register({ transpileOnly: true, compilerOptions: { jsx: 'react-jsx', module: 'commonjs' } });
const React = require('react');
const ReactDOMServer = require('react-dom/server');
global.window = { navigator: { vibrate: () => {} }, innerHeight: 800, innerWidth: 600, addEventListener: () => {}, removeEventListener: () => {} };
global.document = { getElementById: () => null, createElement: () => ({}) };
global.navigator = global.window.navigator;
global.localStorage = { getItem: () => null, setItem: () => {} };
global.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
const App = require('./src/App.tsx').default;

try {
  const html = ReactDOMServer.renderToString(React.createElement(App));
  console.log("Render successful!");
} catch (e) {
  console.error("RENDER ERROR:", e);
}
