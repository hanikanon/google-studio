const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `      {/* Native Telegram-style App Bar */}
      <div className={cn(
        "z-50 shrink-0 relative flex flex-col w-full shadow-sm",
        'bg-white dark:bg-[#1c1c1d] border-b border-black/5 dark:border-gray-800'
      )}>
        <div className="flex items-center justify-between h-[56px] px-1">
          {showSearch ? (
            <div className="flex items-center w-full px-2 gap-3 h-full">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="p-2 text-gray-500 hover:bg-black/5 rounded-full transition-colors">
                <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2} />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search messages..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[16px] font-medium text-gray-900 dark:text-white placeholder:text-gray-400"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-1.5 flex-1 min-w-0 h-full">
                <button 
                  onClick={onBack}
                  className="p-2 text-gray-500 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10 mx-1"
                >
                  <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2} />
                </button>
                <div className="flex items-center gap-3 cursor-pointer flex-1 min-w-0 h-full" onClick={() => setShowProfile(true)}>
                  <div className="relative shrink-0">
                    <div className={cn(
                      "w-[40px] h-[40px] rounded-full overflow-hidden flex items-center justify-center relative shadow-sm border border-black/5",
                      chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200"
                    )}>
                      {chat.avatarType === 'image' ? (
                        <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                      ) : null}
                    </div>
                    {chat.isOnline && (
                      <div className="absolute bottom-0 right-0 w-[12px] h-[12px] bg-[#22c55e] border-[2px] border-white rounded-full z-20 dark:border-[#1c1c1d]"></div>
                    )}
                  </div>
                  <div className="flex flex-col justify-center min-w-0">
                    <span className="font-semibold text-[17px] text-gray-900 dark:text-white leading-tight tracking-tight flex items-center gap-1.5 truncate">
                      <span className="truncate">{chat.name}</span>
                      {isMuted && <BellOff className="w-[14px] h-[14px] text-gray-400 shrink-0" />}
                      {isPinned && <Pin className="w-[14px] h-[14px] text-gray-400 fill-gray-400 shrink-0" />}
                    </span>
                    <span className="text-[13px] text-gray-500 leading-tight mt-[1px] tracking-wide">
                      {isTyping ? <span className="text-[#007AFF] font-medium">typing...</span> : (chat.isOnline ? <span className="text-[#007AFF]">online</span> : 'last seen recently')}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center pr-1 shrink-0">
                <button onClick={() => handleCall(true)} className={cn("p-2.5 text-gray-500 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10 mx-0.5", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[24px] h-[24px]" strokeWidth={2} />
                </button>
                <button onClick={() => handleCall(false)} className={cn("p-2.5 text-gray-500 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10 mx-0.5", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[24px] h-[24px]" strokeWidth={2} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2.5 text-gray-500 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10 mx-0.5">
                    <MoreVertical className="w-[24px] h-[24px]" strokeWidth={2} />
                  </button>`;

const replacement = `      {/* Native Telegram-style App Bar */}
      <div className={cn(
        "z-50 shrink-0 relative flex flex-col w-full shadow-sm",
        'bg-white dark:bg-[#1c1c1d] border-b border-black/5 dark:border-white/5'
      )}>
        <div className="flex items-center justify-between h-[56px] pl-1 pr-2">
          {showSearch ? (
            <div className="flex items-center w-full px-2 gap-2 h-full">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="p-2 text-gray-500 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors">
                <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[17px] font-medium text-gray-900 dark:text-white placeholder:text-gray-400"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 flex-1 min-w-0 h-full">
                <button 
                  onClick={onBack}
                  className="w-12 h-12 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10 mx-0.5 shrink-0"
                >
                  <ArrowLeft className="w-[24px] h-[24px]" strokeWidth={2.2} />
                </button>
                <div className="flex items-center gap-3 cursor-pointer flex-1 min-w-0 h-full py-2" onClick={() => setShowProfile(true)}>
                  <div className="relative shrink-0">
                    <div className={cn(
                      "w-[42px] h-[42px] rounded-full overflow-hidden flex items-center justify-center relative",
                      chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200 dark:bg-gray-700"
                    )}>
                      {chat.avatarType === 'image' ? (
                        <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                      ) : null}
                    </div>
                    {chat.isOnline && (
                      <div className="absolute bottom-0 right-0 w-[12px] h-[12px] bg-[#22c55e] border-[2px] border-white dark:border-[#1c1c1d] rounded-full z-20"></div>
                    )}
                  </div>
                  <div className="flex flex-col justify-center min-w-0 pt-0.5">
                    <span className="font-semibold text-[17px] text-gray-900 dark:text-white leading-[1.2] tracking-tight flex items-center gap-1.5 truncate">
                      <span className="truncate">{chat.name}</span>
                      {isMuted && <BellOff className="w-[14px] h-[14px] text-gray-400 shrink-0" />}
                      {isPinned && <Pin className="w-[14px] h-[14px] text-gray-400 fill-gray-400 shrink-0" />}
                    </span>
                    <span className="text-[13.5px] text-gray-500 dark:text-gray-400 leading-[1.2] mt-[2px] tracking-wide">
                      {isTyping ? <span className="text-[#007AFF] font-medium">typing...</span> : (chat.isOnline ? <span className="text-[#007AFF]">online</span> : 'last seen recently')}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center pr-1 shrink-0 gap-0.5">
                <button onClick={() => handleCall(true)} className={cn("w-10 h-10 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[24px] h-[24px]" strokeWidth={2} />
                </button>
                <button onClick={() => handleCall(false)} className={cn("w-10 h-10 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[22px] h-[22px]" strokeWidth={2} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="w-10 h-10 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors active:bg-black/10">
                    <MoreVertical className="w-[24px] h-[24px]" strokeWidth={2} />
                  </button>`;

if (content.includes("Native Telegram-style App Bar")) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacement));
  console.log("Refined header");
} else {
  console.log("Target string not found!");
}
