const fs = require('fs');
let content = fs.readFileSync('src/components/messages/ReactionBar.tsx', 'utf8');

const oldBlock = `    <div className="flex items-center gap-1.5 px-3 py-2 bg-[#1c1c1d]/95 backdrop-blur-xl border border-white/10 rounded-[32px] shadow-[0_16px_40px_rgba(0,0,0,0.3)] max-w-[280px] overflow-x-auto hide-scrollbar shrink-0">
      {EMOJIS.map((emoji, i) => (
        <motion.button 
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: i * 0.03, type: 'spring', stiffness: 500, damping: 25 }}
          whileTap={{ scale: 0.8 }}
          key={i} 
          className="text-[26px] shrink-0 hover:scale-125 transition-transform origin-bottom" 
          onClick={(e) => { 
            e.stopPropagation(); 
            onReact(emoji); 
          }}
        >
          {emoji}
        </motion.button>
      ))}
    </div>`;

const newBlock = `    <motion.div 
      initial={{ opacity: 0, scale: 0.9, y: 5 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9, y: 5 }}
      transition={{ type: 'spring', damping: 25, stiffness: 400 }}
      className="flex items-center gap-1.5 px-3 py-1.5 bg-white/95 dark:bg-[#1c1c1d]/95 backdrop-blur-xl border border-black/5 dark:border-white/10 rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_16px_40px_rgba(0,0,0,0.3)] max-w-[280px] overflow-x-auto hide-scrollbar shrink-0"
    >
      {EMOJIS.map((emoji, i) => (
        <motion.button 
          initial={{ scale: 0, opacity: 0, y: 10 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{ delay: i * 0.02, type: 'spring', stiffness: 600, damping: 20 }}
          whileHover={{ scale: 1.25, transition: { duration: 0.2 } }}
          whileTap={{ scale: 0.8 }}
          key={i} 
          className="text-[24px] shrink-0 origin-bottom flex items-center justify-center p-1" 
          onClick={(e) => { 
            e.stopPropagation(); 
            onReact(emoji); 
          }}
        >
          {emoji}
        </motion.button>
      ))}
    </motion.div>`;

if (content.includes(oldBlock)) {
  fs.writeFileSync('src/components/messages/ReactionBar.tsx', content.replace(oldBlock, newBlock));
  console.log("Fixed ReactionBar style.");
} else {
  console.log("Could not find old ReactionBar block!");
}
