const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const importTarget = `import { ImageMessage } from './messages/ImageMessage';`;
const importReplacement = `import { ImageMessage } from './messages/ImageMessage';\nimport { ChatHeaderMenu } from './messages/ChatHeaderMenu';`;
if (content.includes(importTarget)) {
  content = content.replace(importTarget, importReplacement);
}

const headerTarget = `                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2.5 text-gray-500 hover:bg-black/5 rounded-full transition-all active:scale-90">
                      <MoreVertical className="w-[22px] h-[22px]" strokeWidth={2.5} />
                    </button>
                    <AnimatePresence>
                      {isMenuOpen && <motion.div key="menu-bg" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 w-screen h-screen z-40 cursor-default touch-none" onClick={() => setIsMenuOpen(false)} />}
                      {isMenuOpen && (
                          <motion.div 
                            key="menu-modal"
                            initial={{ opacity: 0, scale: 0.95, transformOrigin: 'top right' }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ duration: 0.1 }}
                            className="absolute right-0 top-12 w-52 bg-[#1c1c1d]/95 backdrop-blur-xl rounded-[20px] shadow-[0_16px_40px_rgba(0,0,0,0.2)] py-2 z-50 border border-white/10"
                          >
                            {[
                              { icon: <User className="w-[18px] h-[18px]" />, label: 'View Profile', action: () => { setShowProfile(true); setIsMenuOpen(false); } },
                              { icon: <Search className="w-[18px] h-[18px]" />, label: 'Search', action: () => { setShowSearch(true); setIsMenuOpen(false); } },
                              { icon: isMuted ? <BellOff className="w-[18px] h-[18px]" /> : <Bell className="w-[18px] h-[18px]" />, label: isMuted ? 'Unmute' : 'Mute', action: () => { setIsMuted(!isMuted); setIsMenuOpen(false); } },
                              { icon: <Pin className="w-[18px] h-[18px]" />, label: isPinned ? 'Unpin Chat' : 'Pin Chat', action: () => { setIsPinned(!isPinned); setIsMenuOpen(false); } },
                              { divider: true },
                              { icon: <Star className="w-[18px] h-[18px]" />, label: 'Favorites', action: () => { setActiveChatFilter(activeChatFilter === 'favorites' ? null : 'favorites'); setIsMenuOpen(false); } },
                              { icon: <Pin className="w-[18px] h-[18px]" />, label: 'Pinned Messages', action: () => { setActiveChatFilter(activeChatFilter === 'pinned' ? null : 'pinned'); setIsMenuOpen(false); } },
                              { icon: <ImageIcon className="w-[18px] h-[18px]" />, label: 'Photos', action: () => { setActiveChatFilter(activeChatFilter === 'photos' ? null : 'photos'); setIsMenuOpen(false); } },
                              { icon: <Video className="w-[18px] h-[18px]" />, label: 'Videos', action: () => { setActiveChatFilter(activeChatFilter === 'videos' ? null : 'videos'); setIsMenuOpen(false); } },
                              { icon: <FileText className="w-[18px] h-[18px]" />, label: 'Documents', action: () => { setActiveChatFilter(activeChatFilter === 'documents' ? null : 'documents'); setIsMenuOpen(false); } },
                              { icon: <Mic className="w-[18px] h-[18px]" />, label: 'Voice', action: () => { setActiveChatFilter(activeChatFilter === 'voice' ? null : 'voice'); setIsMenuOpen(false); } },
                              { icon: <Link2 className="w-[18px] h-[18px]" />, label: 'Links', action: () => { setActiveChatFilter(activeChatFilter === 'links' ? null : 'links'); setIsMenuOpen(false); } },
                              { divider: true },
                              { icon: <Folder className="w-[18px] h-[18px]" />, label: 'Shared Files', action: () => { setShowDocuments(true); setIsMenuOpen(false); } },
                              { icon: <ImageIcon className="w-[18px] h-[18px]" />, label: 'Wallpaper', action: () => { setIsMenuOpen(false); } },
                              { icon: <Settings className="w-[18px] h-[18px]" />, label: 'Theme', action: () => { setChatTheme(chatTheme === 'dark' ? 'light' : 'dark'); setIsMenuOpen(false); } },
                            ].map((item: any, i) => item.divider ? (
                              <div key={i} className="h-[1px] bg-white/10 my-1 mx-2" />
                            ) : (
                              <button
                                key={i}
                                className="w-full flex items-center justify-between px-4 py-2 text-white hover:bg-white/5 transition-colors"
                                onClick={(e) => { e.stopPropagation(); item.action(); }}
                              >
                                <span className="text-[15px] font-medium">{item.label}</span>
                                <div>{item.icon}</div>
                              </button>
                            ))}
                          </motion.div>
                      )}
                    </AnimatePresence>`;

const headerReplacement = `                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2.5 text-gray-500 hover:bg-black/5 rounded-full transition-all active:scale-90">
                      <MoreVertical className="w-[22px] h-[22px]" strokeWidth={2.5} />
                    </button>
                    <AnimatePresence>
                      {isMenuOpen && (
                        <ChatHeaderMenu
                          isMuted={isMuted}
                          isPinned={isPinned}
                          onClose={() => setIsMenuOpen(false)}
                          onAction={(action) => {
                            if (action === 'profile') setShowProfile(true);
                            if (action === 'search') setShowSearch(true);
                            if (action === 'mute') setIsMuted(!isMuted);
                            if (action === 'pin') setIsPinned(!isPinned);
                            if (action === 'favorites') setActiveChatFilter(activeChatFilter === 'favorites' ? null : 'favorites');
                            if (action === 'photos') setActiveChatFilter(activeChatFilter === 'photos' ? null : 'photos');
                            if (action === 'videos') setActiveChatFilter(activeChatFilter === 'videos' ? null : 'videos');
                            if (action === 'documents') setActiveChatFilter(activeChatFilter === 'documents' ? null : 'documents');
                            if (action === 'voice') setActiveChatFilter(activeChatFilter === 'voice' ? null : 'voice');
                            if (action === 'links') setActiveChatFilter(activeChatFilter === 'links' ? null : 'links');
                            if (action === 'files') setShowDocuments(true);
                            if (action === 'theme') setChatTheme(chatTheme === 'dark' ? 'light' : 'dark');
                            setIsMenuOpen(false);
                          }}
                        />
                      )}
                    </AnimatePresence>`;

if (content.includes(headerTarget)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(headerTarget, headerReplacement));
  console.log("Header menu replaced successfully.");
} else {
  console.log("Could not find Header menu block to replace!");
}
