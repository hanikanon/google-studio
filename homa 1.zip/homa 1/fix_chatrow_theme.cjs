const fs = require('fs');
let content = fs.readFileSync('src/components/ChatRow.tsx', 'utf8');

content = content.replace(
  `isContextMenuOpen ? "bg-transparent" : "bg-white"`,
  `isContextMenuOpen ? "bg-transparent" : "bg-white dark:bg-[#111111]"`
);

content = content.replace(
  `isContextSelected ? "bg-white rounded-2xl mx-2 w-[calc(100%-16px)] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.15)]" : (isPressing ? "bg-gray-100/80" : "hover:bg-gray-50 active:bg-gray-100/80")`,
  `isContextSelected ? "bg-white dark:bg-[#1c1c1d] rounded-2xl mx-2 w-[calc(100%-16px)] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.15)]" : (isPressing ? "bg-gray-100/80 dark:bg-white/10" : "hover:bg-gray-50 dark:hover:bg-white/5 active:bg-gray-100/80 dark:active:bg-white/10")`
);

content = content.replace(
  `chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-100"`,
  `chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-100 dark:bg-gray-800"`
);

content = content.replace(
  `border-[2.5px] border-white`,
  `border-[2.5px] border-white dark:border-[#111111]`
);

content = content.replace(
  `border-b border-gray-100/50`,
  `border-b border-gray-100/50 dark:border-white/10`
);

content = content.replace(
  `text-gray-900 truncate tracking-tight`,
  `text-gray-900 dark:text-gray-100 truncate tracking-tight`
);

content = content.replace(
  `bg-blue-100 text-blue-600`,
  `bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400`
);

content = content.replace(
  `bg-gray-100 text-gray-500`,
  `bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400`
);

content = content.replace(
  `text-gray-500 leading-none mb-1.5`,
  `text-gray-500 dark:text-gray-400 leading-none mb-1.5`
);

content = content.replace(
  `text-gray-500 leading-[1.3] pr-2`,
  `text-gray-500 dark:text-gray-400 leading-[1.3] pr-2`
);

content = content.replace(
  `text-gray-900 font-medium mr-1`,
  `text-gray-900 dark:text-gray-300 font-medium mr-1`
);

content = content.replace(
  `text-gray-300 fill-current rotate-45`,
  `text-gray-300 dark:text-gray-600 fill-current rotate-45`
);

fs.writeFileSync('src/components/ChatRow.tsx', content);
console.log("Fixed ChatRow theme classes");
