const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const regex = /}\s*<\/div>\s*\{\/\* Messages Area \*\/\}/g;
// Wait, let's just do a clear replace

content = content.replace(
  `              </>
            )}
      </div>
      {/* Messages Area */}}`,
  `              </>
            )}
      </div>
      {/* Messages Area */}`
);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
