const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `export const MessagesPage: React.FC<MessagesPageProps> = ({ chat, onBack, onUpdateChat }) => {`;
const replacementStr = `const swipeConfidenceThreshold = 10000;
const swipePower = (offset: number, velocity: number) => {
  return Math.abs(offset) * velocity;
};

export const MessagesPage: React.FC<MessagesPageProps> = ({ chat, onBack, onUpdateChat }) => {`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacementStr));
  console.log("Added swipe utils.");
} else {
  console.log("Could not find start of MessagesPage!");
}
