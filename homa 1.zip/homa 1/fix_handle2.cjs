const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `                             if (action === 'files') setShowDocuments(true);`;

const replacement = `                             if (action === 'files') setShowDocuments(true);
                             if (action === 'theme') {
                               // Just toggle a class on the body for demonstration or show an alert
                               alert("Theme settings would open here.");
                             }`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed theme.");
} else {
  console.log("Could not find target string.");
}
