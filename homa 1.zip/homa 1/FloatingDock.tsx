import React, { useState } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { Home, MessageSquare, Users, BookOpen, Settings } from 'lucide-react';

interface FloatingDockProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: string) => void;
}

export const FloatingDock: React.FC<FloatingDockProps> = ({ isOpen, onClose, onNavigate }) => {
  const [activeItem, setActiveItem] = useState('Home');

  // 60 FPS, fully responsive GPU-accelerated animations
  const items = [
    { id: 'Home', icon: <Home className="w-6 h-6" strokeWidth={2} /> },
    { id: 'Chat', icon: <MessageSquare className="w-6 h-6" strokeWidth={2} /> },
    { id: 'Community', icon: <Users className="w-6 h-6" strokeWidth={2} /> },
    { id: 'Learning', icon: <BookOpen className="w-6 h-6" strokeWidth={2} /> },
    { id: 'Settings', icon: <Settings className="w-6 h-6" strokeWidth={2} /> },
  ];

  const handlePanEnd = (event: any, info: PanInfo) => {
    // Detect horizontal swipe to the left
    if (info.offset.x < -40 || info.velocity.x < -200) {
      onClose();
    }
  };

  const handleDragEnd = (e: any, info: any) => {
    if (info.offset.x < -30 || info.velocity.x < -200) {
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/5 backdrop-blur-[2px]"
          />

          {/* Dock */}
          <motion.div
            initial={{ x: -100, opacity: 0, scale: 0.95 }}
            animate={{ x: 0, opacity: 1, scale: 1 }}
            exit={{ x: -100, opacity: 0, scale: 0.95 }}
            transition={{
              type: 'spring',
              stiffness: 350,
              damping: 25,
              mass: 0.8,
              duration: 0.25
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={{ left: 0.5, right: 0 }}
            onDragEnd={handleDragEnd}
            onPanEnd={handlePanEnd}
            className="fixed z-50 left-[16px] md:left-[20px] top-[65%] -translate-y-1/2 flex flex-col items-center py-[22px] w-[76px] rounded-[40px] shadow-[0_20px_50px_rgba(0,0,0,0.3)]"
            style={{
              background: 'rgba(9, 9, 11, 0.75)',
              backgroundImage: 'linear-gradient(to bottom, rgba(255,255,255,0.06), rgba(255,255,255,0.02))',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              border: '1px solid rgba(255, 255, 255, 0.12)',
            }}
          >
            <div className="flex flex-col gap-5 items-center w-full">
              {items.map((item) => {
                const isActive = activeItem === item.id;
                return (
                  <motion.button
                    key={item.id}
                    whileTap={{ scale: 0.85 }}
                    onClick={() => {
                      if (window.navigator?.vibrate) window.navigator.vibrate(20);
                      setActiveItem(item.id);
                      onNavigate(item.id);
                      setTimeout(() => onClose(), 150);
                    }}
                    className="relative w-12 h-12 flex items-center justify-center outline-none group"
                  >
                    {isActive && (
                      <motion.div
                        layoutId="active-dock-item"
                        className="absolute inset-0 rounded-[14px]"
                        style={{
                          background: 'linear-gradient(135deg, #42A5F5 0%, #1E88E5 100%)',
                          boxShadow: '0 4px 12px rgba(66, 165, 245, 0.45)',
                        }}
                        initial={false}
                        transition={{ type: "spring", stiffness: 400, damping: 25 }}
                      />
                    )}
                    <motion.div
                      animate={{
                        color: isActive ? '#FFFFFF' : '#8B8B95',
                        opacity: isActive ? 1 : 0.65,
                      }}
                      whileHover={!isActive ? { opacity: 0.9, color: '#A1A1AA' } : undefined}
                      className="relative z-10 flex items-center justify-center"
                    >
                      {item.icon}
                    </motion.div>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
