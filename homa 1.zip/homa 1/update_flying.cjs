const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

// First replace the EMOJIS in ReactionBar
let rbContent = fs.readFileSync('src/components/messages/ReactionBar.tsx', 'utf8');
rbContent = rbContent.replace(
  "const EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🔥', '🎉'];",
  "const EMOJIS = ['⭐', '👍', '❤️', '😂', '😮', '😢', '🔥'];"
);
fs.writeFileSync('src/components/messages/ReactionBar.tsx', rbContent);

// Add rendering for flyingEmojis
const renderCode = `      {/* Flying Emojis */}
      <AnimatePresence>
        {flyingEmojis.map((e) => (
           <motion.div
              key={e.id}
              initial={{ opacity: 0, scale: 0, x: e.x - 20, y: e.y - 20 }}
              animate={{ 
                 opacity: [0, 1, 1, 0], 
                 scale: [0.3, e.scale, e.scale, e.scale * 0.8], 
                 y: [e.y - 20, e.y - 60 - Math.random() * 80, e.y - 100 - Math.random() * 80],
                 x: e.x - 20 + e.offsetX
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.2 + Math.random() * 0.5, ease: "easeOut" }}
              className="fixed z-[9999] pointer-events-none text-2xl drop-shadow-md"
           >
              {e.emoji}
           </motion.div>
        ))}
      </AnimatePresence>

      {/* Hidden File Inputs */}`;

content = content.replace(
  "{/* Hidden File Inputs */}",
  renderCode
);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
console.log("Updated rendering");
