const fs = require('fs');
let content = fs.readFileSync('src/components/messages/ImageMessage.tsx', 'utf8');

const targetStr = `              <div 
                key={i} 
                className={cn("relative bg-black/10 cursor-pointer overflow-hidden", images.length === 1 ? "" : spanClass)}
                onClick={(e) => handleInteraction(e, i)}
              >`;

const replacement = `              <div 
                key={i} 
                className={cn("relative bg-black/10 cursor-pointer overflow-hidden flex items-center justify-center", images.length === 1 ? "w-[280px] h-[320px]" : spanClass)}
                onClick={(e) => handleInteraction(e, i)}
              >`;

if (content.includes(targetStr)) {
  fs.writeFileSync('src/components/messages/ImageMessage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed ImageMessage.");
} else {
  console.log("Could not find target in ImageMessage!");
}
