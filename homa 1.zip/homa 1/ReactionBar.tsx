import React from 'react';
import { motion } from 'framer-motion';

const EMOJIS = ['⭐', '👍', '❤️', '😂', '😮', '😢', '🔥'];

interface ReactionBarProps {
  onReact: (emoji: string) => void;
}

export const ReactionBar: React.FC<ReactionBarProps> = ({ onReact }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9, y: 5 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9, y: 5 }}
      transition={{ type: 'spring', damping: 25, stiffness: 400 }}
      className="flex items-center gap-1 px-2 py-1.5 bg-white dark:bg-[#1c1c1d] rounded-[24px] shadow-[0_4px_20px_rgba(0,0,0,0.12)] dark:shadow-[0_4px_20px_rgba(0,0,0,0.4)] max-w-[280px] overflow-x-auto hide-scrollbar shrink-0"
    >
      {EMOJIS.map((emoji, i) => (
        <motion.button 
          initial={{ scale: 0, opacity: 0, y: 10 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{ delay: i * 0.02, type: 'spring', stiffness: 600, damping: 20 }}
          whileHover={{ scale: 1.25, transition: { duration: 0.2 } }}
          whileTap={{ scale: 0.8 }}
          key={i} 
          className="text-[24px] shrink-0 origin-bottom flex items-center justify-center p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-full" 
          onClick={(e) => { 
            e.stopPropagation(); 
            onReact(emoji); 
          }}
        >
          {emoji}
        </motion.button>
      ))}
    </motion.div>
  );
};
