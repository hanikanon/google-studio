import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const replaceInFile = (filePath, replacements) => {
  const fullPath = path.join(__dirname, filePath);
  if (!fs.existsSync(fullPath)) return;
  let content = fs.readFileSync(fullPath, 'utf8');
  for (const [search, replace] of replacements) {
    // replace global
    content = content.replace(new RegExp(search, 'g'), replace);
  }
  fs.writeFileSync(fullPath, content);
};

// App.tsx
replaceInFile('src/App.tsx', [
  ["import React, \\{ useState, useEffect \\} from 'react';", "import { useState, useEffect } from 'react';"]
]);

// ActionFlowOverlay.tsx
replaceInFile('src/components/ActionFlowOverlay.tsx', [
  ["import React from 'react';\\n", ""],
  ["import \\{ Share, Copy, Trash2, ArrowRight, CornerUpLeft, CornerUpRight, Flag, X \\} from 'lucide-react';", "import { Share, Copy, Trash2, ArrowRight, CornerUpLeft, CornerUpRight, X } from 'lucide-react';"]
]);

// AttachmentMenu.tsx
replaceInFile('src/components/AttachmentMenu.tsx', [
  ["onClick=\\{\\(e\\) => \\{ if \\(onGallery\\) onGallery\\(\\); \\}\\}", "onClick={() => { if (onGallery) onGallery(); }}"],
  ["onClick=\\{\\(e\\) => \\{ if \\(onFile\\) onFile\\(\\); \\}\\}", "onClick={() => { if (onFile) onFile(); }}"],
  ["onClick=\\{\\(e\\) => \\{ if \\(onLocation\\) onLocation\\(\\); \\}\\}", "onClick={() => { if (onLocation) onLocation(); }}"],
  ["onClick=\\{\\(e\\) => \\{ if \\(onContact\\) onContact\\(\\); \\}\\}", "onClick={() => { if (onContact) onContact(); }}"]
]);

// ChatRow.tsx
replaceInFile('src/components/ChatRow.tsx', [
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); onPin\\(\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); onPin(); }}"],
  ["onPointerDown=\\{\\(e\\) => handlePointerDown\\(\\)\\}", "onPointerDown={() => handlePointerDown()}"]
]);

// ContextMenu.tsx
replaceInFile('src/components/ContextMenu.tsx', [
  ["const rect = target\\.getBoundingClientRect\\(\\);", "target.getBoundingClientRect();"],
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); onReply\\(\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); onReply(); }}"],
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); onCopy\\(\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); onCopy(); }}"],
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); onPin\\(\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); onPin(); }}"],
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); onForward\\(\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); onForward(); }}"],
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); onDelete\\(\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); onDelete(); }}"]
]);

// FAB.tsx
replaceInFile('src/components/FAB.tsx', [
  ["import \\{ MessageSquare, Plus, Check, Edit2, Camera, Lock, ArrowLeft, X \\} from 'lucide-react';", "import { MessageSquare, Plus, Check, Edit2, Camera, ArrowLeft } from 'lucide-react';"],
  ["const FAB = \\(\\{ mode, onAction, onClick \\}: \\{ mode: 'default' \\| 'select' \\| 'edit' \\| 'camera' \\| 'add', onAction\\?: \\(\\) => void, onClick\\?: \\(\\) => void \\}\\) => \\{", "const FAB = ({ mode, onClick }: { mode: 'default' | 'select' | 'edit' | 'camera' | 'add', onClick?: () => void }) => {"],
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); if \\(onClick\\) onClick\\(\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); if (onClick) onClick(); }}"]
]);

// FloatingDock.tsx
replaceInFile('src/components/FloatingDock.tsx', [
  ["onPointerDown=\\{\\(event\\) => \\{", "onPointerDown={() => {"],
  ["onPointerMove=\\{\\(e\\) => \\{", "onPointerMove={() => {"]
]);

// Header.tsx
replaceInFile('src/components/Header.tsx', [
  ["import \\{ ArrowLeft, Search, MoreVertical, Phone, Video, User \\} from 'lucide-react';", "import { ArrowLeft, Search, MoreVertical, Phone, Video } from 'lucide-react';"],
  ["import Logo from '\\./Logo';\\n", ""]
]);

// MessagesPage.tsx
replaceInFile('src/components/MessagesPage.tsx', [
  ["import React, \\{ useState, useEffect, useRef, useMemo, useCallback \\} from 'react';", "import React, { useState, useEffect, useRef, useMemo } from 'react';"],
  ["import \\{ ArrowLeft, MoreVertical, Phone, Video, Search, Paperclip, Mic, Send, Smile, Play, Pause, Camera, MapPin, FileText, X, Check, CheckCheck, Reply, Copy, Pin, Forward, Trash2, Heart, Plus, Folder, Music, Image \\} from 'lucide-react';", "import { ArrowLeft, MoreVertical, Phone, Video, Search, Paperclip, Mic, Play, Pause, FileText, X, Reply, Copy, Pin, Forward, Trash2, Heart } from 'lucide-react';"],
  ["const _scrollToMessage = \\(msgId: string\\) => \\{", "const _scrollToMessage = (_msgId: string) => {"],
  ["const isRecording = false;\\n", ""],
  ["const audioError = null;\\n", ""],
  ["const showProfile = false;\\n", ""],
  ["const slideOffset = 0;\\n", ""],
  ["const handleMicPointerDown = \\(e: React\\.PointerEvent\\) => \\{\\};\\n", ""],
  ["const handleMicPointerMove = \\(e: React\\.PointerEvent\\) => \\{\\};\\n", ""],
  ["const handleMicPointerUp = \\(\\) => \\{\\};\\n", ""],
  ["const isMoreMenuOpen = false;\\n", ""],
  ["const isFirstInCluster = i === 0 \\|\\| messages\\[i - 1\\]\\.senderId !== msg\\.senderId;\\n", ""],
  ["onDragEnd=\\{\\(_e, info\\) => \\{", "onDragEnd={(_, info) => {"],
  ["onClick=\\{\\(e\\) => \\{ e\\.stopPropagation\\(\\); handleReaction\\(msg\\.id, r\\.emoji, e\\); \\}\\}", "onClick={(e) => { e.stopPropagation(); handleReaction(msg.id, r.emoji, e); }}"],
  ["msg\\.reactions\\.map\\(\\(r, i\\) => \\(", "msg.reactions.map((r) => ("]
]);

// usePopupManager.ts
replaceInFile('src/usePopupManager.ts', [
  ["const handleEscape = \\(e: KeyboardEvent\\) => \\{", "const handleEscape = () => {"]
]);
