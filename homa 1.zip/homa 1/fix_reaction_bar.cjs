const fs = require('fs');
let content = fs.readFileSync('src/components/messages/ReactionBar.tsx', 'utf8');

content = content.replace(
  `className="flex items-center gap-2 px-3 py-2 bg-white/95 dark:bg-[#232324]/95 backdrop-blur-xl border border-black/5 dark:border-white/10 rounded-[20px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_16px_40px_rgba(0,0,0,0.3)] max-w-[280px] overflow-x-auto hide-scrollbar shrink-0"`,
  `className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-[#1c1c1d] rounded-[24px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_32px_rgba(0,0,0,0.4)] max-w-[280px] overflow-x-auto hide-scrollbar shrink-0"`
);

content = content.replace(
  `className="text-[24px] shrink-0 origin-bottom flex items-center justify-center p-1"`,
  `className="text-[26px] shrink-0 origin-bottom flex items-center justify-center p-1 hover:bg-black/5 dark:hover:bg-white/5 rounded-full"`
);

fs.writeFileSync('src/components/messages/ReactionBar.tsx', content);
console.log("Fixed ReactionBar");
