const fs = require('fs');
let content = fs.readFileSync('src/components/messages/MessageMenu.tsx', 'utf8');

content = content.replace(
  `className="w-[220px] bg-white dark:bg-[#1c1c1d] rounded-[14px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_32px_rgba(0,0,0,0.4)] flex flex-col overflow-hidden"`,
  `className="w-[200px] bg-white dark:bg-[#1c1c1d] rounded-[12px] shadow-[0_4px_24px_rgba(0,0,0,0.15)] dark:shadow-[0_4px_24px_rgba(0,0,0,0.4)] flex flex-col overflow-hidden"`
);

content = content.replace(
  `className="w-full flex items-center justify-between px-4 py-[11px] transition-colors active:bg-black/5 dark:active:bg-white/5"`,
  `className="w-full flex items-center justify-between px-3 py-[9px] transition-colors active:bg-black/5 dark:active:bg-white/5"`
);

content = content.replace(
  `className={cn(
                "w-full flex items-center justify-between px-4 py-[11px] transition-colors active:bg-black/5 dark:active:bg-white/5", 
                item.isRemove ? "text-[#FF3B30]" : "text-gray-900 dark:text-gray-200"
              )}`,
  `className={cn(
                "w-full flex items-center justify-between px-3.5 py-[10px] transition-colors active:bg-black/5 dark:active:bg-white/5", 
                item.isRemove ? "text-[#FF3B30]" : "text-gray-900 dark:text-gray-200"
              )}`
);

content = content.replace(
  `className="text-[15px] font-medium leading-none"`,
  `className="text-[15px] font-medium leading-none"`
);

fs.writeFileSync('src/components/messages/MessageMenu.tsx', content);
console.log("Fixed msg menu");
