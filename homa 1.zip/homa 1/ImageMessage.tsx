import React from 'react';
import { cn } from '../../utils';
import { Message } from '../../data';
import { MessageIndicators } from '../MessageIndicators';
import { Play } from 'lucide-react';

interface ImageMessageProps {
  msg: Message;
  isMe: boolean;
  onImageClick?: (msg: Message, index: number) => void;
  onDoubleTap?: (msg: Message, e: React.MouseEvent) => void;
}

export const ImageMessage: React.FC<ImageMessageProps> = ({ msg, isMe, onImageClick, onDoubleTap }) => {
  const images = msg.mediaGroup && msg.mediaGroup.length > 0 ? msg.mediaGroup : [{ url: msg.imageUrl }];
  
  const getGridClass = (count: number) => {
    if (count === 1) return 'grid-cols-1';
    if (count === 2) return 'grid-cols-2';
    if (count === 3) return 'grid-cols-2'; 
    if (count >= 4) return 'grid-cols-2';
    return 'grid-cols-2';
  };

  const handleInteraction = (e: React.MouseEvent, index: number) => {
    e.stopPropagation();
    if ((window as any)._tapTimer) {
       clearTimeout((window as any)._tapTimer);
       (window as any)._tapTimer = null;
       onDoubleTap?.(msg, e);
    } else {
       (window as any)._tapTimer = setTimeout(() => {
          (window as any)._tapTimer = null;
          onImageClick?.(msg, index);
       }, 250);
    }
  };

  return (
    <div className="flex flex-col p-1">
      <div className="relative">
        <div className={cn("grid gap-[2px] rounded-[12px] overflow-hidden", getGridClass(images.length))}>
          {images.map((img: any, i: number) => {
            if (i > 3) return null; // cap at 4 for preview
            const isMore = images.length > 4 && i === 3;
            // For 3 images, make the first one span full width
            const spanClass = (images.length === 3 && i === 0) ? 'col-span-2 aspect-[2/1]' : 'aspect-square';
            return (
              <div 
                key={i} 
                className={cn("relative bg-black/10 cursor-pointer overflow-hidden flex items-center justify-center", images.length === 1 ? "w-[280px] h-[320px]" : spanClass)}
                onClick={(e) => handleInteraction(e, i)}
              >
                {img.type === 'video' ? (
                  <div className="absolute inset-0 bg-black flex items-center justify-center min-h-[200px]">
                    <video src={img.url} className="absolute inset-0 w-full h-full object-cover opacity-80 pointer-events-none" />
                    <Play className="w-10 h-10 text-white z-10" fill="currentColor" />
                  </div>
                ) : (
                  <>
                    <img 
                      src={img.url || img} 
                      alt="" 
                      loading="lazy"
                      onLoad={(e) => {
                        (e.target as HTMLImageElement).classList.remove('opacity-0');
                      }}
                      className="w-full h-full object-cover select-none pointer-events-none opacity-0 transition-opacity duration-300" 
                    />
                    <div className="absolute inset-0 bg-black/5 flex items-center justify-center -z-10 animate-pulse" />
                  </>
                )}
                {isMore && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <span className="text-white text-xl font-bold">+{images.length - 4}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        {!msg.text && (
          <div className="absolute bottom-1.5 right-1.5 bg-black/30 backdrop-blur-[8px] rounded-full px-2 py-0.5 flex items-center gap-1 text-white shadow-sm z-10 pointer-events-none">
            <span className="text-[11px] leading-none font-medium tabular-nums mt-[1px]">{msg.time}</span>
            <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} isImageOverlay={true} />
          </div>
        )}
      </div>
      {msg.text && (
        <div className="px-2 pt-1.5 pb-1 relative min-w-[90px]">
          <div className="text-[16px] leading-[1.35] break-words whitespace-pre-wrap" dir="auto">
            {msg.text}
            <span className={cn("float-right inline-flex items-center ml-2.5 mt-1.5 h-[15px] select-none pointer-events-none", isMe ? "text-white/70" : "text-gray-400")} dir="ltr">
              <span className="text-[11px] font-medium leading-none tabular-nums mt-[2px]">{msg.time}</span>
              <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} />
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
