const fs = require('fs');
let content = fs.readFileSync('src/components/FAB.tsx', 'utf8');

content = content.replace(
  `bg-white/60 backdrop-blur-sm`,
  `bg-white/60 dark:bg-black/60 backdrop-blur-sm`
);

content = content.replace(
  `bg-white/90 backdrop-blur-xl rounded-[20px] shadow-[0_12px_32px_-4px_rgba(0,0,0,0.15)] border border-white/60`,
  `bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-xl rounded-[20px] shadow-[0_12px_32px_-4px_rgba(0,0,0,0.15)] border border-white/60 dark:border-white/10`
);

content = content.replace(
  `bg-white/90 backdrop-blur-xl rotate-45 border-b border-r border-white/60`,
  `bg-white/90 dark:bg-[#1c1c1d]/90 backdrop-blur-xl rotate-45 border-b border-r border-white/60 dark:border-white/10 dark:border-l-0 dark:border-t-0`
);

content = content.replace(
  `bg-white pl-3 pr-1 py-1 rounded-full shadow-lg shadow-black/5 hover:shadow-xl transition-shadow border border-gray-50`,
  `bg-white dark:bg-[#1c1c1d] pl-3 pr-1 py-1 rounded-full shadow-lg shadow-black/5 dark:shadow-black/40 hover:shadow-xl transition-shadow border border-gray-50 dark:border-white/5`
);

content = content.replace(
  `font-medium text-gray-700 text-[13px]`,
  `font-medium text-gray-700 dark:text-gray-200 text-[13px]`
);

fs.writeFileSync('src/components/FAB.tsx', content);
console.log("Fixed FAB theme classes");
