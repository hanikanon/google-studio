const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

const targetStr = `                    </AnimatePresence>
                  </div>
                </div>
              </>
            )}
        </div>
      </div>
      {/* Messages Area */}`;

const replacement = `                    </AnimatePresence>
                  </div>
                </div>
              </>
            )}
      </div>
      {/* Messages Area */}`;

if (content.includes("        </div>\n      </div>\n      {/* Messages Area */}")) {
  fs.writeFileSync('src/components/MessagesPage.tsx', content.replace(targetStr, replacement));
  console.log("Fixed closing tags");
} else {
  console.log("Not found");
}
