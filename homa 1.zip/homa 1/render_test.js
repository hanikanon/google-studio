import { renderToString } from 'react-dom/server';
import React from 'react';

// Setup globals
global.window = { navigator: { vibrate: () => {} }, innerHeight: 800, innerWidth: 600, addEventListener: () => {}, removeEventListener: () => {} };
global.document = { getElementById: () => null, createElement: () => ({}) };
global.navigator = global.window.navigator;
global.localStorage = { getItem: () => null, setItem: () => {} };
global.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };

import App from './dist/index-D5E7hDP2.js'; // Note: this won't work easily due to hashing and css
console.log("App:", App);
