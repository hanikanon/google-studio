import { useEffect } from 'react';

export function usePopupManager(
  isOpen: boolean,
  onClose: () => void
) {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    const handlePopState = (e: PopStateEvent) => {
      onClose();
    };

    try {
      window.history.pushState({ popup: true }, '');
    } catch (e) {
      // Ignore if pushState is blocked by sandbox
    }

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('popstate', handlePopState);
    };
  }, [isOpen]);
}
