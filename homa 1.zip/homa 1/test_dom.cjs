const { JSDOM } = require('jsdom');
const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', { runScripts: "dangerously" });
global.window = dom.window;
global.document = dom.window.document;
global.navigator = dom.window.navigator;
global.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };

// We need to load the built client code.
// Since it's a module, we can use dynamic import if we use an mjs file.
