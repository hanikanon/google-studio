import "../styles.css";

import { createRootRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";
import React, { ReactNode } from "react";
import { SettingsProvider, useSettings } from "../components/settings/SettingsContext";
import { motion, AnimatePresence } from "framer-motion";
import { themeStyle } from "../config/themes";

const queryClient = new QueryClient();

export const Route = createRootRoute({
  component: RootComponent,
  notFoundComponent: () => {
    return (
      <div className="flex h-full w-full flex-col items-center justify-center p-4 text-center">
        <h1 className="mb-2 text-2xl font-bold">404</h1>
        <p className="text-muted-foreground">The page you are looking for does not exist.</p>
      </div>
    );
  },
});

function RouteTransition({ children }: { children: ReactNode }) {
  const routerState = useRouterState();
  const isBack = !!(routerState.location.state as any)?.isBack;
  return (
    <AnimatePresence mode="popLayout" custom={isBack}>
      <motion.div
        key={routerState.location.pathname}
        custom={isBack}
        variants={{
          initial: (back: boolean) => ({
            x: back ? -20 : 20,
            opacity: 0,
          }),
          animate: {
            x: 0,
            opacity: 1,
          },
          exit: (back: boolean) => ({
            x: back ? 20 : -20,
            opacity: 0,
          })
        }}
        initial="initial"
        animate="animate"
        exit="exit"
        transition={{
          type: "spring",
          stiffness: 400,
          damping: 35,
          mass: 0.8,
        }}
        className="h-full w-full bg-background"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

function RootComponent() {
  return (
    <QueryClientProvider client={queryClient}>
      <SettingsProvider>
        <ThemedShell>
          <RouteTransition>
            <Outlet />
          </RouteTransition>
        </ThemedShell>
      </SettingsProvider>
    </QueryClientProvider>
  );
}

function ThemedShell({ children }: { children: ReactNode }) {
  const s = useSettings();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="settings-root dark flex h-full w-full items-center justify-center overflow-hidden bg-background font-sans text-foreground"
      style={themeStyle(s.theme, s.accent, s.radius, s.fontSize, s.blur)}
    >
      <div className="relative mx-auto flex h-full w-full max-w-[480px] flex-col overflow-hidden bg-background">
        {children}
        <Toaster
          theme="dark"
          position="bottom-center"
          toastOptions={{
            style: {
              background: 'var(--surface-3)',
              border: '1px solid var(--border)',
              color: 'var(--foreground)',
              borderRadius: '16px',
            }
          }}
        />
      </div>
    </motion.div>
  );
}
