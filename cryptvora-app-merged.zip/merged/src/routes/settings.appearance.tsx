import { createFileRoute } from "@tanstack/react-router";
import { Palette, Type, CircleDot } from "lucide-react";
import { SettingsScreen } from "@/components/settings/SettingsScreen";
import { SettingGroup } from "@/components/settings/SettingGroup";
import { RowChoice } from "@/components/settings/rows";
import { useSettings } from "@/components/settings/SettingsContext";

export const Route = createFileRoute("/settings/appearance")({
  component: Page,
});

function Page() {
  const s = useSettings();

  return (
    <SettingsScreen title="Appearance">
      <SettingGroup label="Display">
        <RowChoice
          icon={Palette}
          label="Bubble style"
          value={s.bubble}
          options={[
            { value: "rounded", label: "Rounded" },
            { value: "modern", label: "Modern" },
            { value: "square", label: "Square" },
            { value: "tail", label: "Tail" },
          ]}
          onChange={s.setBubble}
        />
        <RowChoice
          icon={Type}
          label="Font size"
          value={s.fontSize}
          options={[
            { value: "small", label: "Small" },
            { value: "medium", label: "Medium" },
            { value: "large", label: "Large" },
            { value: "xl", label: "Extra large" },
          ]}
          onChange={s.setFontSize}
        />
        <RowChoice
          icon={CircleDot}
          label="Motion"
          value={s.motion}
          options={[
            { value: "normal", label: "Normal" },
            { value: "fast", label: "Fast" },
            { value: "reduced", label: "Reduced" },
          ]}
          onChange={s.setMotion}
          last
        />
      </SettingGroup>
    </SettingsScreen>
  );
}
