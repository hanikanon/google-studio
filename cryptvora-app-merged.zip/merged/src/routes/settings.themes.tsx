import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { SettingsScreen } from "@/components/settings/SettingsScreen";
import { SettingGroup } from "@/components/settings/SettingGroup";
import { useSettings } from "@/components/settings/SettingsContext";
import { THEMES, ACCENTS, type ThemeId, type AccentId } from "@/config/themes";

export const Route = createFileRoute("/settings/themes")({
  component: Page,
});

function Page() {
  const s = useSettings();
  const themeIds = Object.keys(THEMES) as ThemeId[];
  const accentIds = Object.keys(ACCENTS) as AccentId[];

  return (
    <SettingsScreen title="Themes">
      <SettingGroup label="Theme">
        <div className="grid grid-cols-3 gap-2 px-3 py-3">
          {themeIds.map((id) => {
            const t = THEMES[id];
            const active = s.theme === id;
            return (
              <button
                key={id}
                onClick={() => s.setTheme(id)}
                className="flex flex-col items-center gap-1.5 rounded-xl p-2 press"
                style={{
                  border: active ? "2px solid var(--primary)" : "1px solid var(--border)",
                }}
              >
                <span
                  className="flex h-9 w-9 items-center justify-center rounded-full"
                  style={{ background: t.bg, border: `1px solid ${t.border}` }}
                >
                  {active && <Check size={14} color={t.fg} />}
                </span>
                <span className="text-[11px] capitalize text-foreground">{id}</span>
              </button>
            );
          })}
        </div>
      </SettingGroup>

      <SettingGroup label="Accent color">
        <div className="flex flex-wrap gap-3 px-4 py-3">
          {accentIds.map((id) => {
            const a = ACCENTS[id];
            const active = s.accent === id;
            return (
              <button
                key={id}
                aria-label={id}
                onClick={() => s.setAccent(id)}
                className="flex h-9 w-9 items-center justify-center rounded-full press"
                style={{
                  background: a.value,
                  boxShadow: active ? `0 0 0 2px var(--surface), 0 0 0 4px ${a.value}` : "none",
                }}
              >
                {active && <Check size={14} color="#fff" />}
              </button>
            );
          })}
        </div>
      </SettingGroup>
    </SettingsScreen>
  );
}
