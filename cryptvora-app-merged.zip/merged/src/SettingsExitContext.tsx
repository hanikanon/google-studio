import { createContext, useContext } from "react";

export const SettingsExitContext = createContext<() => void>(() => {});

export function useSettingsExit() {
  return useContext(SettingsExitContext);
}
