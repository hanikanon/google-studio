import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, MessageSquare, Users, Megaphone, Lock, User, FileText, Pencil, Settings, Bot, Shield, ScanLine, UserPlus, X } from 'lucide-react';
import { cn } from './utils';
import { usePopupManager } from './usePopupManager';

interface FABProps {
  isVisible: boolean;
  onAction?: (action: string) => void;
  onLongPressAction?: () => void;
}

export const FAB: React.FC<FABProps> = ({ isVisible, onAction, onLongPressAction }) => {
  const [menuState, setMenuState] = useState<'none' | 'standard' | 'longPress'>('none');
  const [isPressing, setIsPressing] = useState(false);
  
  const isAnyOpen = menuState !== 'none';
  usePopupManager(isAnyOpen, () => setMenuState('none'));

  React.useEffect(() => {
    if (menuState === 'none') return;
    const handleScroll = () => setMenuState('none');
    window.addEventListener('scroll', handleScroll, { capture: true, passive: true });
    return () => window.removeEventListener('scroll', handleScroll, { capture: true });
  }, [menuState]);
  
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const wasLongPress = useRef(false);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (menuState !== 'none') {
      return;
    }
    
    setIsPressing(true);
    wasLongPress.current = false;
    
    longPressTimer.current = setTimeout(() => {
      wasLongPress.current = true;
      setIsPressing(false);
      if (onLongPressAction) {
        onLongPressAction();
      } else {
        setMenuState('longPress');
      }
      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
    }, 400);
  };

  const handlePointerUp = () => {
    setIsPressing(false);
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  const handleClick = () => {
    if (wasLongPress.current) {
      // It was a long press, so releasing the pointer will trigger click. Ignore it.
      // Reset the flag for the next interaction
      wasLongPress.current = false;
      return;
    }
    
    if (menuState !== 'none') {
      setMenuState('none');
      return;
    }
    
    if (window.navigator?.vibrate) window.navigator.vibrate(20); setMenuState('standard');
  };

  const handleCloseAll = () => {
    setMenuState('none');
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.05, delayChildren: 0.02 }
    },
    exit: {
      opacity: 0,
      transition: { staggerChildren: 0.03, staggerDirection: -1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15, scale: 0.8 },
    visible: { opacity: 1, y: 0, scale: 1, transition: { type: 'spring', stiffness: 400, damping: 25 } },
    exit: { opacity: 0, y: 10, scale: 0.8, transition: { duration: 0.15 } }
  };

  return (
    <>
      <AnimatePresence>
        {isVisible && isAnyOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={() => { if (window.navigator?.vibrate) window.navigator.vibrate(20); handleCloseAll(); }}
            onPointerDown={handleCloseAll}
            className="fixed inset-0 w-screen h-screen bg-white/60 backdrop-blur-sm z-30 cursor-default touch-none"
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ y: 100, opacity: 0, scale: 0.9 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 100, opacity: 0, scale: 0.9 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="absolute bottom-6 right-5 flex flex-col items-end justify-end z-40 pointer-events-none gap-4"
          >
            {/* Long Press Menu */}
            <AnimatePresence>
              {menuState === 'longPress' && (
                <motion.div 
                  initial={{ opacity: 0, y: 15, scale: 0.9, filter: 'blur(4px)', transformOrigin: 'bottom right' }}
                  animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, y: 15, scale: 0.9, filter: 'blur(2px)' }}
                  transition={{ type: 'spring', damping: 25, stiffness: 350, mass: 0.9 }}
                  className="pointer-events-auto absolute bottom-[68px] right-0 flex flex-row items-center justify-between px-3 py-2 bg-white/90 backdrop-blur-xl rounded-[20px] shadow-[0_12px_32px_-4px_rgba(0,0,0,0.15)] border border-white/60 min-w-[200px]"
                >
                  <div className="absolute -bottom-[5px] right-[24px] w-3 h-3 bg-white/90 backdrop-blur-xl rotate-45 border-b border-r border-white/60 shadow-sm" style={{ zIndex: -1 }} />
                  
                  {[
                    { icon: <User className="w-[22px] h-[22px]" strokeWidth={1.5} />, color: 'text-gray-700' },
                    { icon: <Settings className="w-[22px] h-[22px]" strokeWidth={1.5} />, color: 'text-gray-700' },
                    { icon: <FileText className="w-[22px] h-[22px]" strokeWidth={1.5} />, color: 'text-gray-700' },
                    { icon: <Bot className="w-[22px] h-[22px]" strokeWidth={1.5} />, color: 'text-gray-700' },
                  ].map((item, i) => (
                    <motion.button 
                      key={i}
                      whileHover={{ scale: 1.1, backgroundColor: 'rgba(0,0,0,0.04)' }}
                      whileTap={{ scale: 0.9 }}
                      onClick={handleCloseAll}
                      className={cn("flex items-center justify-center w-[40px] h-[40px] rounded-[14px] transition-colors outline-none", item.color)}
                    >
                      {item.icon}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Standard Tap Menu */}
            <AnimatePresence>
              {menuState === 'standard' && (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="flex flex-col gap-2 pointer-events-auto items-end mb-2"
                >
                  {[
                    { icon: <MessageSquare className="w-[18px] h-[18px]" />, label: 'New Message', color: 'text-blue-600', bg: 'bg-blue-100' },
                    { icon: <Users className="w-[18px] h-[18px]" />, label: 'New Group', color: 'text-indigo-600', bg: 'bg-indigo-100' },
                    { icon: <Shield className="w-[18px] h-[18px]" />, label: 'New Community', color: 'text-purple-600', bg: 'bg-purple-100' },
                    { icon: <Megaphone className="w-[18px] h-[18px]" />, label: 'New Channel', color: 'text-orange-600', bg: 'bg-orange-100' },
                    { icon: <UserPlus className="w-[18px] h-[18px]" />, label: 'Invite Contacts', color: 'text-teal-600', bg: 'bg-teal-100' },
                    { icon: <ScanLine className="w-[18px] h-[18px]" />, label: 'Scan QR Code', color: 'text-gray-700', bg: 'bg-gray-100' },
                  ].map((item, i) => (
                    <motion.button 
                      key={i}
                      variants={itemVariants as any}
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={handleCloseAll}
                      className="flex items-center gap-2.5 bg-white pl-3 pr-1 py-1 rounded-full shadow-lg shadow-black/5 hover:shadow-xl transition-shadow border border-gray-50"
                    >
                      <span className="font-medium text-gray-700 text-[13px] pl-1">{item.label}</span>
                      <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", item.bg, item.color)}>
                        {item.icon}
                      </div>
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            <motion.button
              onPointerDown={handlePointerDown}
              onPointerUp={handlePointerUp}
              onPointerLeave={handlePointerUp}
              onPointerCancel={handlePointerUp}
              onClick={handleClick}
              animate={{ scale: isPressing ? 0.92 : 1 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="pointer-events-auto w-14 h-14 rounded-2xl flex items-center justify-center transition-shadow overflow-hidden relative group shadow-[0_4px_12px_rgba(59,130,246,0.3)] bg-[#3b82f6] hover:bg-[#2563eb]"
            >
              <motion.div 
                animate={{ rotate: (isAnyOpen) ? 135 : 0 }} 
                transition={{ type: 'spring', damping: 22, stiffness: 350 }}
                className="z-10 flex items-center justify-center"
              >
                {(isAnyOpen) ? (
                   <Plus className="w-6 h-6 text-white" strokeWidth={2.5} />
                ) : (
                   <Pencil className="w-6 h-6 text-white fill-current" strokeWidth={2} />
                )}
              </motion.div>
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
