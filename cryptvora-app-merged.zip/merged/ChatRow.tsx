import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  BadgeCheck, Pin, User, Bookmark, Phone, Megaphone, Check, CheckCheck, Star, BellOff, Users, Bot, Ban
} from 'lucide-react';
import { cn } from './utils';
import { Chat } from './data';

interface ChatRowProps {
  chat: Chat;
  onLongPress: (x: number, y: number, chat: Chat, rect?: DOMRect) => void;
  onClick: (chat: Chat) => void;
  searchQuery?: string;
  isContextMenuOpen?: boolean;
  isContextSelected?: boolean;
}

const highlightMatch = (text: string, query?: string) => {
  if (!query || !text) return text;
  
  const regex = new RegExp(`(${query})`, 'gi');
  const parts = text.split(regex);
  
  if (parts.length === 1) return text;

  return (
    <>
      {parts.map((part, i) => 
        part.toLowerCase() === query.toLowerCase() ? (
          <span key={i} className="text-blue-500">{part}</span>
        ) : (
          part
        )
      )}
    </>
  );
};

const AvatarIcon = ({ name }: { name?: string }) => {
  switch (name) {
    case 'bookmark': return <Bookmark className="w-6 h-6 text-white" strokeWidth={2.5} />;
    case 'user': return <User className="w-7 h-7 text-white fill-current" />;
    case 'phone': return <Phone className="w-6 h-6 text-white fill-current" />;
    case 'megaphone': return <Megaphone className="w-6 h-6 text-white fill-current" />;
    case 'users': return <Users className="w-7 h-7 text-white fill-current" />;
    default: return null;
  }
};

const TypingIndicator = () => {
  const dotVariants = {
    initial: { y: 0, opacity: 0.3, scale: 0.8 },
    animate: { y: -2, opacity: 1, scale: 1 }
  };
  
  return (
    <div className="flex items-center gap-1">
      <span className="text-[14px] font-medium text-blue-500">typing</span>
      <div className="flex items-center gap-[2px] mt-[4px]">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            variants={dotVariants}
            initial="initial"
            animate="animate"
            transition={{
              duration: 0.4,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut",
              delay: i * 0.15
            }}
            className="w-[3px] h-[3px] bg-blue-500 rounded-full"
          />
        ))}
      </div>
    </div>
  );
};

export const ChatRow: React.FC<ChatRowProps> = ({ chat, onLongPress, onClick, searchQuery, isContextMenuOpen, isContextSelected }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPressing, setIsPressing] = useState(false);
  
  // Long press logic
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const wasLongPress = useRef(false);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsPressing(true);
    wasLongPress.current = false;
    
    const startX = e.clientX;
    const startY = e.clientY;
    containerRef.current?.setAttribute('data-start-y', startY.toString());
    
    longPressTimer.current = setTimeout(() => {
      wasLongPress.current = true;
      setIsPressing(false);
      
      const rect = containerRef.current?.getBoundingClientRect();
      onLongPress(startX, startY, chat, rect);
    }, 400); 
  };

  const handlePointerUp = () => {
    setIsPressing(false);
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const startYStr = containerRef.current?.getAttribute('data-start-y');
    if (startYStr) {
      const startY = parseFloat(startYStr);
      if (Math.abs(e.clientY - startY) > 10) {
        handlePointerUp();
      }
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    if (!wasLongPress.current && !isContextMenuOpen) {
      onClick(chat);
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95, height: 0, margin: 0, padding: 0 }}
      transition={{ type: 'spring', damping: 25, stiffness: 400 }}
      className={cn(
        "relative w-full overflow-hidden transition-opacity duration-300", 
        isContextMenuOpen && !isContextSelected ? "opacity-40" : "opacity-100",
        isContextSelected ? "z-50" : "z-0",
        isContextMenuOpen ? "bg-transparent" : "bg-white"
      )} 
      ref={containerRef}
      onContextMenu={(e) => {
        e.preventDefault();
      }}
    >
      <motion.div
        animate={{ scale: isContextSelected ? 0.98 : 1 }}
        transition={{ type: 'spring', stiffness: 400, damping: 25 }}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onPointerMove={handlePointerMove}
        onClick={handleClick}
        className={cn(
          "relative flex items-center px-[16px] py-[12px] w-full cursor-pointer transition-all duration-200 select-none",
          isContextSelected ? "bg-white rounded-2xl mx-2 w-[calc(100%-16px)] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.15)]" : (isPressing ? "bg-gray-100/80" : "hover:bg-gray-50 active:bg-gray-100/80")
        )}
      >
        {/* Avatar */}
        <div className="relative flex-shrink-0 mr-3.5">
          <div className={cn(
            "w-[56px] h-[56px] rounded-full overflow-hidden flex items-center justify-center relative shadow-[0_2px_8px_rgba(0,0,0,0.08)]",
            chat.avatarType === 'icon' && chat.iconName === 'bookmark' 
              ? "bg-blue-500" 
              : chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-100"
          )}>
            {chat.avatarType === 'image' ? (
              <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
            ) : (
              <AvatarIcon name={chat.iconName} />
            )}
          </div>
          {chat.isOnline && (
            <div className="absolute bottom-[2px] right-[2px] w-[14px] h-[14px] bg-[#22c55e] border-[2.5px] border-white rounded-full z-20 shadow-sm"></div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 flex flex-col justify-center pointer-events-none pb-[2px] border-b border-gray-100/50">
          {/* Top Line */}
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center min-w-0">
              <span className="font-semibold text-[17px] text-gray-900 truncate tracking-tight">
                {highlightMatch(chat.name, searchQuery)}
              </span>
              <AnimatePresence>
              {chat.type === 'bot' && (
                <span key="bot" className="ml-1.5 px-[5px] py-[2px] text-[10px] font-bold tracking-widest rounded bg-blue-100 text-blue-600 uppercase flex items-center gap-0.5">
                  <Bot className="w-3 h-3" /> BOT
                </span>
              )}
              {chat.type === 'channel' && (
                <Megaphone key="channel" className="w-[14px] h-[14px] ml-1.5 text-gray-400 flex-shrink-0" />
              )}
              {chat.isStarred && (
                <motion.div key="starred" initial={{ scale: 0, rotate: -45, opacity: 0, filter: 'drop-shadow(0px 0px 0px rgba(251, 191, 36, 0))' }} animate={{ scale: 1, rotate: 0, opacity: 1, filter: 'drop-shadow(0px 2px 4px rgba(251, 191, 36, 0.4))' }} exit={{ scale: 0, rotate: 45, opacity: 0 }} transition={{ type: 'spring', stiffness: 400, damping: 15, mass: 1 }} className="relative flex items-center justify-center">
                  <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: [1, 2, 1], opacity: [0, 0.4, 0] }} transition={{ duration: 0.6, ease: "easeOut" }} className="absolute inset-0 bg-amber-400 rounded-full blur-[4px]" />
                  <Star className="w-[16px] h-[16px] ml-1.5 text-amber-400 fill-amber-400 flex-shrink-0" />
                </motion.div>
              )}
              {chat.isMuted && (
                <motion.div key="muted" initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }} transition={{ type: 'spring', stiffness: 500, damping: 25, mass: 1 }}>
                  <BellOff className="w-[15px] h-[15px] ml-1.5 text-gray-400 flex-shrink-0" />
                </motion.div>
              )}
              {chat.isBlocked && (
                <motion.div key="blocked" initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }} transition={{ type: 'spring', stiffness: 500, damping: 25, mass: 1 }}>
                  <Ban className="w-[15px] h-[15px] ml-1.5 text-red-400 flex-shrink-0" />
                </motion.div>
              )}
              </AnimatePresence>
              {chat.isVerified && (
                <BadgeCheck className="w-[18px] h-[18px] ml-1.5 text-white fill-blue-500 flex-shrink-0" />
              )}
              {chat.badge && (
                <span className={cn("ml-2 px-1.5 py-[2px] text-[10px] font-bold tracking-wider rounded bg-gray-100 text-gray-500 uppercase")}>
                  {chat.badge.text}
                </span>
              )}
            </div>
            {chat.time && (
              <span className={cn("text-[13px] flex-shrink-0 ml-2 font-medium tracking-wide", chat.unreadCount ? "text-blue-500 font-semibold" : "text-gray-400")}>
                {chat.time}
              </span>
            )}
          </div>

          {/* Subtitle Line for Channel/Group counts */}
          {(chat.type === 'channel' && chat.subscriberCount) || (chat.type === 'group' && chat.memberCount) ? (
            <div className="text-[13px] text-gray-500 leading-none mb-1.5">
              {chat.type === 'channel' ? chat.subscriberCount : chat.memberCount}
            </div>
          ) : null}
          {/* Bottom Line */}
          <div className="flex items-start justify-between">
            <div className="text-[15px] text-gray-500 leading-[1.3] pr-2 break-words flex items-center gap-1.5 min-w-0 flex-1 truncate">
              {!chat.isTyping && chat.readStatus === 'sent' && <Check className="w-[16px] h-[16px] text-gray-400 flex-shrink-0" />}
              {!chat.isTyping && chat.readStatus === 'delivered' && <CheckCheck className="w-[16px] h-[16px] text-gray-400 flex-shrink-0" />}
              {!chat.isTyping && chat.readStatus === 'read' && <CheckCheck className="w-[16px] h-[16px] text-blue-500 flex-shrink-0" />}
              
              <AnimatePresence mode="wait">
                {chat.isTyping ? (
                  <motion.div
                    key="typing"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    <TypingIndicator />
                  </motion.div>
                ) : (
                  <motion.div 
                    key="preview"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                    className="truncate flex-1 tracking-wide"
                  >
                    {chat.previewPrefix && (
                      <span className="text-gray-900 font-medium mr-1">{chat.previewPrefix}:</span>
                    )}
                    {highlightMatch(chat.preview, searchQuery)}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="flex flex-col items-end justify-center flex-shrink-0 pl-1 h-6">
              <AnimatePresence mode="wait">
              {chat.unreadCount ? (
                <motion.div key="unread" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }} className="bg-[#3b82f6] text-white text-[12px] font-bold h-[22px] min-w-[22px] px-1.5 rounded-full flex items-center justify-center shadow-md">
                  {chat.unreadCount}
                </motion.div>
              ) : chat.isPinned ? (
                <motion.div key="pin" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }}>
                  <Pin className="w-4 h-4 text-gray-300 fill-current rotate-45" />
                </motion.div>
              ) : null}
            </AnimatePresence>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};
