import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PostData } from './mockPosts';
import { 
  MoreHorizontal, Heart, MessageCircle, Send, Bookmark, TrendingUp, Star, ArrowLeft
} from 'lucide-react';
import { PinkBadgeIcon, OwlLogo, ReadMoreText } from './SharedComponents';

interface PostViewerProps {
  posts: PostData[];
  initialIndex: number;
  onClose: () => void;
}

export const PostViewer: React.FC<PostViewerProps> = ({ posts, initialIndex, onClose }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Set initial scroll position
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.clientHeight * initialIndex;
    }
  }, [initialIndex]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/90 sm:bg-black/95 flex flex-col"
    >
      <div className="absolute top-0 left-0 right-0 z-10 p-4 flex justify-between items-center bg-gradient-to-b from-black/60 to-transparent">
        <button 
          onClick={onClose}
          className="p-2 bg-black/40 hover:bg-black/60 backdrop-blur-md rounded-full text-white transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <span className="text-white font-bold text-[16px]">Posts</span>
        <div className="w-10"></div>
      </div>

      <div 
        ref={containerRef}
        className="flex-1 overflow-y-auto snap-y snap-mandatory hide-scrollbar relative"
        style={{ scrollBehavior: 'smooth' }}
      >
        {posts.map((post, index) => (
          <PostDetail 
            key={post.id} 
            post={post} 
            isInitial={index === initialIndex}
          />
        ))}
      </div>
    </motion.div>
  );
};

const PostDetail: React.FC<{ post: PostData; isInitial: boolean }> = ({ post, isInitial }) => {
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(post.likes);

  const toggleLike = () => {
    setLiked(!liked);
    setLikes(prev => liked ? prev - 1 : prev + 1);
  };

  return (
    <div className="h-screen w-full snap-start snap-always flex flex-col justify-center max-w-2xl mx-auto px-4">
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100/60 flex flex-col gap-4 relative overflow-hidden">
        <div className="flex justify-between items-center">
          <div className="flex gap-3 items-center">
            <div className="w-[48px] h-[48px] rounded-full bg-gradient-to-b from-[#a855f7] to-[#6b21a8] flex flex-col items-center justify-center shrink-0 shadow-inner relative overflow-hidden cursor-pointer">
              <OwlLogo className="w-[22px] h-[22px] text-white mt-1" />
              <span className="text-[5.5px] font-bold text-white tracking-widest mt-0.5 z-10">Cryptvora</span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5 cursor-pointer">
                <span className="font-bold text-[16px] text-[#111827] tracking-tight hover:underline">{post.author.name}</span>
                <div className="bg-[#3b82f6] rounded-full p-[2px]">
                  <Star className="w-[8px] h-[8px] text-white fill-white" />
                </div>
                <div className="bg-[#3b82f6] rounded-full p-[2.5px]">
                  <PinkBadgeIcon className="w-[8px] h-[8px] text-white" />
                </div>
              </div>
              <div className="text-[13px] text-gray-400 font-medium">
                {post.timestamp}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        {post.image && (
          <motion.div 
            layoutId={isInitial ? `post-image-${post.id}` : undefined}
            className="w-full aspect-square rounded-2xl overflow-hidden -mx-1"
          >
            <img src={post.image} alt="Post media" className="w-full h-full object-cover" />
          </motion.div>
        )}

        <ReadMoreText 
          className="text-[15.5px] text-[#374151] leading-relaxed tracking-wide pt-1"
          text={post.content}
          maxLength={100}
        />

        {post.linkPreview && (
          <div className="bg-[#f8fafc] border border-gray-100 rounded-[20px] p-3 flex items-center mt-1 w-fit">
            <div className="text-blue-500 font-medium flex items-center gap-1.5 text-[13px]">
              <TrendingUp className="w-4 h-4" />
              <span className="text-[#111827] font-bold">{post.linkPreview.symbol}</span> 
              <span className={post.linkPreview.isPositive ? "text-green-500" : "text-red-500"}>{post.linkPreview.change}</span>
            </div>
          </div>
        )}

        <div className="flex justify-between items-center pt-2">
          <div className="flex items-center gap-6">
            <motion.button 
              whileTap={{ scale: 0.85 }} 
              onClick={toggleLike}
              className="flex items-center gap-2 group transition-colors"
            >
              <motion.div
                animate={liked ? { scale: [1, 1.2, 1] } : { scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <Heart className={`w-[22px] h-[22px] transition-colors ${liked ? 'text-red-500 fill-red-500' : 'text-gray-400 group-hover:text-red-500'}`} />
              </motion.div>
              <span className={`font-medium text-[14px] transition-colors ${liked ? 'text-red-500' : 'text-gray-500'}`}>
                {likes > 1000 ? (likes / 1000).toFixed(1) + 'k' : likes}
              </span>
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} className="flex items-center gap-2 text-gray-400 hover:text-gray-600 transition-colors">
              <MessageCircle className="w-[22px] h-[22px] stroke-[1.5]" /> 
              <span className="font-medium text-[14px]">{post.comments}</span>
            </motion.button>
            <motion.button whileTap={{ scale: 0.9 }} className="flex items-center gap-2 text-gray-400 hover:text-gray-600 transition-colors">
              <Send className="w-[20px] h-[20px] stroke-[1.5] -rotate-45 -mt-1" />
              <span className="font-medium text-[14px]">{post.shares}</span>
            </motion.button>
          </div>
          <motion.button whileTap={{ scale: 0.9 }} className="text-gray-400 hover:text-gray-600 transition-colors">
            <Bookmark className="w-[22px] h-[22px] stroke-[1.5]" />
          </motion.button>
        </div>
      </div>
    </div>
  );
};
