/**
 * Real Firebase Authentication setup was declined by the user.
 * This file would normally contain the Firebase app initialization:
 * 
 * import { initializeApp } from 'firebase/app';
 * import { getAuth } from 'firebase/auth';
 * 
 * const firebaseConfig = { ... };
 * export const app = initializeApp(firebaseConfig);
 * export const auth = getAuth(app);
 */

export const isMocked = true;
