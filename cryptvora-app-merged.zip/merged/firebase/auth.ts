/**
 * Real Firebase Authentication setup was declined by the user.
 * This is a mock implementation of the Google Sign-In flow.
 */
export async function signInWithGoogle(): Promise<boolean> {
  // Simulate network request and authentication delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(true);
    }, 1500);
  });
}
