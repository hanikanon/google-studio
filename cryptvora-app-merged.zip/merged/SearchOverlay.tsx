import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Search, X } from 'lucide-react';
import { chats, Chat } from './data';
import { ChatRow } from './ChatRow';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectChat: (chat: Chat) => void;
}

export const SearchOverlay: React.FC<SearchOverlayProps> = ({ isOpen, onClose, onSelectChat }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Chat[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery('');
      setResults([]);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const lowerQuery = query.toLowerCase();
    const filtered = chats.filter(chat => 
      chat.name.toLowerCase().includes(lowerQuery) || 
      chat.preview.toLowerCase().includes(lowerQuery) ||
      (chat.messages && chat.messages.some(m => m.text?.toLowerCase().includes(lowerQuery)))
    );
    setResults(filtered);
  }, [query]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="absolute inset-0 z-50 bg-white flex flex-col"
        >
          <div className="flex items-center gap-2 px-3 py-2 pt-[max(env(safe-area-inset-top),8px)] border-b border-gray-100 shadow-sm">
            <button 
              onClick={onClose}
              className="p-2 text-gray-500 hover:text-indigo-600 hover:bg-gray-100 rounded-full transition-colors shrink-0"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="flex-1 flex items-center bg-gray-100 rounded-full px-4 h-10">
              <Search className="w-4 h-4 text-gray-400 mr-2 shrink-0" />
              <input 
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search conversations..."
                className="flex-1 bg-transparent border-none outline-none text-[15px] text-gray-900 placeholder-gray-500"
              />
              {query && (
                <button 
                  onClick={() => setQuery('')}
                  className="p-1 hover:bg-gray-200 rounded-full text-gray-500 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {query.trim() && results.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center px-6 opacity-60">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-[17px] font-semibold text-gray-900">No results found</h3>
                <p className="text-[14px] text-gray-500 mt-1">We couldn't find any matching conversations or contacts.</p>
              </div>
            ) : (
              <div className="flex flex-col">
                {results.map(chat => (
                  <ChatRow 
                    key={chat.id} 
                    chat={chat} 
                    searchQuery={query}
                    onClick={() => {
                      onSelectChat(chat);
                      onClose();
                    }} 
                    onLongPress={() => {}} 
                  />
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
