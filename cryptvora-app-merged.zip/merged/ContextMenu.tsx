import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Pin, Archive, BellOff, CheckCircle2, Trash2, 
  Star, Ban, Flag, Eraser, User, Share2, ChevronRight, ChevronLeft, Check
} from 'lucide-react';
import { Chat } from './data';
import { cn } from './utils';
import { usePopupManager } from './usePopupManager';

interface ContextMenuProps {
  isOpen: boolean;
  onClose: () => void;
  position: { x: number; y: number } | null;
  chat: Chat | null;
  rect?: DOMRect;
}

interface ContextMenuExtendedProps extends ContextMenuProps {
  onUpdateChat?: (id: string, updates: any) => void;
  onDeleteChat?: (id: string) => void;
  onAction?: (action: string) => void;
  showToast?: (message: string, onUndo?: () => void) => void;
}

export const ContextMenu: React.FC<ContextMenuExtendedProps> = ({ isOpen, onClose, position, chat, rect, onUpdateChat, onDeleteChat, onAction, showToast }) => {
  const [view, setView] = useState<'main' | 'more' | 'confirm-delete' | 'confirm-block' | 'confirm-clear'>('main');

  usePopupManager(isOpen, onClose);

  useEffect(() => {
    if (!isOpen) {
      const timer = setTimeout(() => setView('main'), 300);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  if (!position || !chat) return null;

  const menuWidth = 220;
  const menuHeight = view === 'main' ? 415 : view === 'more' ? 200 : 240;
  
  let top = position.y - 20; 
  if (top + menuHeight > window.innerHeight - 20) {
    top = Math.max(20, window.innerHeight - menuHeight - 20);
  }

  let left = position.x - menuWidth / 2;
  left = Math.max(16, Math.min(left, window.innerWidth - menuWidth - 16));

  const triggerHaptic = () => {
    if (window.navigator?.vibrate) window.navigator.vibrate(20);
  };

  const handleAction = (callback: () => void) => {
    triggerHaptic();
    callback();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="fixed inset-0 w-screen h-screen bg-black/15 backdrop-blur-[2px] z-40 cursor-default touch-none"
            onClick={onClose}
          />
          
          {/* Menu */}
          <motion.div
            layout
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={0.2}
            onDragEnd={(e, { offset, velocity }) => {
              if (offset.y > 50 || velocity.y > 100) {
                onClose();
              }
            }}
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350, mass: 0.8 }}
            style={{ 
              position: 'fixed',
              top,
              left,
              width: menuWidth,
            }}
            className="bg-white/95 backdrop-blur-3xl rounded-[24px] shadow-[0_20px_60px_-10px_rgba(0,0,0,0.25)] z-50 overflow-hidden flex flex-col border border-white/60 touch-none"
            onClick={(e) => e.stopPropagation()}
          >
            <AnimatePresence mode="wait" initial={false}>
              {view === 'confirm-delete' ? (
                <motion.div
                  key="confirm-delete"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 20, opacity: 0 }}
                  transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                  className="flex flex-col py-3 px-4 text-center items-center justify-center min-h-[200px]"
                >
                  <Trash2 className="w-10 h-10 text-red-500 mb-3 bg-red-50 p-2 rounded-full" />
                  <p className="text-sm font-semibold mb-1 text-gray-900">Delete Chat?</p>
                  <p className="text-[13px] text-gray-500 mb-4 leading-tight">This cannot be undone. All history will be removed.</p>
                  <div className="flex gap-2 w-full mt-auto">
                    <button onClick={() => handleAction(() => setView('main'))} className="flex-1 bg-gray-100 hover:bg-gray-200 active:bg-gray-300 py-2 rounded-xl text-sm font-medium transition-colors">Cancel</button>
                    <button onClick={() => handleAction(() => { onDeleteChat?.(chat.id); onClose(); })} className="flex-1 bg-red-500 hover:bg-red-600 active:bg-red-700 text-white py-2 rounded-xl text-sm font-medium shadow-sm transition-colors">Delete</button>
                  </div>
                </motion.div>
              ) : view === 'confirm-block' ? (
                <motion.div
                  key="confirm-block"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 20, opacity: 0 }}
                  transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                  className="flex flex-col py-3 px-4 text-center items-center justify-center min-h-[200px]"
                >
                  <Ban className="w-10 h-10 text-orange-500 mb-3 bg-orange-50 p-2 rounded-full" />
                  <p className="text-sm font-semibold mb-1 text-gray-900">Block User?</p>
                  <p className="text-[13px] text-gray-500 mb-4 leading-tight">You won't receive messages from this user.</p>
                  <div className="flex gap-2 w-full mt-auto">
                    <button onClick={() => handleAction(() => setView('more'))} className="flex-1 bg-gray-100 hover:bg-gray-200 active:bg-gray-300 py-2 rounded-xl text-sm font-medium transition-colors">Cancel</button>
                    <button onClick={() => handleAction(() => { onUpdateChat?.(chat.id, { isBlocked: true }); showToast?.('User blocked'); onClose(); })} className="flex-1 bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white py-2 rounded-xl text-sm font-medium shadow-sm transition-colors">Block</button>
                  </div>
                </motion.div>
              ) : view === 'confirm-clear' ? (
                <motion.div
                  key="confirm-clear"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 20, opacity: 0 }}
                  transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                  className="flex flex-col py-3 px-4 text-center items-center justify-center min-h-[200px]"
                >
                  <Eraser className="w-10 h-10 text-red-500 mb-3 bg-red-50 p-2 rounded-full" />
                  <p className="text-sm font-semibold mb-1 text-gray-900">Clear History?</p>
                  <p className="text-[13px] text-gray-500 mb-4 leading-tight">All messages will be removed permanently.</p>
                  <div className="flex gap-2 w-full mt-auto">
                    <button onClick={() => handleAction(() => setView('more'))} className="flex-1 bg-gray-100 hover:bg-gray-200 active:bg-gray-300 py-2 rounded-xl text-sm font-medium transition-colors">Cancel</button>
                    <button onClick={() => handleAction(() => { onUpdateChat?.(chat.id, { preview: 'Chat history cleared', previewPrefix: '', messages: [] }); showToast?.('History cleared'); onClose(); })} className="flex-1 bg-red-500 hover:bg-red-600 active:bg-red-700 text-white py-2 rounded-xl text-sm font-medium shadow-sm transition-colors">Clear</button>
                  </div>
                </motion.div>
              ) : view === 'main' ? (
                <motion.div 
                  key="main"
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: -20, opacity: 0 }}
                  transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                  className="flex flex-col py-1.5"
                >
                  <MenuButton icon={<BellOff className="w-[18px] h-[18px]" />} label={chat.isMuted ? "Unmute Notifications" : "Mute Notifications"} isActive={chat.isMuted} onClick={() => handleAction(() => { const val = !chat.isMuted; onUpdateChat?.(chat.id, { isMuted: val }); showToast?.(val ? 'Notifications muted' : 'Notifications unmuted'); onClose(); })} />
                  <MenuButton icon={<Pin className="w-[18px] h-[18px]" />} label={chat.isPinned ? "Unpin Chat" : "Pin Chat"} isActive={chat.isPinned} onClick={() => handleAction(() => { const val = !chat.isPinned; onUpdateChat?.(chat.id, { isPinned: val }); showToast?.(val ? 'Chat pinned' : 'Chat unpinned'); onClose(); })} />
                  <MenuButton icon={<Archive className="w-[18px] h-[18px]" />} label={chat.isArchived ? "Unarchive Chat" : "Archive Chat"} isActive={chat.isArchived} onClick={() => handleAction(() => { const val = !chat.isArchived; onUpdateChat?.(chat.id, { isArchived: val }); showToast?.(val ? 'Chat archived' : 'Chat unarchived', () => onUpdateChat?.(chat.id, { isArchived: !val })); onClose(); })} />
                  <MenuButton icon={<CheckCircle2 className="w-[18px] h-[18px]" />} label={chat.unreadCount ? "Mark as Read" : "Mark as Unread"} isActive={!chat.unreadCount} 
                    onClick={() => handleAction(() => { const val = chat.unreadCount ? 0 : 1; onUpdateChat?.(chat.id, { unreadCount: val }); showToast?.(val ? 'Marked as unread' : 'Marked as read'); onClose(); })}
                  />
                  <MenuButton icon={<Star className="w-[18px] h-[18px]" />} label={chat.isStarred ? "Remove from Favorites" : "Add to Favorites"} isActive={chat.isStarred} onClick={() => handleAction(() => { const val = !chat.isStarred; onUpdateChat?.(chat.id, { isStarred: val }); showToast?.(val ? 'Added to Favorites' : 'Removed from Favorites'); onClose(); })} />
                  <MenuButton icon={<User className="w-[18px] h-[18px]" />} label="View Profile" onClick={() => handleAction(() => { onAction?.('View Profile'); onClose(); })} />
                  <MenuButton icon={<Share2 className="w-[18px] h-[18px]" />} label="Share Contact" onClick={() => handleAction(() => { onAction?.('Share Contact'); onClose(); })} />
                  <MenuButton 
                    icon={<ChevronRight className="w-[18px] h-[18px]" />} 
                    label="More" 
                    onClick={() => handleAction(() => setView('more'))} 
                  />
                  
                  <div className="h-[1px] bg-gray-200/50 my-1 mx-2" />
                  
                  <MenuButton 
                    icon={<Trash2 className="w-[18px] h-[18px]" />} 
                    label="Delete Conversation" 
                    className="text-red-500 hover:bg-red-50" 
                    iconContainerClassName="bg-red-50 text-red-500"
                    onClick={() => handleAction(() => setView('confirm-delete'))}
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="more"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 20, opacity: 0 }}
                  transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                  className="flex flex-col py-1.5"
                >
                  <MenuButton 
                    icon={<ChevronLeft className="w-[18px] h-[18px]" />} 
                    label="Back" 
                    onClick={() => handleAction(() => setView('main'))} 
                    className="font-bold"
                  />
                  
                  <div className="h-[1px] bg-gray-200/50 my-1 mx-2" />
                  
                  <MenuButton icon={<Eraser className="w-[18px] h-[18px]" />} label="Clear Chat History" onClick={() => handleAction(() => setView('confirm-clear'))} />
                  <MenuButton 
                    icon={<Ban className="w-[18px] h-[18px]" />} 
                    label={chat.isBlocked ? "Unblock User" : "Block User"}
                    className="text-orange-500 hover:bg-orange-50"
                    iconContainerClassName="bg-orange-50 text-orange-500"
                    onClick={() => handleAction(() => chat.isBlocked ? (onUpdateChat?.(chat.id, { isBlocked: false }), showToast?.('User unblocked'), onClose()) : setView('confirm-block'))}
                  />
                  <MenuButton 
                    icon={<Flag className="w-[18px] h-[18px]" />} 
                    label="Report User" 
                    className="text-red-500 hover:bg-red-50"
                    iconContainerClassName="bg-red-50 text-red-500"
                    onClick={() => handleAction(() => { onAction?.('Report User'); onClose(); })}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

interface MenuButtonProps {
  icon: React.ReactNode;
  label: string;
  className?: string;
  iconContainerClassName?: string;
  onClick?: () => void;
  isActive?: boolean;
}

const MenuButton = ({ icon, label, className = "", iconContainerClassName = "bg-gray-100/50 text-gray-700", onClick, isActive }: MenuButtonProps) => {
  return (
    <motion.button 
      onClick={onClick}
      whileTap={{ scale: 0.98 }}
      className={cn(
        "w-[calc(100%-12px)] px-2.5 py-1.5 flex items-center gap-2.5 text-left transition-colors text-gray-800 text-[14px] font-medium mx-1.5 rounded-[10px] active:bg-gray-100 hover:bg-gray-50",
        className
      )}
    >
      <motion.div 
        whileHover={{ scale: 1.05 }}
        className={cn("w-8 h-8 rounded-[8px] flex items-center justify-center flex-shrink-0 transition-colors", iconContainerClassName)}
      >
        {icon}
      </motion.div>
      <span className="flex-1 tracking-wide">{label}</span>
      <AnimatePresence>
        {isActive && (
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.5, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 400 }}
            className="ml-auto flex items-center"
          >
            <Check className="w-[18px] h-[18px] text-[#3b82f6]" strokeWidth={2.5} />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.button>
  );
};
