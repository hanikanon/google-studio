
import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useMotionValueEvent, AnimatePresence } from 'framer-motion';
import { Header } from './Header';
import { ChatRow } from './ChatRow';
import { FAB } from './FAB';
import { FloatingDock } from './FloatingDock';
import { ContextMenu } from './ContextMenu';
import { MessagesPage } from './MessagesPage';
import { SearchOverlay } from './SearchOverlay';
import { ActionFlowOverlay } from './ActionFlowOverlay';
import { ProfilePage } from './ProfilePage';
import { SettingsApp } from './SettingsApp';
import { chats, Chat } from './data';
import { cn } from './utils';

function ChatApp() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll({ container: scrollContainerRef });

  const [headerState, setHeaderState] = useState<'full' | 'tabs-only' | 'hidden'>('full');
  const [isFabVisible, setIsFabVisible] = useState(true);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [activeFlow, setActiveFlow] = useState<string | null>(null);
  const [isDockOpen, setIsDockOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState('All');

  const [toast, setToast] = useState<{ id: number; message: string; onUndo?: () => void } | null>(null);

  const showToast = (message: string, onUndo?: () => void) => {
    const id = Date.now();
    setToast({ id, message, onUndo });
    setTimeout(() => {
      setToast(current => (current?.id === id ? null : current));
    }, 4000);
  };

  const [chatList, setChatList] = useState<Chat[]>(() => {
    try {
      const saved = localStorage.getItem('chatApp_chats');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return chats;
  });

  useEffect(() => {
    try {
      localStorage.setItem('chatApp_chats', JSON.stringify(chatList));
    } catch (e) {}
  }, [chatList]);

  const updateChat = (id: string, updates: Partial<Chat>) => {
    setChatList(prev => prev.map(c => (c.id === id ? { ...c, ...updates } : c)));
    setSelectedChat(prev => (prev?.id === id ? { ...prev, ...updates } : prev));
    setContextMenuState(prev =>
      prev.chat?.id === id ? { ...prev, chat: { ...prev.chat, ...updates } } : prev,
    );
  };

  const deleteChat = (id: string) => {
    setChatList(prev => {
      const chatIndex = prev.findIndex(c => c.id === id);
      if (chatIndex > -1) {
        const chat = prev[chatIndex];
        showToast('Conversation deleted', () => {
          setChatList(current => {
            const newChats = [...current];
            newChats.splice(chatIndex, 0, chat);
            return newChats;
          });
        });
      }
      return prev.filter(c => c.id !== id);
    });
  };

  const [contextMenuState, setContextMenuState] = useState<{
    isOpen: boolean;
    position: { x: number; y: number } | null;
    chat: Chat | null;
    rect?: DOMRect;
  }>({
    isOpen: false,
    position: null,
    chat: null,
  });

  useMotionValueEvent(scrollY, 'change', latest => {
    const previous = scrollY.getPrevious() || 0;
    const isScrollingDown = latest > previous;

    if (latest <= 20) {
      if (headerState !== 'full') setHeaderState('full');
      if (!isFabVisible) setIsFabVisible(true);
    } else if (isScrollingDown && latest > 30) {
      if (headerState !== 'hidden') setHeaderState('hidden');
      if (isFabVisible) setIsFabVisible(false);
    } else if (!isScrollingDown && latest < previous - 2) {
      if (headerState !== 'tabs-only') setHeaderState('tabs-only');
      if (!isFabVisible) setIsFabVisible(true);
    }
  });

  const handleLongPress = (x: number, y: number, chat: Chat, rect?: DOMRect) => {
    setContextMenuState({ isOpen: true, position: { x, y }, chat, rect });
    if (window.navigator?.vibrate) window.navigator.vibrate(50);
  };

  const handleChatClick = (chat: Chat) => setSelectedChat(chat);
  const handleBackFromChat = () => setSelectedChat(null);
  const handleBackFromProfile = () => setIsProfileOpen(false);

  // Any secondary screen being open pushes the chat list to the left
  const isSecondaryOpen = !!selectedChat || isProfileOpen || isSettingsOpen;

  const handleDockNavigate = (route: string) => {
    if (route === 'Profile') {
      setIsProfileOpen(true);
      setIsDockOpen(false);
    } else if (route === 'Settings') {
      setIsSettingsOpen(true);
      setIsDockOpen(false);
    } else {
      showToast(`Navigating to ${route}`);
    }
  };

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden text-gray-900 font-sans selection:bg-transparent">
      {/* ── Main Screen: Chat List ─────────────────────────────────────────── */}
      <motion.div
        className="w-full h-full absolute inset-0 bg-white z-10"
        initial={false}
        animate={{
          x: isSecondaryOpen ? '-30%' : '0%',
          opacity: isSecondaryOpen ? 0.4 : 1,
          scale: isSecondaryOpen ? 0.96 : 1,
        }}
        transition={{ type: 'spring', damping: 30, stiffness: 350, mass: 0.9 }}
      >
        <Header
          headerState={headerState}
          onSearchClick={() => setIsSearchOpen(true)}
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
        />

        <div
          ref={scrollContainerRef}
          className="w-full h-full overflow-y-auto overflow-x-hidden hide-scrollbar touch-pan-y overscroll-none"
          style={{ paddingTop: '90px', paddingBottom: '100px' }}
        >
          <div className="flex flex-col relative z-0">
            <AnimatePresence mode="popLayout">
              {chatList
                .filter(chat => {
                  if (chat.isArchived) return false;
                  if (activeFilter === 'Unread') return chat.unreadCount && chat.unreadCount > 0;
                  if (activeFilter === 'Groups') return chat.type === 'group';
                  if (activeFilter === 'Channels') return chat.type === 'channel';
                  if (activeFilter === 'Favorites') return chat.isStarred;
                  if (activeFilter === 'Pinned') return chat.isPinned;
                  return true;
                })
                .map(chat => (
                  <ChatRow
                    key={chat.id}
                    chat={chat}
                    onLongPress={handleLongPress}
                    onClick={handleChatClick}
                    isContextMenuOpen={contextMenuState.isOpen || contextMenuState.chat !== null}
                    isContextSelected={contextMenuState.chat?.id === chat.id}
                  />
                ))}
            </AnimatePresence>
          </div>
        </div>

        <FAB
          isVisible={isFabVisible}
          onAction={action => setActiveFlow(action)}
          onLongPressAction={() => setIsDockOpen(true)}
        />
        <FloatingDock
          isOpen={isDockOpen}
          onClose={() => setIsDockOpen(false)}
          onNavigate={handleDockNavigate}
        />

        <ContextMenu
          isOpen={contextMenuState.isOpen}
          position={contextMenuState.position}
          chat={contextMenuState.chat}
          rect={contextMenuState.rect}
          onUpdateChat={updateChat}
          onDeleteChat={deleteChat}
          onAction={action => setActiveFlow(action)}
          showToast={showToast}
          onClose={() => {
            setContextMenuState(prev => ({ ...prev, isOpen: false }));
            setTimeout(() => {
              setContextMenuState(prev =>
                prev.isOpen ? prev : { ...prev, chat: null, position: null, rect: undefined },
              );
            }, 300);
          }}
        />

        <SearchOverlay
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
          onSelectChat={handleChatClick}
        />
      </motion.div>

      {/* ── Secondary Screen: Messages ─────────────────────────────────────── */}
      <AnimatePresence>
        {selectedChat && (
          <MessagesPage
            key="messages-page"
            chat={selectedChat}
            onBack={handleBackFromChat}
            onUpdateChat={updateChat}
          />
        )}
      </AnimatePresence>

      {/* ── Secondary Screen: Profile ──────────────────────────────────────── */}
      <AnimatePresence>
        {isProfileOpen && (
          <motion.div
            key="profile-screen"
            initial={{ x: '100%', opacity: 0.95 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0.95 }}
            transition={{ type: 'spring', damping: 28, stiffness: 300, mass: 0.8 }}
            className="absolute inset-0 z-50 w-full h-full overflow-y-auto bg-white"
          >
            <ProfilePage onBack={handleBackFromProfile} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Secondary Screen: Settings ─────────────────────────────────────── */}
      <AnimatePresence>
        {isSettingsOpen && (
          <motion.div
            key="settings-screen"
            initial={{ x: '100%', opacity: 0.95 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0.95 }}
            transition={{ type: 'spring', damping: 28, stiffness: 300, mass: 0.8 }}
            className="absolute inset-0 z-50 w-full h-full overflow-hidden bg-black"
          >
            <SettingsApp onExit={() => setIsSettingsOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      <ActionFlowOverlay action={activeFlow} onClose={() => setActiveFlow(null)} showToast={showToast} />

      {/* ── Toast ─────────────────────────────────────────────────────────── */}
      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="absolute bottom-[100px] left-1/2 -translate-x-1/2 z-[60] bg-gray-900 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 min-w-[280px] border border-gray-700/50"
          >
            <span className="flex-1 text-[14px] font-medium tracking-wide">{toast.message}</span>
            {toast.onUndo && (
              <button
                onClick={() => {
                  toast.onUndo!();
                  setToast(null);
                }}
                className="text-blue-400 font-bold text-[14px] uppercase tracking-wider px-2 py-1 active:bg-white/10 rounded-lg transition-colors"
              >
                Undo
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default ChatApp;
