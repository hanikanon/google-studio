import React, { useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, Image as ImageIcon, Video, FileText, Music, MapPin, User, BarChart2, Smile, Sticker } from 'lucide-react';
import { cn } from './utils';

interface AttachmentMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (type: string) => void;
}

export const AttachmentMenu: React.FC<AttachmentMenuProps> = ({ isOpen, onClose, onSelect }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  const items = [
    { id: 'camera', icon: Camera, label: 'Camera', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { id: 'gallery', icon: ImageIcon, label: 'Gallery', color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { id: 'video', icon: Video, label: 'Videos', color: 'text-rose-500', bg: 'bg-rose-500/10' },
    { id: 'document', icon: FileText, label: 'Documents', color: 'text-indigo-500', bg: 'bg-indigo-500/10' },
    { id: 'audio', icon: Music, label: 'Audio', color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { id: 'contact', icon: User, label: 'Contacts', color: 'text-cyan-500', bg: 'bg-cyan-500/10' },
    { id: 'location', icon: MapPin, label: 'Location', color: 'text-green-500', bg: 'bg-green-500/10' },
    { id: 'poll', icon: BarChart2, label: 'Poll', color: 'text-orange-500', bg: 'bg-orange-500/10' },
    { id: 'gif', icon: Smile, label: 'GIF', color: 'text-pink-500', bg: 'bg-pink-500/10' },
    { id: 'sticker', icon: Sticker, label: 'Sticker', color: 'text-teal-500', bg: 'bg-teal-500/10' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 z-[55] bg-black/40 backdrop-blur-sm cursor-default"
          />
          <motion.div
            ref={containerRef}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 1 }}
            onDragEnd={(e, info) => {
              if (info.offset.y > 100 || info.velocity.y > 500) {
                onClose();
              }
            }}
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350, mass: 0.8 }}
            className="absolute bottom-0 left-0 right-0 z-[60] bg-white/80 backdrop-blur-3xl rounded-t-[32px] pt-4 pb-8 px-4 shadow-[0_-10px_40px_rgba(0,0,0,0.15)] flex flex-col touch-pan-y"
          >
            <div className="w-10 h-1.5 bg-gray-300/80 rounded-full mx-auto mb-6 shrink-0" />
            
            <div className="overflow-y-auto no-scrollbar pb-safe max-h-[60vh]">
              <div className="grid grid-cols-4 gap-y-6 gap-x-4 w-full">
                {items.map((item, i) => (
                  <motion.button
                    key={item.id}
                    initial={{ opacity: 0, scale: 0.8, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ delay: i * 0.03, type: 'spring', stiffness: 300, damping: 20 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      if (navigator.vibrate) navigator.vibrate(10);
                      onSelect(item.id);
                    }}
                    className="flex flex-col items-center gap-2 outline-none group"
                  >
                    <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-sm", item.bg, item.color)}>
                      <item.icon className="w-7 h-7" strokeWidth={1.5} />
                    </div>
                    <span className="text-[12px] font-medium text-gray-700 tracking-tight">{item.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
