import { motion } from 'framer-motion';
import { useEffect } from 'react';

export default function SplashScreen({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3000); 
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-white"
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
    >
      <motion.div
        className="relative flex items-center text-6xl font-black tracking-tight text-gray-900"
        animate={{ scale: [1, 1, 0.85] }}
        transition={{ duration: 3, times: [0, 0.8, 1], ease: "easeInOut" }}
      >
        <motion.span
          initial={{ x: -80, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.2, 0.65, 0.3, 0.9] }}
        >
          O
        </motion.span>
        <motion.span
          initial={{ y: -80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.2, 0.65, 0.3, 0.9], delay: 0.1 }}
        >
          w
        </motion.span>
        <motion.span
          initial={{ x: 80, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.2, 0.65, 0.3, 0.9], delay: 0.2 }}
        >
          l
        </motion.span>
        <motion.span
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.2, 0.65, 0.3, 0.9], delay: 0.3 }}
        >
          i
        </motion.span>
        <motion.span
          initial={{ x: -80, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.2, 0.65, 0.3, 0.9], delay: 0.4 }}
        >
          n
        </motion.span>
        <motion.span
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "backOut", delay: 1 }}
          className="text-blue-600"
        >
          o
        </motion.span>

        {/* Subtle glow that appears when they meet */}
        <motion.div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl pointer-events-none"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2, duration: 1 }}
        />
      </motion.div>
    </motion.div>
  );
}
