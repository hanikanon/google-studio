import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export default function AnimatedTitle({ onAnimationComplete }: { onAnimationComplete?: () => void }) {
  const [glow, setGlow] = useState(false);

  // Start positions for each letter: elegant entry from varying distances and angles
  const letters = [
    { char: 'O', x: "-50vw", y: "-30vh", rotate: -25, scale: 1.5 },
    { char: 'w', x: "30vw", y: "-50vh", rotate: 45, scale: 0.8 },
    { char: 'l', x: "50vw", y: "40vh", rotate: -45, scale: 1.2 },
    { char: 'i', x: 0, y: "60vh", rotate: 90, scale: 1.8 },
    { char: 'n', x: "-60vw", y: "20vh", rotate: -90, scale: 0.9 },
    { char: 'o', x: "40vw", y: "-10vh", rotate: 60, scale: 1.1 },
  ];

  useEffect(() => {
    // Reveal the glow right as letters land
    const glowTimer = setTimeout(() => {
      setGlow(true);
    }, 1600);
    
    // Total animation time before revealing the rest of the UI
    const completeTimer = setTimeout(() => {
      if (onAnimationComplete) onAnimationComplete();
    }, 2800);

    return () => {
      clearTimeout(glowTimer);
      clearTimeout(completeTimer);
    };
  }, [onAnimationComplete]);

  return (
    <motion.div 
      className="relative flex items-center justify-center"
      animate={{ scale: glow ? [1, 1.02, 1] : 1 }}
      transition={{ duration: 1.2, ease: "easeInOut" }}
    >
      {/* Subtle background glow that appears after assembly */}
      <motion.div
        className="absolute inset-0 bg-blue-500/20 blur-[50px] rounded-full scale-150 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: glow ? 1 : 0 }}
        transition={{ duration: 2, ease: "easeOut" }}
      />
      
      {/* Custom Wordmark */}
      <div className="relative flex items-center font-display text-[4.5rem] sm:text-[5.5rem] font-black tracking-[-0.04em] text-gray-900 z-10 leading-none">
        {letters.map((letter, index) => (
          <motion.span
            key={index}
            initial={{ 
              x: letter.x, 
              y: letter.y, 
              rotate: letter.rotate,
              scale: letter.scale,
              opacity: 0,
              filter: "blur(24px)"
            }}
            animate={{ 
              x: 0, 
              y: 0, 
              rotate: 0,
              scale: 1,
              opacity: 1,
              filter: "blur(0px)"
            }}
            transition={{ 
              duration: 1.8, 
              delay: index * 0.12, 
              ease: [0.16, 1, 0.3, 1] // Custom spring-like premium easing
            }}
            className={`inline-block ${letter.char === 'o' && index === 5 ? 'text-blue-600' : ''}`}
          >
            {letter.char}
          </motion.span>
        ))}
      </div>
    </motion.div>
  );
}
