import { motion } from 'framer-motion';
import { useMemo } from 'react';

const ICONS = [
  'XAU/USD', 'EUR/USD', 'GBP/USD', 'USD/JPY', 'BTC/USD', 'ETH/USD',
  'NASDAQ', 'S&P 500', 'DOW JONES', 'NIKKEI', 'DAX', 'FOREX', 'CRYPTO'
];

export default function TradingBackground() {
  const patternCells = useMemo(() => {
    const items: Array<{id: number, text: string, rotate: number, size: number, opacity: number, color: string, left: number, top: number}> = [];
    
    // Stable pseudo-random generator for consistent renders
    let seed = 42;
    const random = () => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };

    const isOverlapping = (x: number, y: number) => {
      for (const item of items) {
        // Distance check in percentages.
        // Horizontal distance must be at least 22% (approx 90px on mobile)
        // Vertical distance must be at least 10% (approx 80px on mobile)
        const dx = Math.abs(x - item.left);
        const dy = Math.abs(y - item.top);
        if (dx < 22 && dy < 10) {
          return true;
        }
      }
      return false;
    };

    const isCenterSafe = (x: number, y: number) => {
      // Avoid the center area where the logo, title, and button are located
      if (x > 15 && x < 85 && y > 35 && y < 65) {
        return false;
      }
      return true;
    };

    let attempts = 0;
    let lastIconIndex = -1;

    // Try to place items without overlapping. Use 18 items max
    while (items.length < 18 && attempts < 2000) {
      attempts++;
      
      // Keep items slightly away from the extreme edges
      const left = 2 + random() * 96; 
      const top = 2 + random() * 96;

      if (!isOverlapping(left, top) && isCenterSafe(left, top)) {
        let iconIndex = Math.floor(random() * ICONS.length);
        if (iconIndex === lastIconIndex) {
          iconIndex = (iconIndex + 1) % ICONS.length;
        }
        lastIconIndex = iconIndex;
        
        const text = ICONS[iconIndex];
        const rotate = Math.floor(random() * 91) - 45; // -45 to +45
        const size = 16 + Math.floor(random() * 20); // 16px to 36px
        // Make every watermark slightly darker (opacity around 12-18%)
        const opacity = 0.12 + random() * 0.06; 
        const color = random() > 0.6 ? '#60A5FA' : '#94A3B8'; // 40% blue, 60% gray

        items.push({
          id: items.length,
          text,
          rotate,
          size,
          opacity,
          color,
          left,
          top
        });
      }
    }
    
    return items;
  }, []);

  return (
    <div className="absolute inset-0 z-0 overflow-hidden bg-white pointer-events-none">
      
      {/* Very Soft Animated Gradients BEHIND the text */}
      <motion.div 
        className="absolute top-[-20%] left-[-10%] w-[120%] h-[120%] bg-gradient-to-br from-blue-50/40 via-transparent to-transparent rounded-full blur-[120px] pointer-events-none z-0"
        animate={{ 
          rotate: [0, 45, 0],
          scale: [1, 1.05, 1]
        }}
        transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
      />
      
      {/* Scattered Background Elements */}
      <div className="absolute inset-0 z-10">
        {patternCells.map((cell) => {
          return (
            <motion.div
              key={cell.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: cell.opacity }}
              transition={{ duration: 2, delay: (cell.id % 10) * 0.1 }}
              style={{
                position: 'absolute',
                left: `${cell.left}%`,
                top: `${cell.top}%`,
                transform: `translate(-50%, -50%) rotate(${cell.rotate}deg)`,
                color: cell.color,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <span style={{ fontSize: cell.size }} className="font-display font-bold whitespace-nowrap tracking-wider uppercase">
                {cell.text}
              </span>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
