import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

export default function FloatingParticles() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
      {Array.from({ length: 25 }).map((_, i) => {
        const initialX = Math.random() * 100;
        const initialY = Math.random() * 100;
        const size = Math.random() * 3 + 1;
        const duration = Math.random() * 20 + 20;
        const delay = Math.random() * 10;
        
        // Random drift for x and y to make it feel like floating nodes
        const xDrift = (Math.random() - 0.5) * 20;
        
        return (
          <motion.div
            key={`particle-${i}`}
            className="absolute bg-blue-400 rounded-full z-0"
            style={{ width: size, height: size, left: `${initialX}vw`, top: `${initialY}vh` }}
            initial={{ opacity: 0, x: 0, y: 0 }}
            animate={{
              y: [0, -100],
              x: [0, xDrift, 0],
              opacity: [0, 0.2, 0]
            }}
            transition={{
              duration: duration,
              repeat: Infinity,
              ease: "linear",
              delay: delay
            }}
          />
        );
      })}
    </div>
  );
}
