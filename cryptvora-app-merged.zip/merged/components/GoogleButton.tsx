import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, ShieldCheck } from 'lucide-react';

interface GoogleButtonProps {
  onClick: () => Promise<void>;
}

export default function GoogleButton({ onClick }: GoogleButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      await onClick();
    } finally {
      setTimeout(() => setIsLoading(false), 500);
    }
  };

  return (
    <motion.button
      onClick={handleClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      className="relative flex items-center w-full max-w-[280px] mx-auto py-2 px-3 bg-white backdrop-blur-2xl rounded-full overflow-hidden group select-none shadow-[0_4px_20px_-8px_rgba(0,0,0,0.12)] border border-gray-200 hover:shadow-[0_8px_30px_-10px_rgba(37,99,235,0.15)] hover:border-blue-200 hover:bg-gray-50 transition-all duration-300"
    >
      {/* Tap/Hover Glow overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-50/0 via-blue-50/40 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-in-out" />
      <div className="absolute inset-0 group-active:bg-black/5 transition-colors duration-200" />
      
      <div className="relative flex items-center justify-between w-full z-10">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 bg-white rounded-full shadow-[0_2px_8px_-4px_rgba(0,0,0,0.1)] border border-gray-100 transition-transform duration-300 group-hover:scale-105">
            <svg className="w-5 h-5" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.64 24.55c0-1.65-.15-3.23-.44-4.75H24v9.03h12.73c-.55 2.97-2.22 5.5-4.78 7.23l7.41 5.74c4.35-4.01 6.87-9.92 6.87-16.51z" />
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.41-5.74c-2.06 1.38-4.72 2.2-8.48 2.2-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
            </svg>
          </div>
          
          <div className="flex flex-col items-start pr-1 text-left">
            <span className="text-[15px] font-semibold text-gray-900 tracking-tight leading-tight">Continue with Google</span>
            <span className="text-[11px] font-medium text-gray-500 mt-0.5 leading-tight line-clamp-1">Secure authentication</span>
          </div>
        </div>

        <div className="flex items-center justify-center w-10 h-10 pr-2">
          <AnimatePresence mode="wait">
            {isLoading ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0, rotate: -90, scale: 0.5 }}
                animate={{ opacity: 1, rotate: 0, scale: 1 }}
                exit={{ opacity: 0, rotate: 90, scale: 0.5 }}
                transition={{ duration: 0.2 }}
              >
                <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
              </motion.div>
            ) : (
              <motion.div
                key="shield"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.5 }}
                transition={{ duration: 0.2 }}
              >
                <ShieldCheck className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors duration-300" strokeWidth={2} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.button>
  );
}
