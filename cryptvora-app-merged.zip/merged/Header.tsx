import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Bell, MessageCircle, Users, Megaphone, User } from 'lucide-react';
import { cn } from './utils';
import { Logo } from './Logo';

interface HeaderProps {
  headerState?: 'full' | 'tabs-only' | 'hidden';
  onSearchClick: () => void;
  activeFilter: string;
  onFilterChange: (filter: string) => void;
}

const TabButton = ({ 
  label, 
  icon, 
  count, 
  isActive, 
  onClick 
}: { 
  label: string, 
  icon?: React.ReactNode, 
  count?: number, 
  isActive: boolean, 
  onClick: () => void 
}) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative flex items-center justify-center h-[34px] px-3.5 rounded-full font-medium text-[13.5px] transition-colors whitespace-nowrap flex-shrink-0",
        isActive ? "text-white" : "text-gray-500 hover:bg-gray-100/80 bg-gray-50/50"
      )}
    >
      {isActive && (
        <motion.div
          layoutId="active-pill"
          className="absolute inset-0 rounded-full bg-[#3b82f6] shadow-sm"
          transition={{ type: "spring", stiffness: 400, damping: 30 }}
        />
      )}
      <div className="flex items-center gap-1.5 z-10 relative">
        {icon && (
          <span className={cn("w-[14px] h-[14px]", isActive ? "text-white" : "text-gray-400")}>
            {icon}
          </span>
        )}
        {label}
        {count !== undefined && (
          <span className={cn(
            "ml-0.5 flex items-center justify-center text-[10.5px] font-bold h-[16px] min-w-[16px] px-1 rounded-full transition-colors",
            isActive ? "bg-white/25 text-white" : "bg-gray-200/60 text-gray-500"
          )}>
            {count}
          </span>
        )}
      </div>
    </button>
  );
};

export const Header: React.FC<HeaderProps> = ({ headerState = 'full', onSearchClick, activeFilter, onFilterChange }) => {

  return (
    <motion.div
      initial={false}
      animate={{ 
        y: headerState === 'hidden' ? '-100%' : '0%',
      }}
      transition={{ type: 'spring', damping: 28, stiffness: 300, mass: 0.8 }}
      className="absolute top-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-xl pt-[max(env(safe-area-inset-top),8px)] shadow-[0_1px_4px_rgba(0,0,0,0.03)]"
    >
      <div className="flex flex-col w-full pb-1.5">
        {/* Top Bar */}
        <motion.div 
          initial={false}
          animate={{ 
            height: headerState !== 'tabs-only' ? 44 : 0, 
            opacity: headerState !== 'tabs-only' ? 1 : 0,
            marginBottom: headerState !== 'tabs-only' ? 6 : 0
          }}
          transition={{ type: 'spring', damping: 28, stiffness: 300, mass: 0.8 }}
          className="overflow-hidden"
        >
          <div className="flex items-center justify-between h-[44px] relative px-3">
            {/* Left: Search Icon */}
            <button 
              onClick={onSearchClick}
              className="w-10 h-10 flex items-center justify-start rounded-full text-gray-500 hover:text-blue-500 transition-colors z-10 active:scale-90"
            >
              <Search className="w-[20px] h-[20px]" strokeWidth={2.5} />
            </button>
            
            {/* Center: Logo */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
               <span className="text-[26px] tracking-wide text-[#262626]" style={{ fontFamily: "'Grand Hotel', cursive", transform: "translateY(1px)" }}>
                 Hoo-X
               </span>
            </div>

            {/* Right: Bell Icon */}
            <button className="w-10 h-10 flex items-center justify-end rounded-full text-gray-500 hover:text-blue-500 transition-colors z-10 active:scale-90">
              <Bell className="w-[20px] h-[20px]" strokeWidth={2.5} />
            </button>
          </div>
        </motion.div>

        {/* Filter Chips Container */}
        <div className="flex overflow-x-auto hide-scrollbar gap-1.5 px-3 snap-x">
          <TabButton 
            label="All" 
            icon={<MessageCircle className="w-[14px] h-[14px]" />} 
            count={12} 
            isActive={activeFilter === 'All'} 
            onClick={() => onFilterChange('All')} 
          />
          <TabButton 
            label="Unread" 
            count={3} 
            isActive={activeFilter === 'Unread'} 
            onClick={() => onFilterChange('Unread')} 
          />
          <TabButton 
            label="Groups" 
            icon={<Users className="w-[14px] h-[14px]" />} 
            isActive={activeFilter === 'Groups'} 
            onClick={() => onFilterChange('Groups')} 
          />
          <TabButton 
            label="Channels" 
            icon={<Megaphone className="w-[14px] h-[14px]" />} 
            isActive={activeFilter === 'Channels'} 
            onClick={() => onFilterChange('Channels')} 
          />
          <TabButton 
            label="Favorites" 
            isActive={activeFilter === 'Favorites'} 
            onClick={() => onFilterChange('Favorites')} 
          />
          <TabButton 
            label="Pinned" 
            isActive={activeFilter === 'Pinned'} 
            onClick={() => onFilterChange('Pinned')} 
          />
        </div>
      </div>
    </motion.div>
  );
};
