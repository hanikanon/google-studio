import React, { useMemo } from "react";
import { RouterProvider, createMemoryHistory } from "@tanstack/react-router";
import { getRouter } from "./src/router";
import { SettingsExitContext } from "./src/SettingsExitContext";

interface SettingsAppProps {
  onExit: () => void;
}

// Mounts the full settings module (TanStack Router based) in an isolated
// memory-history router so it never touches the real browser URL and always
// resets to the settings index the next time it's opened.
export function SettingsApp({ onExit }: SettingsAppProps) {
  const router = useMemo(() => {
    const history = createMemoryHistory({ initialEntries: ["/"] });
    return getRouter(history);
  }, []);

  return (
    <SettingsExitContext.Provider value={onExit}>
      <RouterProvider router={router} />
    </SettingsExitContext.Provider>
  );
}

export default SettingsApp;
