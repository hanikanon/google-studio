import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Save, ArrowLeft } from 'lucide-react';

interface ComposeModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialContent?: string;
  onSaveDraft: (content: string) => void;
  onPost: (content: string) => void;
}

export const ComposeModal = ({ isOpen, onClose, initialContent = '', onSaveDraft, onPost }: ComposeModalProps) => {
  const [content, setContent] = useState(initialContent);

  useEffect(() => {
    if (isOpen) {
      setContent(initialContent);
    }
  }, [isOpen, initialContent]);

  if (!isOpen) return null;

  const handlePost = () => {
    if (!content.trim()) return;
    onPost(content);
    setContent('');
    onClose();
  };

  const handleSaveDraft = () => {
    if (!content.trim()) return;
    onSaveDraft(content);
    setContent('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50">
      <motion.div
        initial={{ opacity: 0, y: "100%" }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: "100%" }}
        transition={{ type: "spring", stiffness: 400, damping: 30 }}
        className="w-full h-full sm:h-auto sm:max-h-[85vh] sm:max-w-xl bg-white sm:rounded-2xl flex flex-col overflow-hidden shadow-2xl"
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 -ml-2 rounded-full hover:bg-gray-100 active:bg-gray-200 transition-colors"
            >
              <X className="w-5 h-5 text-gray-700" />
            </button>
            <h2 className="text-[17px] font-bold text-[#111827]">New Post</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveDraft}
              disabled={!content.trim()}
              className="px-4 py-1.5 text-[14px] font-semibold text-gray-700 bg-gray-100 hover:bg-gray-200 active:bg-gray-300 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save Draft
            </button>
            <button
              onClick={handlePost}
              disabled={!content.trim()}
              className="px-4 py-1.5 text-[14px] font-semibold text-white bg-blue-500 hover:bg-blue-600 active:bg-blue-700 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Post
            </button>
          </div>
        </div>

        <div className="flex-1 p-4 overflow-y-auto">
          <textarea
            autoFocus
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="What's on your mind?"
            className="w-full h-full min-h-[300px] sm:min-h-[200px] text-[17px] text-[#111827] placeholder-gray-400 bg-transparent resize-none focus:outline-none"
          />
        </div>
      </motion.div>
    </div>
  );
};
