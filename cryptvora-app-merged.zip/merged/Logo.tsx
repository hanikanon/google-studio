import React from 'react';
import { cn } from './utils';

interface LogoProps {
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ className }) => {
  return (
    <svg 
      viewBox="0 0 160 60" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={cn("w-auto h-full overflow-visible", className)}
    >
      <defs>
        <style>
          {`
            @import url('https://fonts.googleapis.com/css2?family=Alex+Brush&display=swap');
            .adaptive-wordmark {
              mix-blend-mode: difference;
              fill: white;
              font-family: 'Alex Brush', cursive;
              font-size: 48px;
              text-anchor: middle;
              dominant-baseline: middle;
              letter-spacing: 0.5px;
            }
          `}
        </style>
      </defs>
      
      {/* 
        Using mix-blend-mode: difference with white fill creates automatic contrast detection.
        On light backgrounds it renders black, on dark backgrounds it renders white.
      */}
      <text x="80" y="32" className="adaptive-wordmark">
        Hoo-X
      </text>
    </svg>
  );
};
