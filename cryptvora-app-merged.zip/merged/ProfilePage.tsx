import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Settings, MapPin, Loader2, Link as LinkIcon, UserPlus, Send, Bell, MoreHorizontal, MoreVertical,
  Heart, MessageCircle, Repeat, Bookmark, Grid, Film, Image as ImageIcon, GraduationCap, TrendingUp, Star, Share2, BellOff, Edit, QrCode, Flag, ShieldAlert, VolumeX, RefreshCw, X, CircleOff, Check, CheckCircle
, FileEdit, Trash2, ArrowLeft } from 'lucide-react';
import { UserList } from './UserList';
import { ComposeModal } from './ComposeModal';
import { PostGrid } from './PostGrid';
import { PinkBadgeIcon, OwlLogo, ReadMoreText } from './SharedComponents';


function CandlestickChart() {
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-col mt-4 shadow-sm">
      <div className="relative h-[120px] w-full">
         <svg viewBox="0 0 100 40" className="w-full h-full overflow-visible" preserveAspectRatio="none">
           {/* 1. Green */}
           <line x1="5" y1="20" x2="5" y2="30" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="3.5" y="23" width="3" height="5" fill="#22c55e" rx="0.5" />
           {/* 2. Red */}
           <line x1="12" y1="22" x2="12" y2="28" stroke="#ef4444" strokeWidth="0.5" />
           <rect x="10.5" y="24" width="3" height="2" fill="#ef4444" rx="0.5" />
           {/* 3. Green */}
           <line x1="19" y1="21" x2="19" y2="26" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="17.5" y="22" width="3" height="3" fill="#22c55e" rx="0.5" />
           {/* 4. Red */}
           <line x1="26" y1="20" x2="26" y2="28" stroke="#ef4444" strokeWidth="0.5" />
           <rect x="24.5" y="22" width="3" height="4" fill="#ef4444" rx="0.5" />
           {/* 5. Red */}
           <line x1="33" y1="25" x2="33" y2="35" stroke="#ef4444" strokeWidth="0.5" />
           <rect x="31.5" y="27" width="3" height="6" fill="#ef4444" rx="0.5" />
           {/* 6. Green */}
           <line x1="40" y1="28" x2="40" y2="38" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="38.5" y="32" width="3" height="3" fill="#22c55e" rx="0.5" />
           {/* 7. Green */}
           <line x1="47" y1="25" x2="47" y2="33" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="45.5" y="26" width="3" height="5" fill="#22c55e" rx="0.5" />
           {/* 8. Red */}
           <line x1="54" y1="23" x2="54" y2="29" stroke="#ef4444" strokeWidth="0.5" />
           <rect x="52.5" y="25" width="3" height="2" fill="#ef4444" rx="0.5" />
           {/* 9. Green */}
           <line x1="61" y1="18" x2="61" y2="26" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="59.5" y="20" width="3" height="4" fill="#22c55e" rx="0.5" />
           {/* 10. Red */}
           <line x1="68" y1="18" x2="68" y2="24" stroke="#ef4444" strokeWidth="0.5" />
           <rect x="66.5" y="19" width="3" height="3" fill="#ef4444" rx="0.5" />
           {/* 11. Green */}
           <line x1="75" y1="14" x2="75" y2="22" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="73.5" y="16" width="3" height="4" fill="#22c55e" rx="0.5" />
           {/* 12. Green */}
           <line x1="82" y1="10" x2="82" y2="18" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="80.5" y="11" width="3" height="5" fill="#22c55e" rx="0.5" />
           {/* 13. Green */}
           <line x1="89" y1="6" x2="89" y2="14" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="87.5" y="8" width="3" height="4" fill="#22c55e" rx="0.5" />
           {/* 14. Green */}
           <line x1="96" y1="2" x2="96" y2="10" stroke="#22c55e" strokeWidth="0.5" />
           <rect x="94.5" y="4" width="3" height="5" fill="#22c55e" rx="0.5" />
           
           {/* Dotted Trend Line */}
           <path d="M 5 25.5 L 12 25 L 19 23.5 L 26 24 L 33 30 L 40 33.5 L 47 28.5 L 54 26 L 61 22 L 68 20.5 L 75 18 L 82 13.5 L 89 10 L 96 6.5" fill="none" stroke="#22c55e" strokeWidth="0.3" strokeDasharray="1,1" opacity="0.6" />
         </svg>
      </div>

      <div className="h-[1px] w-full bg-gray-200 my-3"></div>

      <div className="flex justify-between items-center text-[12px] px-1">
        <div className="text-gray-500 font-medium tracking-wide">BTC / USDT · 4H</div>
        <div className="text-green-600 font-medium flex items-center gap-1 bg-green-500/10 px-1.5 py-0.5 rounded">
          <TrendingUp className="w-3 h-3" />
          +2.34%
        </div>
        <div className="text-[#111827] font-bold tracking-wide">64,812.40</div>
      </div>
    </div>
  )
}

function usePersistentState<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  const [state, setState] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      return initialValue;
    }
  });

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(state) : value;
      setState(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.log(error);
    }

  };
  return [state, setValue];
}


export interface Draft {
  id: string;
  content: string;
  timestamp: string;
}

export const ProfilePage = ({ onBack }: { onBack?: () => void }) => {
  const [drafts, setDrafts] = usePersistentState<Draft[]>('user_drafts', []);
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [editingDraftId, setEditingDraftId] = useState<string | null>(null);
  
  const handleSaveDraft = (content: string) => {
    if (editingDraftId) {
      setDrafts(prev => prev.map(d => d.id === editingDraftId ? { ...d, content, timestamp: new Date().toISOString() } : d));
    } else {
      const newDraft: Draft = {
        id: 'draft-' + Date.now(),
        content,
        timestamp: new Date().toISOString(),
      };
      setDrafts(prev => [newDraft, ...prev]);
    }
    setEditingDraftId(null);
    setIsComposeOpen(false);
    window.dispatchEvent(new CustomEvent('showToast', { detail: { message: 'Draft saved successfully.' } }));
  };

  const handlePost = (content: string) => {
    // Fake post
    if (editingDraftId) {
      setDrafts(prev => prev.filter(d => d.id !== editingDraftId));
    }
    setEditingDraftId(null);
    setIsComposeOpen(false);
    window.dispatchEvent(new CustomEvent('showToast', { detail: { message: 'Post published successfully!' } }));
    setActiveTab('POSTS');
  };

  
  const publishDraft = (draft: Draft, e: React.MouseEvent) => {
    e.stopPropagation();
    setDrafts(prev => prev.filter(d => d.id !== draft.id));
    window.dispatchEvent(new CustomEvent('showToast', { detail: { message: 'Post published successfully!' } }));
    setActiveTab('POSTS');
  };

  const deleteDraft = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDrafts(prev => prev.filter(d => d.id !== id));
    window.dispatchEvent(new CustomEvent('showToast', { detail: { message: 'Draft deleted.' } }));
  };

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isActionMenuOpen, setIsActionMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('POSTS');


  // Pull to refresh states
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const touchStartY = useRef(0);
  const hasVibrated = useRef(false);
  const [isPulling, setIsPulling] = useState(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (window.scrollY === 0) {
      touchStartY.current = e.touches[0].clientY;
      setIsPulling(true);
      hasVibrated.current = false;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isPulling || isRefreshing) return;
    const currentY = e.touches[0].clientY;
    const distance = currentY - touchStartY.current;
    if (distance > 0 && window.scrollY === 0) {
      const newDistance = Math.min(distance * 0.4, 80);
      setPullDistance(newDistance);
      
      if (newDistance > 60 && !hasVibrated.current) {
        if (navigator.vibrate) navigator.vibrate(10);
        hasVibrated.current = true;
      } else if (newDistance <= 60 && hasVibrated.current) {
        hasVibrated.current = false;
      }
    }
  };

  const handleTouchEnd = () => {
    if (!isPulling) return;
    setIsPulling(false);
    if (pullDistance > 60) {
      setIsRefreshing(true);
      setPullDistance(60); // Hold at max distance
      setTimeout(() => {
        setIsRefreshing(false);
        setPullDistance(0);
      }, 1500);
    } else {
      setPullDistance(0);
    }
  };

  
  // View states
  const [activeView, setActiveView] = useState<'profile' | 'followers' | 'following'>('profile');

  // Interactive states persisted in localStorage
  const [isBlocked, setIsBlocked] = usePersistentState('user_isBlocked', false);
  const [isMuted, setIsMuted] = usePersistentState('user_isMuted', false);
  const [isRestricted, setIsRestricted] = usePersistentState('user_isRestricted', false);
  const [isFavorite, setIsFavorite] = usePersistentState('user_isFavorite', false);
  const [isFollowing, setIsFollowing] = usePersistentState('user_isFollowing', false);

  const [toastMessage, setToastMessage] = useState<{ message: string, onUndo?: () => void } | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{ type: 'block' } | null>(null);
  const [reportDialogVisible, setReportDialogVisible] = useState(false);
  const [reportReason, setReportReason] = useState<string | null>(null);

  useEffect(() => {
    const handleShowToast = (e: any) => {
      setToastMessage({ message: e.detail.message });
    };
    const handleOpenReport = () => {
      setReportDialogVisible(true);
    };
    window.addEventListener('showToast', handleShowToast);
    window.addEventListener('openReportDialog', handleOpenReport);
    return () => {
      window.removeEventListener('showToast', handleShowToast);
      window.removeEventListener('openReportDialog', handleOpenReport);
    };
  }, []);


  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const [followersCount, setFollowersCount] = usePersistentState('nightowl_followers_count', 12400);
  const [followingCount, setFollowingCount] = usePersistentState('nightowl_following_count', 312);

  // notificationsOn is the opposite of isMuted
  const notificationsOn = !isMuted;
  const setNotificationsOn = (val: boolean) => setIsMuted(!val);

  const handleBlockAction = () => {
    setIsMenuOpen(false);
    setIsActionMenuOpen(false);
    if (isBlocked) {
      setIsBlocked(false);
      setToastMessage({ message: 'User unblocked.' });
    } else {
      setConfirmDialog({ type: 'block' });
    }

  };
  const confirmBlock = () => {
    const wasFollowing = isFollowing;
    setIsBlocked(true);
    if (wasFollowing) {
      setIsFollowing(false);
      setFollowersCount(prev => prev - 1);
    }
    setConfirmDialog(null);
    setToastMessage({
      message: 'User blocked successfully.',
      onUndo: () => {
        setIsBlocked(false);
        if (wasFollowing) {
          setIsFollowing(true);
          setFollowersCount(prev => prev + 1);
        }
        setToastMessage(null);
      }
    });

  };

  const handleShareProfile = async () => {
    setIsMenuOpen(false);
    setIsActionMenuOpen(false);
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'Nightowl',
          text: 'Check out Nightowl on Cryptvora',
          url: 'https://cryptvora.com/@nightowl',
        });
      } else {
        await navigator.clipboard.writeText('https://cryptvora.com/@nightowl');
      }
    } catch (err) {
      /* ignore */
    }

  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText('https://cryptvora.com/@nightowl');
    setIsMenuOpen(false);
    setIsActionMenuOpen(false);
  };
  const TABS = [
    { id: 'POSTS', label: 'POSTS', icon: Grid },
    { id: 'VIDEOS', label: 'VIDEOS', icon: Film },
    { id: 'MEDIA', label: 'MEDIA', icon: ImageIcon },
    { id: 'COURSES', label: 'COURSES', icon: GraduationCap },
    { id: 'DRAFTS', label: 'DRAFTS', icon: FileEdit },
  ];

  return (
    <div className="bg-[#f8fafc] min-h-screen text-[#111827] font-sans relative selection:bg-blue-500/30 overflow-x-hidden">
      
      <AnimatePresence initial={false} mode="popLayout">

        {activeView === 'profile' && (
          <motion.div
            key="profile"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="w-full bg-white min-h-screen relative"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {/* Pull to Refresh Indicator */}
            <div 
              className="absolute top-0 left-0 right-0 flex justify-center items-center z-0 pointer-events-none"
              style={{ 
                height: `${Math.max(pullDistance, isRefreshing ? 60 : 0)}px`, 
                opacity: isRefreshing ? 1 : pullDistance / 60,
                transition: isPulling ? 'none' : 'height 0.3s ease-out, opacity 0.3s ease-out'
              }}
            >
              <motion.div 
                initial={{ y: -20, scale: 0.8 }}
                animate={{ 
                  y: isRefreshing || pullDistance > 10 ? 0 : -20, 
                  scale: isRefreshing || pullDistance > 10 ? 1 : 0.8,
                  rotate: isRefreshing ? 360 : (pullDistance * 2) 
                }}
                transition={isRefreshing ? { rotate: { repeat: Infinity, ease: "linear", duration: 1 }, default: { type: "spring", stiffness: 400, damping: 25 } } : { type: "spring", stiffness: 400, damping: 25, rotate: { duration: 0 } }}
                className="bg-white rounded-full p-2.5 shadow-lg flex items-center justify-center text-blue-500"
              >
                <Loader2 className="w-5 h-5" />
              </motion.div>
            </div>
            <div style={{ transform: `translateY(${pullDistance}px)`, transition: isPulling ? 'none' : 'transform 0.3s ease-out' }} className="relative z-10 bg-white min-h-screen">
            {/* Top Navigation - not sticky as requested earlier, just static */}

            <header className="flex justify-between items-center p-4">
              <div className="flex items-center gap-2">
                {onBack && (
                  <motion.button 
                    whileTap={{ scale: 0.92 }}
                    onClick={onBack}
                    className="p-1.5 -ml-1.5 rounded-full hover:bg-gray-100 transition-colors"
                  >
                    <ArrowLeft className="w-6 h-6 text-[#111827]" />
                  </motion.button>
                )}
                <h1 className="text-[18px] font-bold text-[#111827] tracking-tight">@nightowl</h1>
              </div>
              
              <div className="flex items-center gap-1">
                <AnimatePresence>
                  {isFavorite && (
                    <motion.div
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0, opacity: 0 }}
                      className="mr-1 flex items-center justify-center"
                    >
                      <Star className="w-[20px] h-[20px] text-yellow-400 fill-yellow-400 drop-shadow-sm" />
                    </motion.div>
                  )}
                </AnimatePresence>
                <motion.button 
                  whileTap={{ scale: 0.92 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  onClick={handleShareProfile}
                  className="hover:bg-gray-100 p-1.5 rounded-full transition-colors"
                >
                  <Share2 className="w-[22px] h-[22px] text-[#111827]" />
                </motion.button>

                {/* Three Dot Menu & Dropdown */}
                <div className="relative">
                  <motion.button 
                    whileTap={{ scale: 0.92 }}
                    transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                    className="hover:bg-gray-100 p-1.5 rounded-full transition-colors"
                  >
                    <MoreVertical className="w-[22px] h-[22px] text-[#111827]" />
                  </motion.button>
            
            <AnimatePresence>
              {isMenuOpen && (
                <>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 z-40 bg-black/5 md:bg-transparent" 
                    onClick={() => setIsMenuOpen(false)}
                  />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    transition={{ duration: 0.15, ease: "easeOut" }}
                    className="absolute right-0 top-full mt-1 w-[220px] bg-white border border-gray-100 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] py-2 z-50 overflow-hidden origin-top-right"
                  >
                    <button className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center gap-3">
                      <Edit className="w-5 h-5 text-gray-500" /> Edit Profile
                    </button>
                    <button onClick={handleShareProfile} className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center gap-3">
                      <Share2 className="w-5 h-5 text-gray-500" /> Share Profile
                    </button>
                    <button onClick={handleCopyLink} className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center gap-3">
                      <LinkIcon className="w-5 h-5 text-gray-500" /> Copy Profile Link
                    </button>
                    <button className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center gap-3">
                      <QrCode className="w-5 h-5 text-gray-500" /> QR Code
                    </button>
                    <button onClick={() => { setNotificationsOn(!notificationsOn); setIsMenuOpen(false); }} className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Bell className="w-5 h-5 text-gray-500" /> Notifications
                      </div>
                      {notificationsOn && <Check className="w-5 h-5 text-blue-500" />}
                    </button>
                    <button onClick={() => { setIsFavorite(!isFavorite); setIsMenuOpen(false); }} className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Star className={`w-5 h-5 ${isFavorite ? 'text-yellow-400 fill-yellow-400' : 'text-gray-500'}`} /> {isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                      </div>
                      {isFavorite && <Check className="w-5 h-5 text-blue-500" />}
                    </button>
                    <button className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center gap-3">
                      <RefreshCw className="w-5 h-5 text-gray-500" /> Refresh Profile
                    </button>
                    <button className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center gap-3">
                      <Settings className="w-5 h-5 text-gray-500" /> Settings
                    </button>
                    <div className="h-[1px] bg-gray-100 my-1.5 mx-3"></div>
                    <button onClick={() => { setIsRestricted(!isRestricted); setIsMenuOpen(false); }} className="w-full text-left px-4 py-3 text-[15px] font-medium text-[#111827] hover:bg-gray-50 active:bg-gray-100 transition-colors flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <CircleOff className="w-5 h-5 text-gray-500" /> {isRestricted ? 'Unrestrict User' : 'Restrict User'}
                      </div>
                    </button>

                    <button onClick={handleBlockAction} className="w-full text-left px-4 py-3 text-[15px] font-medium text-red-500 hover:bg-red-50 active:bg-red-100 transition-colors flex items-center gap-3">
                      <ShieldAlert className="w-5 h-5 text-red-500" /> {isBlocked ? 'Unblock User' : 'Block User'}
                    </button>
                    {!isBlocked && (
                      <button onClick={() => { setIsMenuOpen(false); setReportReason(null); setReportDialogVisible(true); }} className="w-full text-left px-4 py-3 text-[15px] font-medium text-red-500 hover:bg-red-50 active:bg-red-100 transition-colors flex items-center gap-3">
                        <Flag className="w-5 h-5 text-red-500" /> Report User
                      </button>
                    )}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      {/* Profile Section */}
      <div className="px-4 pt-2 pb-2">
        {/* Avatar & Stats Row */}
        <div className="flex justify-between items-center">
          <motion.div 
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            className="relative rounded-full p-[2.5px] bg-gradient-to-tr from-blue-400 via-blue-500 to-blue-600 shrink-0 shadow-[0_0_12px_rgba(59,130,246,0.4)] cursor-pointer z-10"
          >
            <div className="bg-white p-1 rounded-full">
              <div className="w-[84px] h-[84px] rounded-full bg-gradient-to-b from-[#a855f7] to-[#6b21a8] flex flex-col items-center justify-center shadow-inner relative overflow-hidden">
                 <OwlLogo className="w-8 h-8 text-white mt-1.5" />
                 <span className="text-[9px] font-bold text-white tracking-widest mt-1 z-10">Cryptvora</span>
              </div>
            </div>
            <div className="absolute bottom-1.5 right-1.5 w-[20px] h-[20px] bg-[#22c55e] border-[3.5px] border-white rounded-full shadow-sm"></div>
          </motion.div>
          
          <div className="flex bg-white border border-gray-200 rounded-full shadow-[0_2px_12px_rgba(0,0,0,0.06)] h-[54px] items-center px-1 ml-4 w-full">
            <motion.button 
              whileTap={{ scale: 0.95, backgroundColor: "rgba(0,0,0,0.05)" }}
              onClick={() => setActiveTab('POSTS')}
              className="flex flex-col items-center justify-center h-full flex-1 px-2 rounded-full transition-colors"
            >
              <span className="font-bold text-[16px] tracking-tight text-[#111827] leading-none mb-0.5">984</span>
              <span className="text-gray-500 text-[10px] font-medium tracking-wide">Posts</span>
            </motion.button>
            <div className="w-[1px] h-8 bg-gray-200" />
            <motion.button 
              whileTap={{ scale: 0.95, backgroundColor: "rgba(0,0,0,0.05)" }}
              onClick={() => setActiveView('followers')}
              className="flex flex-col items-center justify-center h-full flex-1 px-2 rounded-full transition-colors"
            >
              <span className="font-bold text-[16px] tracking-tight text-[#111827] leading-none mb-0.5">
                {followersCount > 1000 ? (followersCount / 1000).toFixed(1) + 'k' : followersCount}
              </span>
              <span className="text-gray-500 text-[10px] font-medium tracking-wide">Followers</span>
            </motion.button>
            <div className="w-[1px] h-8 bg-gray-200" />
            <motion.button 
              whileTap={{ scale: 0.95, backgroundColor: "rgba(0,0,0,0.05)" }}
              onClick={() => setActiveView('following')}
              className="flex flex-col items-center justify-center h-full flex-1 px-2 rounded-full transition-colors"
            >
              <span className="font-bold text-[16px] tracking-tight text-[#111827] leading-none mb-0.5">{followingCount}</span>
              <span className="text-gray-500 text-[10px] font-medium tracking-wide">Following</span>
            </motion.button>
          </div>
        </div>

        {/* Bio Info */}
        <div className="mt-4">
          <div className="flex items-center gap-2">
            <h2 className="text-[22px] font-bold tracking-tight text-[#111827]">Nightowl</h2>
            <div className="bg-[#3b82f6] rounded-full p-[3px]">
              <Star className="w-[11px] h-[11px] text-white fill-white" />
            </div>
            <div className="bg-[#3b82f6] rounded-full p-[3.5px]">
              <PinkBadgeIcon className="w-[10px] h-[10px] text-white" />
            </div>
          </div>
          
          <div className="text-gray-500 text-[14px] font-medium mt-1">
            Trader · Order flow & structure
          </div>
          
          <div className="text-[#111827] text-[15px] mt-3.5 leading-relaxed pr-2">
            Night-shift crypto trader. Order flow, structure, calm risk. Building Cryptvora — a private members' lounge for traders who prefer craft over noise.
          </div>

          <div className="flex items-center gap-4 mt-3.5 text-[14px] text-gray-500 font-medium">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-[15px] h-[15px]" /> Lisbon
            </div>
            <div className="flex items-center gap-1.5 text-[#3b82f6]">
              <LinkIcon className="w-[15px] h-[15px]" /> cryptvora.com
            </div>
            <div className="flex items-center gap-1.5 text-gray-500">
              <div className="w-[6px] h-[6px] bg-[#22c55e] rounded-full"></div> Online
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 mt-5 min-h-[44px]">
          <AnimatePresence mode="wait">
          {isBlocked ? (
            <motion.button 
              key="unblock"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsBlocked(false)}
              className="flex-1 h-[44px] bg-red-50 text-red-600 font-semibold text-[15px] rounded-full flex justify-center items-center gap-2 transition-colors hover:bg-red-100 active:bg-red-200 shadow-sm"
            >
              <ShieldAlert className="w-[18px] h-[18px]" /> Unblock User
            </motion.button>
          ) : (
            <motion.div
              key="actions"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="flex items-center gap-2 flex-1 h-[44px]"
            >
              <motion.button 
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsFollowing(!isFollowing)}
                className={`flex-1 h-[44px] font-semibold text-[15px] rounded-full flex justify-center items-center gap-2 transition-colors shadow-sm ${isFollowing ? 'bg-gray-100 text-[#111827] hover:bg-gray-200 active:bg-gray-300' : 'bg-[#3b82f6] hover:bg-[#2563eb] text-white'}`}
              >
                {isFollowing ? (
                  <>Following</>
                ) : (
                  <><UserPlus className="w-[18px] h-[18px]" /> Follow</>
                )}
              </motion.button>
              <motion.button 
                whileTap={{ scale: 0.95 }}
                className="flex-1 h-[44px] bg-[#f3f4f6] text-gray-700 font-semibold text-[15px] rounded-full flex justify-center items-center gap-2 transition-colors hover:bg-gray-200 active:bg-gray-300"
              >
                <Send className="w-[18px] h-[18px]" /> Message
              </motion.button>
              <motion.button 
                whileTap={{ scale: 0.95 }}
                onClick={() => setNotificationsOn(!notificationsOn)}
                className={`w-11 h-[44px] rounded-full flex justify-center items-center shrink-0 transition-colors shadow-sm ${notificationsOn ? 'bg-[#3b82f6] text-white' : 'bg-[#f3f4f6] text-gray-700 hover:bg-gray-200 active:bg-gray-300'}`}
              >
                <motion.div
                  animate={notificationsOn ? { rotate: [0, 15, -10, 10, -5, 0] } : { scale: 1 }}
                  transition={{ repeat: notificationsOn ? Infinity : 0, repeatDelay: 4, duration: 1, ease: "easeInOut" }}
                  className="relative"
                >
                  <AnimatePresence mode="popLayout" initial={false}>
                    <motion.div
                      key={notificationsOn ? 'on' : 'off'}
                      initial={{ scale: 0.5, opacity: 0, rotate: -45 }}
                      animate={{ scale: 1, opacity: 1, rotate: 0 }}
                      exit={{ scale: 0.5, opacity: 0, rotate: 45 }}
                      transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    >
                      {notificationsOn ? <Bell className="w-5 h-5" /> : <BellOff className="w-5 h-5" />}
                    </motion.div>
                  </AnimatePresence>
                  {notificationsOn && (
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute 1 top-0 right-0 w-[6px] h-[6px] bg-red-500 rounded-full border border-[#3b82f6]" 
                    />
                  )}
                </motion.div>
              </motion.button>
            </motion.div>
          )}
          </AnimatePresence>
          <motion.button 
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsActionMenuOpen(true)}
            className="w-11 h-11 bg-[#f3f4f6] text-gray-700 hover:bg-gray-200 active:bg-gray-300 rounded-full flex justify-center items-center shrink-0 transition-colors shadow-sm"
          >
            <MoreHorizontal className="w-[20px] h-[20px]" />
          </motion.button>
        </div>
      </div>

      {/* Bottom Sheet Action Menu */}
      <AnimatePresence>
        {isActionMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsActionMenuOpen(false)}
              className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 400, damping: 35 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-white rounded-t-3xl overflow-hidden pb-safe shadow-2xl"
            >
              <div className="w-full flex justify-center py-3">
                <div className="w-10 h-1 bg-gray-300 rounded-full" />
              </div>
              <div className="px-4 pb-6 flex flex-col gap-1 max-h-[70vh] overflow-y-auto">
                <button onClick={handleShareProfile} className="w-full text-left px-4 py-3.5 text-[16px] font-semibold text-[#111827] hover:bg-gray-50 active:bg-gray-100 rounded-xl transition-colors flex items-center gap-3">
                  <Share2 className="w-[20px] h-[20px] text-gray-500" /> Share Profile
                </button>
                <button onClick={handleCopyLink} className="w-full text-left px-4 py-3.5 text-[16px] font-semibold text-[#111827] hover:bg-gray-50 active:bg-gray-100 rounded-xl transition-colors flex items-center gap-3">
                  <LinkIcon className="w-[20px] h-[20px] text-gray-500" /> Copy Link
                </button>
                <button className="w-full text-left px-4 py-3.5 text-[16px] font-semibold text-[#111827] hover:bg-gray-50 active:bg-gray-100 rounded-xl transition-colors flex items-center gap-3">
                  <QrCode className="w-[20px] h-[20px] text-gray-500" /> View QR Code
                </button>
                <button className="w-full text-left px-4 py-3.5 text-[16px] font-semibold text-[#111827] hover:bg-gray-50 active:bg-gray-100 rounded-xl transition-colors flex items-center gap-3">
                  <RefreshCw className="w-[20px] h-[20px] text-gray-500" /> Refresh
                </button>
                
                <div className="h-[1px] bg-gray-100 my-2 mx-2"></div>
                
                <button onClick={() => { setIsRestricted(!isRestricted); setIsActionMenuOpen(false); }} className="w-full text-left px-4 py-3.5 text-[16px] font-semibold text-[#111827] hover:bg-gray-50 active:bg-gray-100 rounded-xl transition-colors flex items-center gap-3">
                  <CircleOff className="w-[20px] h-[20px] text-gray-500" /> {isRestricted ? 'Unrestrict' : 'Restrict'}
                </button>
                
                <button onClick={handleBlockAction} className="w-full text-left px-4 py-3.5 text-[16px] font-semibold text-red-500 hover:bg-red-50 active:bg-red-100 rounded-xl transition-colors flex items-center gap-3">
                  <ShieldAlert className="w-[20px] h-[20px] text-red-500" /> {isBlocked ? 'Unblock' : 'Block'}
                </button>
                {!isBlocked && (
                  <button onClick={() => { setIsActionMenuOpen(false); setReportReason(null); setReportDialogVisible(true); }} className="w-full text-left px-4 py-3.5 text-[16px] font-semibold text-red-500 hover:bg-red-50 active:bg-red-100 rounded-xl transition-colors flex items-center gap-3">
                    <Flag className="w-[20px] h-[20px] text-red-500" /> Report
                  </button>
                )}

                <div className="h-[1px] bg-gray-100 my-2 mx-2"></div>
                
                <button onClick={() => setIsActionMenuOpen(false)} className="w-full text-center py-3.5 text-[16px] font-bold text-[#111827] bg-gray-100 hover:bg-gray-200 active:bg-gray-300 rounded-xl transition-colors">
                  Cancel
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {isBlocked ? (
        <div className="flex flex-col items-center justify-center py-20 px-4 text-center mt-8">
          <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mb-4">
            <ShieldAlert className="w-8 h-8 text-red-500" />
          </div>
          <h2 className="text-[20px] font-bold text-[#111827]">You blocked this user</h2>
          <p className="text-gray-500 text-[15px] mt-2 mb-6 max-w-[280px]">
            You won't receive messages, calls, or see their content.
          </p>
          <button 
            onClick={handleBlockAction}
            className="bg-[#111827] text-white font-semibold rounded-full px-8 py-3 transition-colors hover:bg-gray-800"
          >
            Unblock User
          </button>
        </div>
      ) : (
        <>
          {/* Tabs */}
          <div className="border-b border-gray-200 mt-4 pt-3 sticky top-0 bg-white/90 backdrop-blur-md z-30">
            <div className="flex gap-7 overflow-x-auto px-4 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] relative">
              {TABS.map(tab => (
                <button 
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 pb-3.5 font-semibold text-[13px] tracking-widest whitespace-nowrap transition-colors relative ${activeTab === tab.id ? 'text-[#3b82f6]' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  <tab.icon className="w-4 h-4" /> {tab.label}
                  {activeTab === tab.id && (
                    <motion.div 
                      layoutId="activeTabIndicator"
                      className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#3b82f6]"
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Posts Feed */}
          <div className="flex flex-col pt-6 pb-8 min-h-[400px]">
            <AnimatePresence mode="wait">
          {activeTab === 'POSTS' && (
            <motion.div key="posts" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }} className="flex flex-col">
              <PostGrid />
            </motion.div>
          )}

          {activeTab === 'VIDEOS' && (
            <motion.div 
              key="videos"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col items-center justify-center py-16 text-center px-4"
            >
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <Film className="w-8 h-8 text-gray-400" />
              </div>
              <p className="font-bold text-[#111827] text-[18px]">No videos yet</p>
              <p className="text-gray-500 text-[14px] mt-1.5 max-w-[250px]">When Nightowl posts videos, they'll show up here.</p>
            </motion.div>
          )}

          {activeTab === 'MEDIA' && (
            <motion.div 
              key="media"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col items-center justify-center py-16 text-center px-4"
            >
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <ImageIcon className="w-8 h-8 text-gray-400" />
              </div>
              <p className="font-bold text-[#111827] text-[18px]">No media available</p>
              <p className="text-gray-500 text-[14px] mt-1.5 max-w-[250px]">Photos and images shared by Nightowl will appear in this section.</p>
            </motion.div>
          )}

          
          {activeTab === 'DRAFTS' && (
            <motion.div 
              key="drafts"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col px-4 max-w-4xl mx-auto w-full"
            >
              {drafts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <FileEdit className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="font-bold text-[#111827] text-[18px]">No drafts</p>
                  <p className="text-gray-500 text-[14px] mt-1.5 max-w-[250px]">Start writing a post and save it as a draft to finish later.</p>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {drafts.map(draft => (
                    <motion.div 
                      key={draft.id}
                      onClick={() => {
                        setEditingDraftId(draft.id);
                        setIsComposeOpen(true);
                      }}
                      className="p-4 bg-white border border-gray-200 rounded-2xl cursor-pointer hover:bg-gray-50 transition-colors shadow-sm group relative"
                    >
                      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={(e) => deleteDraft(draft.id, e)}
                          className="p-2 -m-2 text-gray-400 hover:text-red-500 transition-colors rounded-full hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-[#111827] text-[15px] line-clamp-3 whitespace-pre-wrap pr-8">
                        {draft.content}
                      </p>
                      <div className="flex items-center justify-between mt-4">
                        <p className="text-gray-500 text-[12px] font-medium">
                          Last edited {new Date(draft.timestamp).toLocaleDateString()}
                        </p>
                        <button
                          onClick={(e) => publishDraft(draft, e)}
                          className="px-4 py-1.5 bg-blue-500 hover:bg-blue-600 active:bg-blue-700 text-white text-[13px] font-semibold rounded-full transition-colors flex items-center gap-1.5"
                        >
                          <Send className="w-3.5 h-3.5" />
                          Publish
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'COURSES' && (
            <motion.div 
              key="courses"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col items-center justify-center py-16 text-center px-4"
            >
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <GraduationCap className="w-8 h-8 text-gray-400" />
              </div>
              <p className="font-bold text-[#111827] text-[18px]">Exclusive Courses</p>
              <p className="text-gray-500 text-[14px] mt-1.5 max-w-[250px]">Premium members can access trading courses here.</p>
              <motion.button 
                whileTap={{ scale: 0.95 }}
                className="mt-6 bg-[#111827] text-white px-6 py-2.5 rounded-full font-semibold text-[14px]"
              >
                Learn More
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      </>
      )}
          </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {activeView === 'followers' && (
          <UserList 
            type="followers" 
            onBack={() => setActiveView('profile')} 
            onUserClick={(user) => {
              setIsBlocked(user.isBlocked || false);
              setIsMuted(user.isMuted || false);
              setIsFollowing(user.isFollowing || false);
              setActiveView('profile');
            }}
            onUpdateFollowers={(delta) => setFollowersCount(followersCount + delta)}
            onUpdateFollowing={(delta) => setFollowingCount(followingCount + delta)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {activeView === 'following' && (
          <UserList 
            type="following" 
            onBack={() => setActiveView('profile')} 
            onUserClick={(user) => {
              setIsBlocked(user.isBlocked || false);
              setIsMuted(user.isMuted || false);
              setIsFollowing(user.isFollowing || false);
              setActiveView('profile');
            }}
            onUpdateFollowers={(delta) => setFollowersCount(followersCount + delta)}
            onUpdateFollowing={(delta) => setFollowingCount(followingCount + delta)}
          />
        )}
      </AnimatePresence>

      {/* Report Dialog */}
      <AnimatePresence>
        {reportDialogVisible && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setReportDialogVisible(false)}
              className="fixed inset-0 bg-black/50 z-[60]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed left-4 right-4 top-1/2 -translate-y-1/2 bg-white rounded-2xl z-[70] overflow-hidden shadow-xl"
            >
              <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                <h3 className="font-bold text-[17px] text-[#111827]">Report @nightowl</h3>
                <button onClick={() => setReportDialogVisible(false)} className="p-1 text-gray-400 hover:bg-gray-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4 flex flex-col">
                <p className="text-[14px] text-gray-500 mb-4">Please select a reason for reporting. Your report will be reviewed by our moderation team.</p>
                <div className="flex flex-col gap-2 mb-6 max-h-[300px] overflow-y-auto">
                  {[
                    "Spam",
                    "Harassment or bullying",
                    "Inappropriate content",
                    "Hate speech or symbols",
                    "False information",
                    "Scam or fraud"
                  ].map((reason) => (
                    <button
                      key={reason}
                      onClick={() => setReportReason(reason)}
                      className={`w-full text-left px-4 py-3 text-[15px] font-medium rounded-xl transition-colors border ${reportReason === reason ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 text-[#111827] hover:bg-gray-50'}`}
                    >
                      <div className="flex items-center justify-between">
                        {reason}
                        {reportReason === reason && <CheckCircle className="w-5 h-5 text-blue-500" />}
                      </div>
                    </button>
                  ))}
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setReportDialogVisible(false)}
                    className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-[#111827] font-semibold rounded-full transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => {
                      if (!reportReason) return;
                      setReportDialogVisible(false);
                      setToastMessage({ message: 'Report submitted.' });
                    }}
                    disabled={!reportReason}
                    className="flex-1 py-3 bg-red-500 hover:bg-red-600 disabled:bg-red-300 disabled:cursor-not-allowed text-white font-semibold rounded-full transition-colors"
                  >
                    Report
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Confirmation Dialogs */}
      <AnimatePresence>
        {confirmDialog && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setConfirmDialog(null)}
              className="fixed inset-0 bg-black/50 z-[60]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed left-6 right-6 top-1/2 -translate-y-1/2 bg-white rounded-2xl z-[70] overflow-hidden shadow-xl"
            >
              <div className="p-6 flex flex-col items-center text-center">
                <h3 className="font-bold text-[20px] text-[#111827] mb-2">Block @nightowl?</h3>
                <p className="text-[15px] text-gray-500 mb-6">
                  They won't be able to find your profile, follow you, or message you.
                </p>
                <div className="flex flex-col gap-3 w-full">
                  <button 
                    onClick={confirmBlock}
                    className="w-full py-3.5 text-[16px] font-bold text-white rounded-xl transition-colors bg-red-500 hover:bg-red-600"
                  >
                    Block
                  </button>
                  <button 
                    onClick={() => setConfirmDialog(null)}
                    className="w-full py-3.5 text-[16px] font-bold text-[#111827] bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Action Toast with Undo */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-[#111827] text-white px-5 py-3 rounded-full shadow-lg z-[80] flex items-center justify-between gap-4 font-medium text-[14px] min-w-[200px]"
          >
            <span>{toastMessage.message}</span>
            {toastMessage.onUndo && (
              <button 
                onClick={toastMessage.onUndo}
                className="text-[#3b82f6] hover:text-blue-400 font-bold ml-2 transition-colors active:scale-95"
              >
                Undo
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>


      <AnimatePresence>
        {isComposeOpen && (
          <ComposeModal
            isOpen={isComposeOpen}
            onClose={() => {
              setIsComposeOpen(false);
              setEditingDraftId(null);
            }}
            initialContent={editingDraftId ? drafts.find(d => d.id === editingDraftId)?.content : ''}
            onSaveDraft={handleSaveDraft}
            onPost={handlePost}
          />
        )}
      </AnimatePresence>

      <button
        onClick={() => {
          setEditingDraftId(null);
          setIsComposeOpen(true);
        }}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-500/30 hover:bg-blue-600 hover:scale-105 active:scale-95 transition-all z-40"
      >
        <Edit className="w-6 h-6 ml-0.5" />
      </button>

    </div>
  );
};
