import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, Check, CheckCheck} from 'lucide-react';
import { MessageIndicators } from './MessageIndicators';
import { cn } from './utils';

// We need a global state or event bus to stop other audio. 
// A simple custom event will do.
const AUDIO_PLAY_EVENT = 'AUDIO_MESSAGE_PLAY';

interface AudioMessageProps {
  msg: {
    id: string;
    audioDuration?: string;
    audioUrl?: string;
    waveform?: number[];
    time: string;
    isRead: boolean;
    readStatus?: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
    isPinned?: boolean;
    isSaved?: boolean;
  };
  isMe: boolean;
}

export const AudioMessage: React.FC<AudioMessageProps> = ({ msg, isMe }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0); // 0 to 1
  const [currentTime, setCurrentTime] = useState('0:00');
  const [playbackRate, setPlaybackRate] = useState(1);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const waveformRef = useRef<HTMLDivElement>(null);
  
  // Use provided waveform or generate a fake one
  const defaultWaveform = [2, 4, 3, 5, 8, 4, 2, 5, 7, 4, 3, 2, 4, 6, 8, 5, 3, 2, 4, 3, 5, 7, 6, 4, 3, 2];
  const waveform = msg.waveform || defaultWaveform;
  
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  useEffect(() => {
    const audio = new Audio(msg.audioUrl || '');
    audioRef.current = audio;
    
    const setAudioData = () => {
      // If we don't have audioDuration, maybe we can calculate it
    };

    const setAudioTime = () => {
      if (!audio.duration) return;
      const curr = audio.currentTime;
      const dur = audio.duration;
      setProgress(curr / dur);
      
      const mins = Math.floor(curr / 60);
      const secs = Math.floor(curr % 60);
      setCurrentTime(`${mins}:${secs.toString().padStart(2, '0')}`);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setProgress(0);
      setCurrentTime('0:00');
    };

    audio.addEventListener('loadeddata', setAudioData);
    audio.addEventListener('timeupdate', setAudioTime);
    audio.addEventListener('ended', handleEnded);
    audio.playbackRate = playbackRate;

    const handleGlobalPlay = (e: any) => {
      if (e.detail.id !== msg.id && !audio.paused) {
        audio.pause();
        setIsPlaying(false);
      }
    };
    
    window.addEventListener(AUDIO_PLAY_EVENT, handleGlobalPlay);

    return () => {
      audio.removeEventListener('loadeddata', setAudioData);
      audio.removeEventListener('timeupdate', setAudioTime);
      audio.removeEventListener('ended', handleEnded);
      window.removeEventListener(AUDIO_PLAY_EVENT, handleGlobalPlay);
      audio.pause();
      audio.src = '';
    };
  }, [msg.id, msg.audioUrl]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio || !msg.audioUrl) return; // If no URL, we can't play anything
    
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      window.dispatchEvent(new CustomEvent(AUDIO_PLAY_EVENT, { detail: { id: msg.id } }));
      audio.play().catch(e => {
        console.error('Audio playback failed:', e);
        setIsPlaying(false);
        alert('Unable to play audio message. Format might not be supported on this device.');
      });
      setIsPlaying(true);
    }
  };


  const toggleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPlaybackRate(prev => {
      if (prev === 1) return 1.5;
      if (prev === 1.5) return 2;
      return 1;
    });
  };

  const handleSeek = (e: React.PointerEvent) => {
    if (!audioRef.current || !waveformRef.current) return;
    const rect = waveformRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const pct = x / rect.width;
    
    audioRef.current.currentTime = pct * (audioRef.current.duration || 0);
    setProgress(pct);
  };

  return (
    <div className="px-2 py-2 min-w-[220px] max-w-[280px]">
      <div className="flex items-center gap-3">
        <button 
          onClick={togglePlay}
          className={cn(
            "w-[44px] h-[44px] rounded-full flex items-center justify-center flex-shrink-0 text-white shadow-sm transition-transform active:scale-90",
            isMe ? "bg-[#4FA953]" : "bg-blue-500"
          )}
        >
          {isPlaying ? (
            <Pause className="w-[20px] h-[20px] fill-current" />
          ) : (
            <Play className="w-[20px] h-[20px] ml-0.5 fill-current" />
          )}
        </button>
        <div className="flex-1 flex flex-col justify-center gap-1.5 min-w-0">
          {/* Waveform */}
          <div 
            ref={waveformRef}
            onPointerDown={handleSeek}
            className="flex items-center gap-[2px] h-[24px] cursor-pointer touch-none"
          >
            {waveform.map((h, i) => {
              const barProgress = i / waveform.length;
              const isPlayed = barProgress <= progress;
              return (
                <div 
                  key={i} 
                  className={cn(
                    "flex-1 rounded-full min-w-[2px]",
                    isPlayed 
                      ? (isMe ? "bg-[#4FA953]" : "bg-blue-500") 
                      : (isMe ? "bg-[#4FA953]/30" : "bg-blue-500/30")
                  )} 
                  style={{ height: `${Math.max(20, h * 10)}%` }}
                />
              );
            })}
          </div>
          <div className="flex items-center justify-between mt-[-2px]">
            <div className="flex items-center gap-2">
              <span className={cn(
                "text-[12px] font-medium tracking-wide",
                isMe ? "text-[#4FA953]" : "text-gray-500"
              )}>
                {isPlaying ? currentTime : (msg.audioDuration || '0:00')}
              </span>
              {isPlaying && (
                <button 
                  onClick={toggleSpeed}
                  className={cn(
                    "text-[10px] font-bold px-1.5 py-0.5 rounded-full transition-colors",
                    isMe ? "bg-[#4FA953]/20 text-[#4FA953] hover:bg-[#4FA953]/30" : "bg-blue-100 text-blue-600 hover:bg-blue-200"
                  )}
                >
                  {playbackRate}x
                </button>
              )}
            </div>
            <div className={cn("flex items-center justify-end gap-1 mt-1 select-none", isMe ? "text-[#53b259]" : "text-gray-400")}>
              <span className="text-[11px] font-medium leading-none tabular-nums">{msg.time}</span>
              <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
