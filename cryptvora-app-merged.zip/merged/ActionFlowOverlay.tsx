import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Camera, Search, UserPlus, User, Share2, Flag, AlertTriangle } from 'lucide-react';
import { usePopupManager } from './usePopupManager';

export const ActionFlowOverlay = ({ action, onClose, showToast }: { action: string | null; onClose: () => void; showToast?: (m: string) => void }) => {
  usePopupManager(!!action, onClose);
  const [inputValue, setInputValue] = useState('');

  return (
    <AnimatePresence>
      {action && (
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="fixed inset-0 bg-white z-50 flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center px-2 h-14 border-b border-gray-100 bg-white/80 backdrop-blur-xl shrink-0">
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-gray-100 transition-colors"
            >
              <ChevronLeft className="w-6 h-6 text-gray-700" />
            </button>
            <h2 className="ml-2 font-semibold text-lg text-gray-900 tracking-tight">
              {action}
            </h2>
          </div>

          {/* Content area */}
          <div className="flex-1 overflow-y-auto px-4 py-6 bg-gray-50 flex flex-col items-center justify-start">

            {action === 'View Profile' ? (
              <div className="flex flex-col items-center w-full mt-4">
                <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center text-blue-500 mb-4 shadow-sm border-4 border-white">
                  <User className="w-12 h-12" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">User Profile</h3>
                <p className="text-gray-500 text-sm mb-6">+1 234 567 8900</p>
                <div className="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-gray-100 divide-y divide-gray-50">
                  <div className="p-4 flex items-center justify-between">
                    <span className="text-gray-600 font-medium">Username</span>
                    <span className="text-gray-900">@username</span>
                  </div>
                  <div className="p-4 flex items-center justify-between">
                    <span className="text-gray-600 font-medium">Bio</span>
                    <span className="text-gray-900 text-right">Available</span>
                  </div>
                </div>
              </div>
            ) : action === 'Share Contact' ? (
              <div className="flex flex-col items-center w-full mt-10">
                <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-500 mb-4">
                  <Share2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Share this contact</h3>
                <p className="text-gray-500 text-sm text-center max-w-xs mb-8">Share contact details with friends and family via other apps.</p>

                <div className="grid grid-cols-4 gap-4 w-full max-w-sm">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                    <div key={i} className="flex flex-col items-center gap-2">
                      <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center border border-gray-100 active:scale-95 transition-transform cursor-pointer">
                        <User className="w-6 h-6 text-gray-400" />
                      </div>
                      <span className="text-[11px] text-gray-500 font-medium">App {i}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : action === 'Report User' ? (
              <div className="flex flex-col w-full max-w-sm mx-auto">
                <div className="flex items-center gap-3 mb-6 text-red-500">
                  <AlertTriangle className="w-6 h-6" />
                  <h3 className="text-lg font-bold text-gray-900">Select a reason</h3>
                </div>
                <div className="flex flex-col gap-3">
                  {['Spam', 'Inappropriate Content', 'Harassment', 'Fake Account', 'Other'].map(reason => (
                    <button
                      key={reason}
                      onClick={() => { onClose(); showToast?.('Report submitted successfully'); }}
                      className="w-full text-left bg-white px-5 py-4 rounded-2xl font-medium text-gray-800 shadow-sm border border-gray-100 hover:border-red-200 active:bg-gray-50 transition-colors"
                    >
                      {reason}
                    </button>
                  ))}
                </div>
              </div>
            ) : action === 'Scan QR Code' ? (
              <div className="flex flex-col items-center justify-center h-full w-full max-w-sm mx-auto opacity-70">
                <div className="w-64 h-64 border-4 border-dashed border-gray-300 rounded-3xl flex items-center justify-center mb-6 relative">
                  <Camera className="w-12 h-12 text-gray-400" />
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-blue-500 rounded-tl-xl m-2" />
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-blue-500 rounded-tr-xl m-2" />
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-blue-500 rounded-bl-xl m-2" />
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-blue-500 rounded-br-xl m-2" />
                </div>
                <p className="text-gray-500 text-center text-[15px]">Position QR code within the frame to scan</p>
              </div>
            ) : action === 'New Message' ? (
              <div className="w-full max-w-md mx-auto flex flex-col gap-4">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search contacts..."
                    value={inputValue}
                    onChange={e => setInputValue(e.target.value)}
                    className="w-full bg-white border border-gray-200 rounded-2xl py-3 pl-12 pr-4 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                  />
                </div>
                <div className="bg-white rounded-2xl border border-gray-100 p-8 flex flex-col items-center justify-center text-center mt-4 shadow-sm">
                  <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
                    <UserPlus className="w-8 h-8 text-blue-500" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">No Contacts Yet</h3>
                  <p className="text-sm text-gray-500 max-w-[250px]">Search for people by their username or phone number to start chatting.</p>
                </div>
              </div>
            ) : (
              <div className="w-full max-w-md mx-auto flex flex-col gap-6">
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-semibold text-gray-700 ml-1">Name</label>
                  <input
                    type="text"
                    placeholder={`Enter ${action.toLowerCase().replace('new ', '')} name`}
                    className="w-full bg-white border border-gray-200 rounded-2xl py-3.5 px-4 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all text-[15px]"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-semibold text-gray-700 ml-1">Description (Optional)</label>
                  <textarea
                    placeholder="Add a description"
                    rows={3}
                    className="w-full bg-white border border-gray-200 rounded-2xl py-3.5 px-4 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all text-[15px] resize-none"
                  />
                </div>

                <button
                  onClick={onClose}
                  className="mt-4 w-full bg-blue-500 hover:bg-blue-600 active:bg-blue-700 text-white rounded-2xl py-4 font-semibold text-[15px] shadow-lg shadow-blue-500/25 transition-all"
                >
                  Create {action.replace('New ', '')}
                </button>
              </div>
            )}

          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
