export interface PostData {
  id: string;
  author: {
    name: string;
    handle: string;
  };
  content: string;
  image?: string;
  timestamp: string;
  likes: number;
  comments: number;
  shares: number;
  linkPreview?: {
    symbol: string;
    change: string;
    isPositive: boolean;
  };
}

export const MOCK_POSTS: PostData[] = [
  {
    id: 'post-1',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "Fed's Powell signals patience; markets pricing in a longer hold. 2Y yields easing.",
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "18m",
    likes: 412100,
    comments: 38,
    shares: 74
  },
  {
    id: 'post-2',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "ETH 4H broke the descending trendline with volume. I'm patient — waiting for the retest before scaling in. Invalidation clearly below the last swing. Here is a longer continuation of the text to trigger the Read More feature clearly.",
    image: "https://images.unsplash.com/photo-1621504450181-5d156ff148bd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    linkPreview: {
      symbol: "ETH/USD",
      change: "+1.12%",
      isPositive: true
    },
    timestamp: "42m",
    likes: 128,
    comments: 15,
    shares: 12
  },
  {
    id: 'post-3',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "Solana continuing its strength relative to the rest of the market. Watching the 120 level closely.",
    image: "https://images.unsplash.com/photo-1639762681485-074b7f4ec08d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "2h",
    likes: 3450,
    comments: 142,
    shares: 88
  },
  {
    id: 'post-4',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "New deep dive on zero-knowledge rollups is out now. Link in bio.",
    image: "https://images.unsplash.com/photo-1639322537228-f710d846310a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "5h",
    likes: 12050,
    comments: 890,
    shares: 430
  },
  {
    id: 'post-5',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "Market sentiment is shifting. Are you positioned accordingly?",
    image: "https://images.unsplash.com/photo-1642104704074-907c0698cbd9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "1d",
    likes: 8900,
    comments: 210,
    shares: 150
  },
  {
    id: 'post-6',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "Building in a bear market is where the real value is created.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "2d",
    likes: 24500,
    comments: 530,
    shares: 210
  },
  {
    id: 'post-7',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "Bitcoin dominance testing major resistance.",
    image: "https://images.unsplash.com/photo-1516245834210-c4c142787335?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "3d",
    likes: 5600,
    comments: 120,
    shares: 45
  },
  {
    id: 'post-8',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "DeFi total value locked is creeping back up.",
    image: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "4d",
    likes: 4200,
    comments: 85,
    shares: 30
  },
  {
    id: 'post-9',
    author: { name: 'Nightowl', handle: 'nightowl' },
    content: "Remember to take profits.",
    image: "https://images.unsplash.com/photo-1614028674026-a65e31bfd27c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    timestamp: "5d",
    likes: 18000,
    comments: 420,
    shares: 310
  }
];
