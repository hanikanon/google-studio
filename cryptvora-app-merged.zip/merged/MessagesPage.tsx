import React, { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Link2, Star, Phone, Bell, Video, MoreVertical, Plus, Mic, Image as ImageIcon, Check, CheckCheck, Search, Play, FileText, Download, User, BellOff, Pin, Share2, Copy, CornerUpLeft, Bookmark, Trash2, XCircle, Flag, Palette, Image, Send, Smile, Camera, MapPin, BarChart2, Edit2, X, Music, Folder} from 'lucide-react';
import { Chat, Message } from './data';
import { cn } from './utils';
import { usePopupManager } from './usePopupManager';
import { AudioMessage } from './AudioMessage';
import { MessageIndicators } from './MessageIndicators';
import { MessageInput } from './MessageInput';
import { AttachmentMenu } from './AttachmentMenu';
import { useAudioRecorder } from './useAudioRecorder';

interface MessagesPageProps {
  chat: Chat;
  onBack: () => void;
  onUpdateChat?: (id: string, updates: Partial<Chat>) => void;
}

export const MessagesPage: React.FC<MessagesPageProps> = ({ chat, onBack, onUpdateChat }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAttachmentOpen, setIsAttachmentOpen] = useState(false);
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null);
  const [contextMenuPosition, setContextMenuPosition] = useState<'top' | 'bottom'>('bottom');
  const [messages, setMessages] = useState<Message[]>(chat.messages || []);
  const [activeChatFilter, setActiveChatFilter] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null);
  const [mediaViewer, setMediaViewer] = useState<{msg: Message, index: number} | null>(null);

  const scrollToMessage = (id: string) => {
    const el = document.getElementById(`msg-${id}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setHighlightedMessageId(id);
      setTimeout(() => setHighlightedMessageId(null), 1500);
    }
  };
    
  const { isRecording, recordingDuration, startRecording, stopRecording, cancelRecording } = useAudioRecorder();
  const [isHoldingMic, setIsHoldingMic] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [showProfile, setShowProfile] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [showDocuments, setShowDocuments] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const lastPinnedMessage = [...messages].reverse().find(m => m.isPinned);
  const filteredMessages = messages.filter(msg => {
    if (searchQuery && !(msg.text || '').toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (activeChatFilter === 'favorites' && !msg.isSaved) return false;
    if (activeChatFilter === 'pinned' && !msg.isPinned) return false;
    if (activeChatFilter === 'photos' && msg.type !== 'image') return false;
    if (activeChatFilter === 'videos' && msg.type !== 'video') return false;
    if (activeChatFilter === 'documents' && msg.type !== 'file') return false;
    if (activeChatFilter === 'voice' && msg.type !== 'audio') return false;
    if (activeChatFilter === 'links' && !(msg.text || '').match(/https?:\/\/[^\s]+/i)) return false;
    return true;
  });
  const isMuted = chat.isMuted || false;
  const setIsMuted = (muted: boolean) => {
    onUpdateChat?.(chat.id, { isMuted: muted });
  };
  const isPinned = chat.isPinned || false;
  const setIsPinned = (pinned: boolean) => {
    onUpdateChat?.(chat.id, { isPinned: pinned });
  };
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const isBlocked = chat.isBlocked || false;
  const setIsBlocked = (blocked: boolean) => {
    onUpdateChat?.(chat.id, { isBlocked: blocked });
  };
  const [chatWallpaper, setChatWallpaper] = useState<string | null>(null);
  const [chatTheme, setChatTheme] = useState<'light' | 'dark' | 'auto'>('light');

  const [slideOffset, setSlideOffset] = useState(0);
  const pointerStartX = useRef<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files);
      setSelectedFiles(prev => [...prev, ...newFiles]);
    }
    // reset input value so selecting the same file again works
    e.target.value = '';
  };

  const handleLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        const newMsg: Message = {
          id: Date.now().toString(),
          senderId: 'me',
          text: `📍 Location: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}\nhttps://maps.google.com/?q=${latitude},${longitude}`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isRead: false,
          type: 'text'
        };
        setMessages(prev => {
      const next = [...prev, newMsg as any];
      chat.messages = next;
      return next;
    });
        setIsAttachmentOpen(false);
      }, (error) => {
        alert("Unable to get location: " + error.message);
      });
    } else {
      alert("Geolocation is not supported by your browser");
    }
  };

  const handlePoll = () => {
    const question = window.prompt('Enter poll question:') || 'New Poll';
    const opt1 = window.prompt('Option 1:') || 'Yes';
    const opt2 = window.prompt('Option 2:') || 'No';
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: 'me',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isRead: false,
      readStatus: 'sending',
      type: 'poll',
      pollData: { question, options: [{ text: opt1, votes: 0 }, { text: opt2, votes: 0 }] }
    };
    setMessages(prev => [...prev, newMsg]);
    setTimeout(() => setMessages(prev => prev.map(m => m.id === newMsg.id ? { ...m, readStatus: 'sent' } : m)), 1000);
  };

  const handleGif = () => {
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: 'me',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isRead: false,
      readStatus: 'sending',
      type: 'image',
      imageUrl: 'https://media.giphy.com/media/l0HlJzWDtqAWqF7A4/giphy.gif'
    };
    setMessages(prev => [...prev, newMsg]);
    setTimeout(() => setMessages(prev => prev.map(m => m.id === newMsg.id ? { ...m, readStatus: 'sent' } : m)), 1000);
  };

  const handleSticker = () => {
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: 'me',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isRead: false,
      readStatus: 'sending',
      type: 'sticker',
      stickerUrl: 'https://cdn-icons-png.flaticon.com/512/7516/7516768.png'
    };
    setMessages(prev => [...prev, newMsg]);
    setTimeout(() => setMessages(prev => prev.map(m => m.id === newMsg.id ? { ...m, readStatus: 'sent' } : m)), 1000);
  };

  const handleCall = (isVideo: boolean) => {
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: 'me',
      text: isVideo ? '📹 Video call started' : '📞 Voice call started',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isRead: false,
      readStatus: 'sending',
      type: 'text'
    };
    setMessages(prev => [...prev, newMsg]);
    setTimeout(() => setMessages(prev => prev.map(m => m.id === newMsg.id ? { ...m, readStatus: 'sent' } : m)), 1000);
  };

  const handleContact = async () => {
    if ('contacts' in navigator && 'ContactsManager' in window) {
      try {
        const props = ['name', 'tel'];
        const contacts = await (navigator as any).contacts.select(props, { multiple: false });
        if (contacts.length > 0) {
          const contact = contacts[0];
          const name = contact.name?.[0] || 'Unknown';
          const phone = contact.tel?.[0] || 'No number';
          const newMsg: Message = {
            id: Date.now().toString(),
            senderId: 'me',
            text: `👤 Contact: ${name}\n📞 ${phone}`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isRead: false,
            type: 'text'
          };
          setMessages(prev => [...prev, newMsg as any]);
          setIsAttachmentOpen(false);
        }
      } catch (ex: any) {
        alert("Unable to access contacts: " + ex.message);
      }
    } else {
      alert("Contact picker is not supported by your browser/device.");
    }
  };
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const handleAudioError = (e: any) => {
      setAudioError(e.detail);
      setIsHoldingMic(false);
      setTimeout(() => setAudioError(null), 3000);
    };
    window.addEventListener('AUDIO_RECORD_ERROR', handleAudioError);

  return () => window.removeEventListener('AUDIO_RECORD_ERROR', handleAudioError);
  }, []);


  usePopupManager(isMenuOpen, () => setIsMenuOpen(false));
  usePopupManager(isAttachmentOpen, () => setIsAttachmentOpen(false));
  usePopupManager(!!selectedMessageId, () => { setSelectedMessageId(null); setIsMoreMenuOpen(false); });


  const handleMicPointerDown = (e: React.PointerEvent) => {
    if (inputText.trim() || selectedFiles.length > 0) return; 
    e.preventDefault();
    e.stopPropagation();
    setIsHoldingMic(true);
    setSlideOffset(0);
    pointerStartX.current = e.clientX;
    startRecording();
    if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
    }
  };

  const handleMicPointerMove = (e: React.PointerEvent) => {
    if (isHoldingMic && pointerStartX.current !== null) {
        const diff = pointerStartX.current - e.clientX;
        if (diff > 0) {
            setSlideOffset(-diff);
        }
        if (diff > 120) {
            cancelRecording();
            setIsHoldingMic(false);
            pointerStartX.current = null;
            setSlideOffset(0);
            if (window.navigator && window.navigator.vibrate) {
                window.navigator.vibrate(50);
            }
        }
    }
  };

  const handleMicPointerUp = async (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isHoldingMic) {
        setIsHoldingMic(false);
        pointerStartX.current = null;
        setSlideOffset(0);
        if (recordingDuration < 1) {
            cancelRecording();
            return;
        }
        const result = await stopRecording();
        if (result) {
            const mins = Math.floor(result.duration / 60);
            const secs = Math.floor(result.duration % 60);
            const durationStr = `${mins}:${secs.toString().padStart(2, '0')}`;
            
            const newMsg = {
                id: Date.now().toString(),
                senderId: 'me',
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                isRead: false,
                type: 'audio',
                audioUrl: result.url,
                audioDuration: durationStr,
                waveform: result.waveform
            };
            setMessages(prev => [...prev, newMsg as any]);
        }
    }
  };

  const handleReply = (msg: Message) => {
    setReplyingTo(msg);
    setSelectedMessageId(null);
    setIsMoreMenuOpen(false);
    if (window.navigator && window.navigator.vibrate) {
      window.navigator.vibrate(50);
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [inputText]);

  
  const handleSendAudio = (url: string, duration: number, waveform: number[]) => {
    const mins = Math.floor(duration / 60);
    const secs = Math.floor(duration % 60);
    const durationStr = `${mins}:${secs.toString().padStart(2, '0')}`;
    
    const newMsg = {
        id: Date.now().toString(),
        senderId: 'me',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isRead: false,
        type: 'audio',
        audioUrl: url,
        audioDuration: durationStr,
        waveform: waveform
    };
    setMessages(prev => [...prev, newMsg as any]);
  };

  const handleSendMedia = (files: File[], caption?: string) => {
    const imgFiles = files.filter(f => f.type.startsWith('image/') || f.type.startsWith('video/'));
    const docFiles = files.filter(f => !f.type.startsWith('image/') && !f.type.startsWith('video/'));
    
    if (imgFiles.length > 0) {
      const mediaGroup = imgFiles.map(f => ({ 
        url: URL.createObjectURL(f), 
        type: f.type.startsWith('video/') ? 'video' : 'image' 
      }));
      const newMsg = {
          id: Date.now().toString(),
          senderId: 'me',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isRead: false,
          readStatus: 'sending' as const,
          type: 'image' as const,
          mediaGroup: mediaGroup,
          imageUrl: mediaGroup[0].url,
          text: caption
      };
      setMessages(prev => [...prev, newMsg as any]);
      setTimeout(() => setMessages(prev => prev.map(m => m.id === newMsg.id ? { ...m, readStatus: 'sent' } : m)), 1000);
    } else if (docFiles.length > 0 && caption) {
        handleSendText(caption);
    }
    
    docFiles.forEach((f, i) => {
       const newMsg = {
          id: Date.now().toString() + i,
          senderId: 'me',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isRead: false,
          readStatus: 'sending' as const,
          type: 'file' as const,
          fileName: f.name,
          fileSize: (f.size / 1024 / 1024).toFixed(1) + ' MB',
          fileType: f.type || 'Document'
       };
       setMessages(prev => [...prev, newMsg as any]);
       setTimeout(() => setMessages(prev => prev.map(m => m.id === newMsg.id ? { ...m, readStatus: 'sent' } : m)), 1000 + (i * 200));
    });
  };


  const handleDoubleTap = (msg: Message) => {
    handleReaction(msg.id, '👍');
  };

  const handleReaction = (msgId: string, emoji: string) => {
    setMessages(prev => prev.map(m => {
        if (m.id === msgId) {
             const existing = m.reactions || [];
             const reactionIdx = existing.findIndex(r => r.emoji === emoji);
             if (reactionIdx !== -1) {
                  const newReactions = existing.map((r, i) => i === reactionIdx ? { ...r } : r);
                  if (newReactions[reactionIdx].userReacted) {
                      newReactions[reactionIdx].count--;
                      newReactions[reactionIdx].userReacted = false;
                      if (newReactions[reactionIdx].count <= 0) {
                          newReactions.splice(reactionIdx, 1);
                      }
                  } else {
                      newReactions[reactionIdx].count++;
                      newReactions[reactionIdx].userReacted = true;
                  }
                  if (window.navigator && window.navigator.vibrate) window.navigator.vibrate(10);
                  return { ...m, reactions: newReactions };
             } else {
                  if (navigator.vibrate) navigator.vibrate(10);
                  return { ...m, reactions: [...existing, { emoji, count: 1, userReacted: true }] };
             }
        }
        return m;
    }));
    setSelectedMessageId(null);
  };

  const handleSendText = (text: string) => {
    if (!text.trim()) return;
    
    
    let newMsg: Message = {
      id: Date.now().toString(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      senderId: 'me',
      isRead: false,
      replyTo: replyingTo || undefined,
    };
    setReplyingTo(null);

    if (false) { } else {
      newMsg = {
        ...newMsg,
        type: 'text',
        text: text,
      };
    }

    setMessages(prev => [...prev, newMsg as any]);
    
    setIsAttachmentOpen(false);
    setReplyingTo(null);
    
    
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        text: "That sounds great! I'll get back to you shortly.",
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        senderId: chat.id,
        isRead: true,
        type: 'text'
      }]);
    }, 2000);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const pointerStartRef = useRef<{x: number, y: number} | null>(null);

  const handlePointerDown = (msgId: string, event: React.PointerEvent<HTMLDivElement>) => {
    pointerStartRef.current = { x: event.clientX, y: event.clientY };
    const currentTarget = event.currentTarget;
    
    longPressTimer.current = setTimeout(() => {
      const rect = currentTarget.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      
      // Calculate available space
      const headerHeight = 60;
      const inputHeight = 70;
      const spaceAbove = rect.top - headerHeight;
      const spaceBelow = windowHeight - rect.bottom - inputHeight;
      
      // Approximate menu height (Reactions + Menu items)
      const menuHeight = 280; 

      let position: 'top' | 'bottom' = 'top';

      if (spaceAbove >= menuHeight) {
        position = 'top';
      } else if (spaceBelow >= menuHeight) {
        position = 'bottom';
      } else {
        // Pick the position that has the most space
        position = spaceAbove > spaceBelow ? 'top' : 'bottom';
      }
      
      setSelectedMessageId(msgId);
      setIsMoreMenuOpen(false); 
      setContextMenuPosition(position);

      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
      
      // Auto-scroll so both message and menu are fully visible
      setTimeout(() => {
        const padding = 24;
        if (position === 'top' && spaceAbove < menuHeight) {
          const scrollAmount = menuHeight - spaceAbove + padding;
          scrollRef.current?.scrollBy({ top: -scrollAmount, behavior: 'smooth' });
        } else if (position === 'bottom' && spaceBelow < menuHeight) {
          const scrollAmount = menuHeight - spaceBelow + padding;
          scrollRef.current?.scrollBy({ top: scrollAmount, behavior: 'smooth' });
        }
      }, 50);

    }, 350);
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (pointerStartRef.current && longPressTimer.current) {
      const dx = event.clientX - pointerStartRef.current.x;
      const dy = event.clientY - pointerStartRef.current.y;
      if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
        clearTimeout(longPressTimer.current);
        longPressTimer.current = null;
      }
    }
  };

  const handlePointerUp = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
    pointerStartRef.current = null;
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  return (
    <motion.div
      initial={{ x: '100%', opacity: 0.95 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: '100%', opacity: 0.95 }}
      transition={{ type: 'spring', damping: 28, stiffness: 300, mass: 0.8 }}
      className={cn("absolute inset-0 z-50 flex flex-col w-full h-full", chatTheme === "dark" ? "bg-gray-900" : (chatWallpaper || "bg-[#e4e2de]"))}
    >
      {/* Header */}
      <div className={cn("backdrop-blur-xl pt-2 px-1 flex flex-col z-50 shrink-0 shadow-[0_1px_3px_rgba(0,0,0,0.05)] relative", chatTheme === 'dark' ? 'bg-gray-900/95 border-b border-gray-800' : 'bg-white/95')}>
        <div className="flex items-center justify-between h-[52px]">
          {showSearch ? (
            <div className="flex items-center w-full px-2 gap-2">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="p-2 -ml-2 text-gray-500 hover:bg-gray-100 rounded-full">
                <ArrowLeft className="w-[22px] h-[22px]" />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search messages..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[15px]"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-1">
                <button 
                  onClick={onBack}
                  className="p-2 -ml-1 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90"
                >
                  <ArrowLeft className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                <div className="flex items-center gap-2.5 cursor-pointer pl-1 active:opacity-70 transition-opacity">
                  <div className="relative">
                    <div className={cn(
                      "w-[38px] h-[38px] rounded-full overflow-hidden flex items-center justify-center relative",
                      chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200"
                    )}>
                      {chat.avatarType === 'image' ? (
                        <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                      ) : null}
                    </div>
                    {chat.isOnline && (
                      <div className="absolute bottom-0 right-0 w-[12px] h-[12px] bg-[#22c55e] border-[2px] border-white rounded-full z-20"></div>
                    )}
                  </div>
                  <div className="flex flex-col justify-center">
                    <span className="font-semibold text-[16px] text-gray-900 leading-tight tracking-tight flex items-center gap-1">
                      {chat.name}
                      {isMuted && <BellOff className="w-3.5 h-3.5 text-gray-400" />}
                      {isPinned && <Pin className="w-3.5 h-3.5 text-gray-400 fill-gray-400" />}
                    </span>
                    <span className="text-[13px] text-gray-500 leading-tight mt-[2px] tracking-wide">
                      {isTyping ? <span className="text-blue-500 font-medium">typing...</span> : (chat.isOnline ? <span className="text-blue-500">online</span> : 'last seen recently')}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center pr-1 gap-1">
                <button onClick={() => handleCall(true)} className={cn("p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90", isBlocked && "opacity-30 pointer-events-none")}>
                  <Video className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                <button onClick={() => handleCall(false)} className={cn("p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90", isBlocked && "opacity-30 pointer-events-none")}>
                  <Phone className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90">
                    <MoreVertical className="w-[22px] h-[22px]" strokeWidth={2.5} />
                  </button>
                  <AnimatePresence>
                    {isMenuOpen && <motion.div key="menu-bg" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 w-screen h-screen z-40 cursor-default touch-none" onClick={() => setIsMenuOpen(false)} />}
                    {isMenuOpen && (
                        <motion.div 
                          key="menu-modal"
                          initial={{ opacity: 0, scale: 0.95, transformOrigin: 'top right' }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          transition={{ duration: 0.1 }}
                          className="absolute right-0 top-10 w-48 bg-white/95 backdrop-blur-xl rounded-[16px] shadow-lg py-1.5 z-50 border border-gray-100/80"
                        >
                          {[
                            { icon: <User className="w-[16px] h-[16px]" />, label: 'View Profile', action: () => { setShowProfile(true); setIsMenuOpen(false); } },
                            { icon: <Search className="w-[16px] h-[16px]" />, label: 'Search', action: () => { setShowSearch(true); setIsMenuOpen(false); } },
                            { icon: isMuted ? <BellOff className="w-[16px] h-[16px]" /> : <Bell className="w-[16px] h-[16px]" />, label: isMuted ? 'Unmute' : 'Mute', action: () => { setIsMuted(!isMuted); setIsMenuOpen(false); } },
                            { icon: <Pin className="w-[16px] h-[16px]" />, label: isPinned ? 'Unpin Chat' : 'Pin Chat', action: () => { setIsPinned(!isPinned); setIsMenuOpen(false); } },
                            { divider: true },
                            { icon: <Star className="w-[16px] h-[16px]" />, label: 'Favorites', action: () => { setActiveChatFilter(activeChatFilter === 'favorites' ? null : 'favorites'); setIsMenuOpen(false); } },
                            { icon: <Pin className="w-[16px] h-[16px]" />, label: 'Pinned Messages', action: () => { setActiveChatFilter(activeChatFilter === 'pinned' ? null : 'pinned'); setIsMenuOpen(false); } },
                            { icon: <ImageIcon className="w-[16px] h-[16px]" />, label: 'Photos', action: () => { setActiveChatFilter(activeChatFilter === 'photos' ? null : 'photos'); setIsMenuOpen(false); } },
                            { icon: <Video className="w-[16px] h-[16px]" />, label: 'Videos', action: () => { setActiveChatFilter(activeChatFilter === 'videos' ? null : 'videos'); setIsMenuOpen(false); } },
                            { icon: <FileText className="w-[16px] h-[16px]" />, label: 'Documents', action: () => { setActiveChatFilter(activeChatFilter === 'documents' ? null : 'documents'); setIsMenuOpen(false); } },
                            { icon: <Mic className="w-[16px] h-[16px]" />, label: 'Voice', action: () => { setActiveChatFilter(activeChatFilter === 'voice' ? null : 'voice'); setIsMenuOpen(false); } },
                            { icon: <Link2 className="w-[16px] h-[16px]" />, label: 'Links', action: () => { setActiveChatFilter(activeChatFilter === 'links' ? null : 'links'); setIsMenuOpen(false); } },
                            { divider: true },
                            { icon: <ImageIcon className="w-[16px] h-[16px]" />, label: 'Media', action: () => { setShowGallery(true); setIsMenuOpen(false); } },
                            { icon: <FileText className="w-[16px] h-[16px]" />, label: 'Shared Files', action: () => { setShowDocuments(true); setIsMenuOpen(false); } },
                            { divider: true },
                            { icon: <ImageIcon className="w-[16px] h-[16px]" />, label: 'Wallpaper', action: () => { setChatWallpaper('bg-blue-50'); setIsMenuOpen(false); } },
                            { icon: <Palette className="w-[16px] h-[16px]" />, label: 'Theme', action: () => { setChatTheme(chatTheme === 'light' ? 'dark' : 'light'); setIsMenuOpen(false); } },
                            { divider: true },
                            { icon: <Trash2 className="w-[16px] h-[16px] text-red-500" />, label: 'Clear Chat', textRed: true, action: () => { setShowClearConfirm(true); setIsMenuOpen(false); } },
                            { icon: <XCircle className="w-[16px] h-[16px] text-red-500" />, label: isBlocked ? 'Unblock User' : 'Block User', textRed: true, action: () => { if(isBlocked) { setIsBlocked(false); setIsMenuOpen(false); } else { setShowBlockConfirm(true); setIsMenuOpen(false); } } },
                          ].map((item: any, i) => 
                            item.divider ? (
                              <div key={i} className="h-px bg-gray-100/80 my-1 mx-2" />
                            ) : (
                              <button key={i} onClick={item.action} className="w-full flex items-center px-3 py-2 hover:bg-gray-50 transition-colors gap-3">
                                <div className={item.textRed ? "text-red-500" : "text-gray-500"}>{item.icon}</div>
                                <span className={cn("text-[14px] font-medium", item.textRed ? "text-red-500" : "text-gray-800")}>{item.label}</span>
                              </button>
                            )
                          )}
                        </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-2 py-4 flex flex-col gap-1 relative"
      >
        <AnimatePresence>
          {activeChatFilter && (
            <motion.div
              key="filter-pill"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="sticky top-2 z-30 mx-auto bg-blue-500/90 backdrop-blur-md text-white px-4 py-1.5 rounded-full text-[13px] font-medium shadow-md flex items-center gap-2 mb-2"
            >
              <span className="capitalize">Viewing {activeChatFilter}</span>
              <button onClick={() => setActiveChatFilter(null)} className="ml-1 hover:bg-white/20 p-1 rounded-full transition-colors active:scale-95">
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          )}
          {!activeChatFilter && lastPinnedMessage && (
            <motion.div
              key="pinned-banner"
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ type: 'spring', damping: 25, stiffness: 400 }}
              className="sticky top-1 z-30 mx-auto max-w-[90%] bg-white/90 backdrop-blur-xl border border-gray-200/60 shadow-sm rounded-xl px-3 py-2 flex items-center gap-3 cursor-pointer hover:bg-gray-50/90 active:scale-95 transition-all"
              onClick={() => {
                const target = document.getElementById(`msg-${lastPinnedMessage.id}`);
                if (target) {
                  target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  setHighlightedMessageId(lastPinnedMessage.id);
                  setTimeout(() => setHighlightedMessageId(null), 1500);
                }
              }}
            >
              <div className="w-[3px] h-full absolute left-0 top-0 bottom-0 bg-blue-500 rounded-l-xl"></div>
              <div className="flex flex-col flex-1 min-w-0 pl-1">
                <span className="text-[12px] font-semibold text-blue-500 flex items-center gap-1">
                  <Pin className="w-3 h-3 fill-current rotate-45" /> Pinned Message
                </span>
                <span className="text-[13px] text-gray-700 truncate">
                  {lastPinnedMessage.text || 'Attachment'}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="flex justify-center my-2">
          <div className="bg-black/10 backdrop-blur-sm text-white px-3 py-1 rounded-full text-[12px] font-medium tracking-wide shadow-sm">
            Today
          </div>
        </div>
        
        <AnimatePresence initial={false}>
        {filteredMessages && filteredMessages.length > 0 ? (
          filteredMessages.map((msg, index) => {
            const isMe = msg.senderId === 'me';
            const isSelected = selectedMessageId === msg.id;
            
            // Check previous message to see if we should cluster
            const prevMsg = index > 0 ? filteredMessages[index - 1] : null;
            const nextMsg = index < filteredMessages.length - 1 ? filteredMessages[index + 1] : null;
            const isFirstInCluster = !prevMsg || prevMsg.senderId !== msg.senderId;
            const isLastInCluster = !nextMsg || nextMsg.senderId !== msg.senderId;
            
            return (
              <motion.div 
                id={`msg-${msg.id}`}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                layout
                key={msg.id} 
                className={cn(
                  "flex flex-col relative", 
                  isMe ? "items-end" : "items-start", 
                  isSelected ? "z-50" : "z-10",
                  !isLastInCluster && "mb-[-1px]"
                )}
              >
                {/* Overlay for context menu */}
                {isSelected && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 w-screen h-screen z-40 bg-black/30 backdrop-blur-[2px] cursor-default touch-none" 
                    onClick={() => { setSelectedMessageId(null); setIsMoreMenuOpen(false); }}
                  />
                )}
                
                <motion.div 
                  drag="x"
                  dragDirectionLock
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={{ left: 0.15, right: 0 }}
                  onDragStart={() => {
                    if (longPressTimer.current) {
                      clearTimeout(longPressTimer.current);
                      longPressTimer.current = null;
                    }
                  }}
                  onDragEnd={(e, info) => {
                    if (info.offset.x < -40) {
                      handleReply(msg);
                    }
                  }}
                  onPointerDown={(e) => handlePointerDown(msg.id, e as any)}
                  onPointerMove={(e) => handlePointerMove(e as any)}
                  onPointerUp={handlePointerUp}
                  onPointerCancel={handlePointerUp}
                  className={cn(
                    "max-w-[85%] rounded-[18px] flex flex-col relative transition-transform duration-200 touch-pan-y",
                    isSelected ? "scale-105 z-50 shadow-2xl" : "",
                    highlightedMessageId === msg.id ? "ring-2 ring-[#8B5CF6] shadow-xl" : "",
                    // Clustering corners
                    isMe 
                      ? cn("rounded-tl-[18px] rounded-tr-[18px] rounded-bl-[18px]", isLastInCluster ? "rounded-br-[4px]" : "rounded-br-[18px]")
                      : cn("rounded-tr-[18px] rounded-tl-[18px] rounded-br-[18px]", isLastInCluster ? "rounded-bl-[4px]" : "rounded-bl-[18px]"),
                    msg.type === 'sticker' 
                      ? "bg-transparent shadow-none" 
                      : isMe 
                        ? "bg-[#effdd6] text-gray-900" 
                        : "bg-white text-gray-900"
                  )}
                >
                  
                  {msg.replyTo && (
                    <div 
                      onClick={(e) => { e.stopPropagation(); console.log("Trying to scroll to:", msg.replyTo.id); const target = document.getElementById(`msg-${msg.replyTo.id}`); if(target) { target.scrollIntoView({behavior: "smooth", block: "center"}); setHighlightedMessageId(msg.replyTo.id); setTimeout(() => setHighlightedMessageId(null), 1500); } else { console.error("Target ID not found in DOM: msg-" + msg.replyTo.id); } }}
                      className={cn(
                      "mx-1.5 mt-1.5 mb-1 px-2.5 py-1.5 rounded-xl border-l-[3px] flex flex-col cursor-pointer hover:opacity-80 active:opacity-70 transition-opacity",
                      isMe ? "bg-[#dcedb9]/70 border-green-600 text-gray-800" : "bg-gray-100 border-blue-500 text-gray-800"
                    )}>
                      <span className={cn(
                        "text-[13px] font-bold leading-tight mb-0.5",
                        isMe ? "text-green-700" : "text-blue-500"
                      )}>
                        {msg.replyTo.senderId === 'me' ? 'You' : chat.name}
                      </span>
                      <span className="text-[13px] leading-tight line-clamp-1 opacity-80">
                        {msg.replyTo.type === 'image' ? '📷 Photo' : msg.replyTo.type === 'audio' ? '🎤 Voice message' : msg.replyTo.type === 'file' ? `📎 ${msg.replyTo.fileName}` : msg.replyTo.text}
                      </span>
                    </div>
                  )}
                  {/* Poll Message */}
                  {msg.type === 'poll' && msg.pollData && (
                    <div className="flex flex-col p-3 min-w-[220px]">
                      <div className="flex items-center gap-2 mb-3">
                        <BarChart2 className="w-5 h-5 text-blue-500" />
                        <span className="font-semibold text-[15px]">{msg.pollData.question}</span>
                      </div>
                      <div className="flex flex-col gap-2 mb-1">
                        {msg.pollData.options.map((opt, i) => (
                          <div key={i} className="flex flex-col gap-1">
                             <button className="flex items-center justify-between w-full bg-black/5 hover:bg-black/10 rounded-lg px-3 py-2 text-sm font-medium transition-colors text-left">
                               <span>{opt.text}</span>
                               <span className="text-[12px] opacity-60 font-normal">{opt.votes > 0 ? opt.votes : ''}</span>
                             </button>
                             {opt.votes > 0 && (
                               <div className="w-full bg-black/5 h-1.5 rounded-full overflow-hidden">
                                 <div className="bg-blue-500 h-full rounded-full" style={{ width: Math.min(100, opt.votes * 10) + '%' }} />
                               </div>
                             )}
                          </div>
                        ))}
                      </div>
                      <div className={cn("flex justify-end items-center mt-1", isMe ? "text-[#53b259]" : "text-gray-400")}>
                        <span className="text-[11px] font-medium leading-none tabular-nums mt-[2px]">{msg.time}</span>
                        <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} />
                      </div>
                    </div>
                  )}
                  
                  {/* Image Message */}
                  {msg.type === 'image' && (
                    <div className="flex flex-col p-1">
                      <div className="relative">
                        {(msg.mediaGroup && msg.mediaGroup.length > 1) ? (
                          <div className={cn("grid gap-0.5 rounded-[14px] overflow-hidden", msg.mediaGroup.length === 2 ? "grid-cols-2" : msg.mediaGroup.length >= 3 ? "grid-cols-2" : "grid-cols-2")}>
                            {msg.mediaGroup.map((item: any, i: number) => {
                              if (i > 3) return null; // only show up to 4
                              const isMore = msg.mediaGroup!.length > 4 && i === 3;
                              return (
                              <div key={i} 
                                onClick={(e) => {
                                   e.stopPropagation();
                                   if ((window as any)._tapTimer) {
                                      clearTimeout((window as any)._tapTimer);
                                      (window as any)._tapTimer = null;
                                      handleDoubleTap(msg);
                                   } else {
                                      (window as any)._tapTimer = setTimeout(() => {
                                         (window as any)._tapTimer = null;
                                         setMediaViewer({ msg, index: i });
                                      }, 250);
                                   }
                                }}
                                className={cn(
                                  "relative w-full cursor-pointer",
                                  msg.mediaGroup!.length === 3 && i === 0 ? "col-span-2 aspect-[2/1]" : "aspect-square"
                                )}>
                                {isMore && (
                                  <div className="absolute inset-0 z-20 bg-black/50 flex items-center justify-center text-white text-2xl font-semibold backdrop-blur-[2px]">
                                    +{msg.mediaGroup!.length - 4}
                                  </div>
                                )}
                                {item.type === 'video' ? (
                                  <div className="absolute inset-0 bg-black flex items-center justify-center">
                                    <video src={typeof item === 'string' ? item : item.url} className="absolute inset-0 w-full h-full object-cover opacity-80" />
                                    <Play className="w-8 h-8 text-white z-10" />
                                  </div>
                                ) : (
                                  <img src={typeof item === 'string' ? item : item.url} alt="attachment" className="absolute inset-0 w-full h-full object-cover select-none" draggable={false} />
                                )}
                              </div>
                            );
                            })}
                          </div>
                        ) : (
                          <div 
                             onClick={(e) => {
                                   e.stopPropagation();
                                   if ((window as any)._tapTimer) {
                                      clearTimeout((window as any)._tapTimer);
                                      (window as any)._tapTimer = null;
                                      handleDoubleTap(msg);
                                   } else {
                                      (window as any)._tapTimer = setTimeout(() => {
                                         (window as any)._tapTimer = null;
                                         setMediaViewer({ msg, index: 0 });
                                      }, 250);
                                   }
                             }}
                             className="relative rounded-[14px] overflow-hidden cursor-pointer">
                             {msg.mediaGroup && msg.mediaGroup[0] && typeof msg.mediaGroup[0] !== 'string' && (msg.mediaGroup[0] as any).type === 'video' ? (
                               <div className="absolute inset-0 bg-black flex items-center justify-center min-h-[200px]">
                                 <video src={(msg.mediaGroup[0] as any).url} className="absolute inset-0 w-full h-full object-cover opacity-80" />
                                 <Play className="w-8 h-8 text-white z-10" />
                               </div>
                             ) : (
                               <img src={msg.imageUrl} alt="attachment" className="max-h-[300px] w-full object-cover select-none" draggable={false} />
                             )}
                          </div>
                        )}
                        {!msg.text && (
                          <div className="absolute bottom-1.5 right-1.5 bg-black/40 backdrop-blur-md rounded-full px-1.5 py-[2px] flex items-center gap-0.5 text-white shadow-sm z-10">
                            <span className="text-[11px] leading-none font-medium tabular-nums mt-[1px]">{msg.time}</span>
                            <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} isImageOverlay={true} />
                          </div>
                        )}
                      </div>
                      {msg.text && (
                        <div className="px-2 pt-1 pb-1 relative min-w-[90px]">
                          <div className="text-[16px] leading-[1.35] break-words whitespace-pre-wrap" dir="auto">
                            {msg.text}
                            <span className={cn("float-right inline-flex items-center ml-2.5 mt-1.5 h-[15px] select-none", isMe ? "text-[#53b259]" : "text-gray-400")} dir="ltr">
                              <span className="text-[11px] font-medium leading-none tabular-nums mt-[2px]">{msg.time}</span>
                              <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} />
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Audio Message */}
                  {msg.type === 'audio' && (
                    <AudioMessage msg={msg as any} isMe={isMe} />
                  )}

                  {/* File Message */}
                  {msg.type === 'file' && (
                    <div className="px-3 pt-2.5 pb-1 relative min-w-[200px]">
                      <div className="flex items-center gap-3 mb-1">
                        <div className={cn("w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 text-white shadow-sm", isMe ? "bg-[#4FA953]" : "bg-blue-500")}>
                          <FileText className="w-[22px] h-[22px]" />
                        </div>
                        <div className="flex-1 flex flex-col justify-center min-w-0 pr-2">
                          <span className="text-[15px] font-medium truncate leading-tight">{msg.fileName}</span>
                          <span className="text-[13px] opacity-70 mt-0.5 font-medium">{msg.fileSize} • {msg.fileType}</span>
                        </div>
                      </div>
                      <div className={cn("flex justify-end items-center mt-[-4px]", isMe ? "text-[#53b259]" : "text-gray-400")}>
                        <span className="text-[11px] font-medium leading-none tabular-nums mt-[1px]">{msg.time}</span>
                        <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} />
                      </div>
                    </div>
                  )}

                  {/* Text Message */}
                  {(!msg.type || msg.type === 'text') && (
                    <div className="px-2.5 pt-1.5 pb-1 relative min-w-[90px]">
                      <div className="text-[16px] leading-[1.35] break-words whitespace-pre-wrap" dir="auto">
                        {msg.text}
                        <span className={cn("float-right inline-flex items-center ml-2.5 mt-1.5 h-[15px] select-none", isMe ? "text-[#53b259]" : "text-gray-400")} dir="ltr">
                          <span className="text-[11px] font-medium leading-none tabular-nums mt-[2px]">{msg.time}</span>
                          <MessageIndicators isMe={isMe} status={msg.readStatus} isRead={msg.isRead} isSaved={msg.isSaved} isPinned={msg.isPinned} />
                        </span>
                      </div>
                    </div>
                  )}



                  {/* Context Menu Tooltip */}
                  <AnimatePresence>
                    {isSelected && (
                      <motion.div
                        initial={{ opacity: 0, y: contextMenuPosition === 'top' ? 10 : -10, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        transition={{ type: 'spring', damping: 25, stiffness: 400 }}
                        className={cn(
                          "absolute w-52 bg-white/95 backdrop-blur-xl rounded-[20px] shadow-[0_16px_40px_rgba(0,0,0,0.15)] z-50 flex flex-col border border-white/60 overflow-hidden",
                          contextMenuPosition === 'top' ? "bottom-full mb-2" : "top-full mt-2",
                          isMe ? "right-0" : "left-0",
                          contextMenuPosition === 'top' ? (isMe ? "origin-bottom-right" : "origin-bottom-left") : (isMe ? "origin-top-right" : "origin-top-left")
                        )}
                        onClick={(e) => e.stopPropagation()}
                      >
                        {/* Dynamic Menu Content */}
                        <AnimatePresence mode="wait">
                            <motion.div
                              key="main-menu"
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -10 }}
                              transition={{ duration: 0.15 }}
                            >
                              {contextMenuPosition === 'bottom' && (
                                <div className="flex items-center justify-between px-3 py-1.5 bg-gray-50/50 border-b border-gray-100/50 rounded-t-[16px]">
                                  {['👍', '❤️', '😂', '😮', '😢'].map((emoji, i) => (
                                    <button key={i} className="text-[20px] hover:scale-125 hover:-translate-y-1 transition-transform origin-bottom" onClick={(e) => { e.stopPropagation(); handleReaction(msg.id, emoji); }}>
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                              <div className="flex flex-col p-1">
                                {[
                                  { icon: <CornerUpLeft className="w-[16px] h-[16px]" />, label: 'Reply', action: () => handleReply(msg) },
                                  { icon: <Copy className="w-[16px] h-[16px]" />, label: 'Copy', action: () => {
                                      if (msg.text) navigator.clipboard.writeText(msg.text);
                                      setSelectedMessageId(null);
                                  } },
                                  { icon: <Star className={cn("w-[16px] h-[16px]", msg.isSaved ? "fill-amber-400 text-amber-400" : "")} />, label: msg.isSaved ? 'Unfavorite' : 'Favorite', action: () => { setMessages(messages.map(m => m.id === msg.id ? { ...m, isSaved: !m.isSaved } : m)); setSelectedMessageId(null); } },
                                  { icon: <Pin className="w-[16px] h-[16px]" />, label: msg.isPinned ? 'Unpin' : 'Pin', action: () => { setMessages(messages.map(m => m.id === msg.id ? { ...m, isPinned: !m.isPinned } : m)); setSelectedMessageId(null); } },
                                  { icon: <Trash2 className="w-[16px] h-[16px]" />, label: 'Delete', isRemove: true, action: () => { setMessages(messages.filter(m => m.id !== msg.id)); setSelectedMessageId(null); } },
                                ].map((item: any, i) => (
                                  <button 
                                    key={i} 
                                    className={cn("w-full flex items-center px-3 py-2 rounded-[10px] transition-all gap-3", item.isRemove ? "text-red-500 hover:bg-red-50 hover:scale-[1.02] active:scale-95" : "hover:bg-gray-100/80")}
                                    onClick={(e) => { e.stopPropagation(); item.action(); }}
                                  >
                                    <div className={cn("text-gray-500", item.isRemove && "text-red-500")}>{item.icon}</div>
                                    <span className={cn("text-[14px] font-medium text-gray-700", item.isRemove && "text-red-500")}>{item.label}</span>
                                  </button>
                                ))}
                              </div>
                              {contextMenuPosition === 'top' && (
                                <div className="flex items-center justify-between px-3 py-1.5 bg-gray-50/50 border-t border-gray-100/50 rounded-b-[16px]">
                                  {['👍', '❤️', '😂', '😮', '😢'].map((emoji, i) => (
                                    <button key={i} className="text-[20px] hover:scale-125 hover:-translate-y-1 transition-transform origin-bottom" onClick={(e) => { e.stopPropagation(); handleReaction(msg.id, emoji); }}>
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </motion.div>
                        </AnimatePresence>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
                                  {msg.reactions && msg.reactions.length > 0 && (
                    <div className={cn("absolute -bottom-3 flex flex-wrap gap-1 z-30 px-2 pointer-events-none", isMe ? "right-0 justify-end" : "left-0 justify-start")}>
                      <AnimatePresence>
                      {msg.reactions.map((r, i) => (
                        <motion.button 
                           key={r.emoji}
                           layout
                           initial={{ scale: 0.3, opacity: 0, y: 15 }}
                           animate={{ scale: 1, opacity: 1, y: 0, transition: { type: 'spring', stiffness: 450, damping: 18, mass: 0.8 } }}
                           exit={{ scale: 0.6, opacity: 0, y: 10, transition: { duration: 0.15 } }}
                           whileTap={{ scale: 0.9 }}
                           onClick={(e) => { e.stopPropagation(); handleReaction(msg.id, r.emoji); }}
                           className={cn("pointer-events-auto px-1.5 py-[3px] rounded-full flex items-center gap-1 text-[12px] font-medium shadow-[0_2px_4px_rgba(0,0,0,0.12)] border backdrop-blur-md active:scale-95 hover:shadow-[0_4px_8px_rgba(0,0,0,0.1)] transition-all", r.userReacted ? (isMe ? "bg-[#dcedb9]/95 border-[#c5d8a0] text-green-800" : "bg-blue-100/95 border-blue-200 text-blue-800") : "bg-white/95 border-gray-200 text-gray-700")}
                        >
                           <motion.span 
                              key={r.count + (r.userReacted ? 'u' : 'n')}
                              initial={{ scale: 0.5 }}
                              animate={{ scale: 1 }}
                              transition={{ type: 'spring', stiffness: 500, damping: 12, mass: 0.5 }}
                              className="mt-[1px] inline-block origin-center"
                           >
                             {r.emoji}
                           </motion.span>
                           {r.count > 1 && <span className="text-[11px] font-semibold">{r.count}</span>}
                        </motion.button>
                      ))}
                      </AnimatePresence>
                    </div>
                  )}
              </motion.div>
            );
          })
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center opacity-50">
            <div className="w-24 h-24 bg-gray-300 rounded-full mb-4 flex items-center justify-center">
              <span className="text-4xl">👋</span>
            </div>
            <p className="text-gray-600 font-medium">Say hello to {chat.name}!</p>
          </div>
        )}
        
        {isTyping && (
          <motion.div 
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex justify-start z-10"
          >
            <div className="bg-white text-gray-900 shadow-[0_1px_2px_rgba(0,0,0,0.08)] rounded-[18px] rounded-tl-sm px-4 py-3 flex items-center gap-[4px]">
              <motion.div animate={{ y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0 }} className="w-1.5 h-1.5 bg-gray-400 rounded-full" />
              <motion.div animate={{ y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} className="w-1.5 h-1.5 bg-gray-400 rounded-full" />
              <motion.div animate={{ y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }} className="w-1.5 h-1.5 bg-gray-400 rounded-full" />
            </div>
          </motion.div>
        )}
        </AnimatePresence>
      </div>

      {/* Input Area */}
      <div className="bg-[#f0f2f5] shrink-0 relative z-20 pb-[env(safe-area-inset-bottom)] border-t border-black/5">
        {isBlocked ? (
          <div className="w-full flex flex-col items-center justify-center py-4 bg-[#f0f2f5]">
            <span className="text-[13px] text-gray-500 font-medium mb-1">You blocked this user.</span>
            <button 
              onClick={() => setIsBlocked(false)} 
              className="text-blue-500 hover:text-blue-600 font-semibold text-[15px] transition-colors uppercase tracking-wider"
            >
              Unblock User
            </button>
          </div>
        ) : (
        <div className="flex flex-col z-30 relative px-2 py-1.5">
          <div className="w-full">
            <AnimatePresence>
              
            </AnimatePresence>

            <AnimatePresence>
              {replyingTo && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mb-1.5 px-1"
                >
                  <div className="flex items-center gap-2 px-2 py-1.5 pl-3 relative bg-black/5 rounded-lg">
                    <div className="absolute left-0 top-1 bottom-1 w-[3px] bg-blue-500 rounded-full" />
                    <div className="flex-1 min-w-0 flex flex-col pl-1">
                      <span className="text-[14px] font-semibold text-blue-500 truncate leading-tight">
                        {replyingTo.senderId === 'me' ? 'You' : chat.name}
                      </span>
                      <span className="text-[14px] text-gray-600 truncate leading-tight mt-0.5">
                        {replyingTo.type === 'image' ? 'Photo' : replyingTo.type === 'file' ? replyingTo.fileName : replyingTo.type === 'audio' ? 'Voice message' : replyingTo.type === 'sticker' ? 'Sticker' : replyingTo.text}
                      </span>
                    </div>
                    {replyingTo.type === 'image' && (
                      <img src={replyingTo.imageUrl} alt="preview" className="w-9 h-9 rounded object-cover shrink-0 ml-1 shadow-sm" />
                    )}
                    <button 
                      onClick={() => setReplyingTo(null)}
                      className="p-1 text-gray-400 hover:text-gray-600 rounded-full transition-colors self-center ml-1"
                    >
                      <X className="w-[20px] h-[20px]" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          
          <MessageInput 
            selectedFiles={selectedFiles}
            setSelectedFiles={setSelectedFiles}
            onSendText={handleSendText}
            onSendAudio={handleSendAudio}
            onSendMedia={handleSendMedia}
            onAttachmentClick={() => setIsAttachmentOpen(true)}
          />
        </div>
        )}
      </div>

      <AnimatePresence>
        
        {showGallery && <motion.div key="gallery-bg" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}  onClick={() => setShowGallery(false)} className="absolute inset-0 z-[55] bg-black/90 backdrop-blur-sm"  />}
        {showGallery && (
            <motion.div key="gallery-modal" initial={{ y: '100%' }}  animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 26, stiffness: 300, mass: 0.8 }} className="absolute inset-x-0 bottom-0 top-20 z-[60] bg-white rounded-t-[24px] flex flex-col overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b">
                <h3 className="font-semibold text-lg">Media Gallery</h3>
                <button onClick={() => setShowGallery(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 grid grid-cols-3 gap-2">
                {messages.filter(m => m.type === 'image' || m.type === 'file').map(m => (
                  <div key={m.id} className="aspect-square bg-gray-100 rounded-lg overflow-hidden relative">
                    {m.type === 'image' && <img src={m.imageUrl || m.imageUrl} className="w-full h-full object-cover" />}
                    {m.type === 'file' && <div className="absolute inset-0 flex items-center justify-center"><Play className="w-8 h-8 text-white drop-shadow-md" /></div>}
                  </div>
                ))}
                {messages.filter(m => m.type === 'image' || m.type === 'file').length === 0 && (
                  <div className="col-span-3 text-center text-gray-500 py-10">No media shared yet</div>
                )}
              </div>
            </motion.div>
        )}
      </AnimatePresence>

        {showDocuments && <motion.div key="docs-bg" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}  onClick={() => setShowDocuments(false)} className="absolute inset-0 z-[55] bg-black/40 backdrop-blur-sm"  />}
        {showDocuments && (
            <motion.div key="docs-modal" initial={{ y: '100%' }}  animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 26, stiffness: 300, mass: 0.8 }} className="absolute inset-x-0 bottom-0 top-20 z-[60] bg-white rounded-t-[24px] flex flex-col overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b">
                <h3 className="font-semibold text-lg">Shared Files</h3>
                <button onClick={() => setShowDocuments(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
                {messages.filter(m => m.type === 'file').map(m => (
                  <div key={m.id} className="flex items-center p-3 border rounded-xl hover:bg-gray-50">
                    <div className="w-10 h-10 bg-blue-100 text-blue-500 rounded-lg flex items-center justify-center mr-3">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{m.fileName || 'Document'}</div>
                      <div className="text-sm text-gray-500">{m.fileSize || 'Unknown size'}</div>
                    </div>
                    <button className="p-2 text-gray-400 hover:text-blue-500"><Download className="w-5 h-5" /></button>
                  </div>
                ))}
                {messages.filter(m => m.type === 'file').length === 0 && (
                  <div className="text-center text-gray-500 py-10">No documents shared yet</div>
                )}
              </div>
            </motion.div>
        )}

        {showClearConfirm && (
            <motion.div key="clear-bg" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}  onClick={() => setShowClearConfirm(false)} className="absolute inset-0 z-[65] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
              <motion.div initial={{ scale: 0.95, opacity: 0 }}  animate={{ scale: 1, opacity: 1, transition: { type: "spring", stiffness: 500, damping: 15 } }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-2">Clear Chat History?</h3>
                <p className="text-gray-600 mb-6">Are you sure you want to delete all messages in this chat? This cannot be undone.</p>
                <div className="flex justify-end gap-2">
                  <button onClick={() => setShowClearConfirm(false)} className="px-4 py-2 font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">Cancel</button>
                  <button onClick={() => { setMessages([]); setShowClearConfirm(false); }} className="px-4 py-2 font-medium text-white bg-red-500 hover:bg-red-600 rounded-lg transition-colors">Clear Chat</button>
                </div>
              </motion.div>
            </motion.div>
        )}

        {showBlockConfirm && <motion.div key="block-bg" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}  onClick={() => setShowBlockConfirm(false)} className="absolute inset-0 z-[65] bg-black/50 backdrop-blur-sm"  />}
        {showBlockConfirm && (
            <motion.div key="block-modal" initial={{ y: '100%' }}  animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 26, stiffness: 300, mass: 0.8 }} className="absolute bottom-0 left-0 right-0 z-[70] bg-white rounded-t-[24px] pb-8 pt-4 px-4 flex flex-col items-center">
              <div className="w-12 h-1.5 bg-gray-300 rounded-full mb-6" />
              <div className="w-full flex flex-col gap-2">
                <button onClick={() => { setIsBlocked(true); setShowBlockConfirm(false); }} className="w-full py-4 text-lg font-semibold text-red-500 bg-gray-50 hover:bg-red-50 rounded-xl transition-colors">Block User</button>
                <button onClick={() => setShowBlockConfirm(false)} className="w-full py-4 text-lg font-semibold text-gray-900 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors">Report User</button>
                <button onClick={() => setShowBlockConfirm(false)} className="w-full py-4 text-lg font-semibold text-gray-900 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors">Restrict User</button>
                <button onClick={() => setShowBlockConfirm(false)} className="w-full py-4 text-lg font-semibold text-gray-500 mt-2">Cancel</button>
              </div>
            </motion.div>
        )}

        

      

      
      <AttachmentMenu 
        isOpen={isAttachmentOpen} 
        onClose={() => setIsAttachmentOpen(false)} 
        onSelect={(type) => {
          setIsAttachmentOpen(false);
          if (type === 'camera') cameraInputRef.current?.click();
          if (type === 'gallery') galleryInputRef.current?.click();
          if (type === 'video') videoInputRef.current?.click();
          if (type === 'document') documentInputRef.current?.click();
          if (type === 'audio') audioInputRef.current?.click();
          if (type === 'location') handleLocation();
          if (type === 'contact') handleContact();
          if (type === 'poll') handlePoll();
          if (type === 'gif') handleGif();
          if (type === 'sticker') handleSticker();
        }} 
      />

      <AnimatePresence>
        {mediaViewer && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black flex flex-col touch-none"
          >
            <div className="flex items-center justify-between p-4 bg-gradient-to-b from-black/50 to-transparent absolute top-0 inset-x-0 z-10">
              <button onClick={() => setMediaViewer(null)} className="p-2 text-white/80 hover:text-white bg-black/20 rounded-full backdrop-blur-md">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div className="text-white font-medium">
                 {mediaViewer.msg.mediaGroup ? `${mediaViewer.index + 1} of ${mediaViewer.msg.mediaGroup.length}` : '1 of 1'}
              </div>
              <button className="p-2 text-white/80 hover:text-white bg-black/20 rounded-full backdrop-blur-md">
                <MoreVertical className="w-6 h-6" />
              </button>
            </div>
            
            <div className="flex-1 relative flex items-center justify-center overflow-hidden"
              onClick={() => setMediaViewer(null)}
            >
              <motion.div
                key={mediaViewer.index}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                className="relative w-full h-full flex items-center justify-center"
                onClick={(e) => e.stopPropagation()}
              >
                {(() => {
                  const item = mediaViewer.msg.mediaGroup ? mediaViewer.msg.mediaGroup[mediaViewer.index] : mediaViewer.msg.imageUrl;
                  const isVideo = item && typeof item !== 'string' && (item as any).type === 'video';
                  const url = typeof item === 'string' ? item : (item as any)?.url || mediaViewer.msg.imageUrl;
                  
                  if (isVideo) {
                     return <video src={url} controls autoPlay className="max-w-full max-h-full object-contain" />;
                  }
                  return <img src={url} alt="fullscreen media" className="max-w-full max-h-full object-contain" />;
                })()}
              </motion.div>
              
              {mediaViewer.msg.mediaGroup && mediaViewer.msg.mediaGroup.length > 1 && (
                <>
                  <button 
                    onClick={(e) => { e.stopPropagation(); setMediaViewer(prev => prev && prev.index > 0 ? { ...prev, index: prev.index - 1 } : prev); }}
                    className={cn("absolute left-4 p-3 rounded-full bg-black/30 backdrop-blur-md text-white transition-opacity", mediaViewer.index === 0 ? "opacity-0 pointer-events-none" : "opacity-100 hover:bg-black/50")}
                  >
                    <ArrowLeft className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); setMediaViewer(prev => prev && prev.msg.mediaGroup && prev.index < prev.msg.mediaGroup.length - 1 ? { ...prev, index: prev.index + 1 } : prev); }}
                    className={cn("absolute right-4 p-3 rounded-full bg-black/30 backdrop-blur-md text-white transition-opacity", mediaViewer.msg.mediaGroup && mediaViewer.index === mediaViewer.msg.mediaGroup.length - 1 ? "opacity-0 pointer-events-none" : "opacity-100 hover:bg-black/50")}
                  >
                    <ArrowLeft className="w-6 h-6 rotate-180" />
                  </button>
                </>
              )}
            </div>
            
            <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/60 to-transparent flex flex-col gap-4">
              {mediaViewer.msg.text && (
                <div className="text-white text-[15px] max-h-[100px] overflow-y-auto">
                  {mediaViewer.msg.text}
                </div>
              )}
              <div className="flex gap-4">
                {['👍', '❤️', '😂', '😮', '😢'].map((emoji, i) => {
                   const r = (mediaViewer.msg.reactions || []).find(x => x.emoji === emoji);
                   const hasReacted = r?.userReacted;
                   return (
                      <button 
                         key={i} 
                         onClick={() => handleReaction(mediaViewer.msg.id, emoji)}
                         className={cn(
                           "flex items-center gap-1.5 px-3 py-1.5 rounded-full backdrop-blur-md transition-colors",
                           hasReacted ? "bg-white/20 text-white" : "bg-black/20 text-white/70 hover:bg-black/40 hover:text-white"
                         )}
                      >
                         <span className="text-[18px]">{emoji}</span>
                         {r && r.count > 0 && <span className="text-[13px] font-medium">{r.count}</span>}
                      </button>
                   );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hidden File Inputs */}
      <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} />
      <input type="file" ref={galleryInputRef} accept="image/*,video/*" multiple className="hidden" onChange={handleFileChange} />
      <input type="file" ref={cameraInputRef} accept="image/*,video/*" capture="environment" className="hidden" onChange={handleFileChange} />
      <input type="file" ref={videoInputRef} accept="video/*" multiple className="hidden" onChange={handleFileChange} />
      <input type="file" ref={audioInputRef} accept="audio/*" className="hidden" onChange={handleFileChange} />
      <input type="file" ref={documentInputRef} accept=".pdf,.doc,.docx,.txt,.rtf,.xls,.xlsx" multiple className="hidden" onChange={handleFileChange} />
    </motion.div>
  );
};
