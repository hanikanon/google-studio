import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import LoginScreen from './pages/LoginScreen';
import SplashScreen from './components/SplashScreen';
import ChatApp from './ChatApp';

type Phase = 'splash' | 'login' | 'app';

export default function App() {
  const [phase, setPhase] = useState<Phase>('splash');

  return (
    <div className="w-full h-[100dvh] bg-white text-gray-900 overflow-hidden antialiased selection:bg-blue-500/30 font-sans relative">
      <AnimatePresence mode="wait">
        {phase === 'splash' ? (
          <SplashScreen key="splash" onComplete={() => setPhase('login')} />
        ) : phase === 'login' ? (
          <LoginScreen key="login" onLogin={() => setPhase('app')} />
        ) : (
          <motion.div
            key="app"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="w-full h-full"
          >
            <ChatApp />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
