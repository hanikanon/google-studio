import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import GoogleButton from '../components/GoogleButton';
import AnimatedTitle from '../components/AnimatedTitle';
import TradingBackground from '../components/TradingBackground';
import { signInWithGoogle } from '../firebase/auth';
import { WifiOff, X } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [introFinished, setIntroFinished] = useState(false);
  const [showError, setShowError] = useState(false);

  // Automatically clear error when connection is restored
  useEffect(() => {
    const handleOnline = () => setShowError(false);
    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, []);

  const handleLogin = async () => {
    // Check if offline
    if (!navigator.onLine) {
      setShowError(true);
      return;
    }

    try {
      const success = await signInWithGoogle();
      if (success) {
        onLogin();
      } else {
        setShowError(true);
      }
    } catch (e) {
      setShowError(true);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.5 }}
      className="relative w-full h-full flex flex-col items-center justify-center px-6 py-12 text-center bg-white overflow-hidden"
    >
      <TradingBackground />

      {/* Main Content Area */}
      <motion.div layout className="relative flex flex-col items-center w-full max-w-sm z-10">
        <motion.div layout className="mb-6">
          <AnimatedTitle onAnimationComplete={() => setIntroFinished(true)} />
        </motion.div>
        
        <AnimatePresence>
          {introFinished && (
            <motion.div
              initial={{ opacity: 0, y: 20, filter: 'blur(10px)', height: 0 }}
              animate={{ opacity: 1, y: 0, filter: 'blur(0px)', height: 'auto' }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="w-full flex flex-col items-center space-y-10 overflow-hidden"
            >
              {/* Copy */}
              <div className="space-y-4 px-2 pt-2">
                <h2 className="text-[22px] font-display font-semibold tracking-tight text-gray-900 leading-tight">
                  Professional Trading Community
                </h2>
                <p className="text-gray-500 text-[15px] font-medium tracking-wide leading-relaxed max-w-[300px] mx-auto">
                  Connect with traders, discover market insights, share strategies and grow together.
                </p>
              </div>

              {/* Actions */}
              <div className="w-full space-y-6 pb-2">
                <GoogleButton onClick={handleLogin} />
                
                <p className="text-[12px] font-medium text-gray-400 max-w-[240px] mx-auto leading-relaxed">
                  We only use your Google account for secure authentication.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Network Error Toast Overlay */}
      <AnimatePresence>
        {showError && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 25 }}
            className="absolute bottom-10 left-0 right-0 mx-auto w-[90%] max-w-sm z-50 flex items-center justify-between p-4 bg-gray-900/90 backdrop-blur-xl rounded-2xl shadow-[0_12px_40px_-12px_rgba(0,0,0,0.4)] border border-white/10"
          >
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center w-10 h-10 bg-red-500/10 rounded-full shrink-0">
                <WifiOff className="w-5 h-5 text-red-400" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[15px] font-semibold text-white tracking-tight leading-tight">No Internet Connection</span>
                <span className="text-[13px] font-medium text-gray-400 mt-0.5 leading-tight">Please check your network settings.</span>
              </div>
            </div>
            <button 
              onClick={() => setShowError(false)}
              className="p-2 text-gray-400 hover:text-white transition-colors shrink-0"
              aria-label="Dismiss"
            >
              <X className="w-5 h-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
