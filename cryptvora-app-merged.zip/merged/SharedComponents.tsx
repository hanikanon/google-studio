import React, { useState } from 'react';

export const PinkBadgeIcon = ({ className = "w-[11px] h-[11px] text-white" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
    <circle cx="8" cy="12" r="5" />
    <circle cx="16" cy="12" r="5" />
  </svg>
);

export const OwlLogo = ({ className = "w-8 h-8 text-white mt-1" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M12 2C8 2 5 5 5 9C5 10.5 5.5 11.9 6.4 13L5 20L9.5 18C10.3 18.2 11.1 18.3 12 18.3C12.9 18.3 13.7 18.2 14.5 18L19 20L17.6 13C18.5 11.9 19 10.5 19 9C19 5 16 2 12 2ZM9 10C8.4 10 8 9.6 8 9C8 8.4 8.4 8 9 8C9.6 8 10 8.4 10 9C10 9.6 9.6 10 9 10ZM15 10C14.4 10 14 9.6 14 9C14 8.4 14.4 8 15 8C15.6 8 16 8.4 16 9C16 9.6 15.6 10 15 10Z" />
  </svg>
);

export const ReadMoreText = ({ text, maxLength = 120, className = "" }: { text: string; maxLength?: number; className?: string }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  if (text.length <= maxLength) {
    return <div className={`${className} whitespace-pre-wrap`}>{text}</div>;
  }
  
  return (
    <div className={`${className} whitespace-pre-wrap`}>
      {isExpanded ? text : `${text.slice(0, maxLength).trim()}...`}
      <button 
        onClick={(e) => {
          e.stopPropagation();
          setIsExpanded(!isExpanded);
        }}
        className="text-gray-500 font-semibold ml-1 hover:text-gray-700 transition-colors"
      >
        {isExpanded ? 'less' : 'more'}
      </button>
    </div>
  );
};
