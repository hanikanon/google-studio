const fs = require('fs');

let content = fs.readFileSync('src/components/ContextMenu.tsx', 'utf-8');

// Add import
content = content.replace("import { cn } from '../utils';", "import { cn } from '../utils';\nimport { usePopupManager } from '../usePopupManager';");

// Add hook inside component
content = content.replace(
  "const [view, setView] = useState<'main' | 'more'>('main');",
  "const [view, setView] = useState<'main' | 'more'>('main');\n  usePopupManager(isOpen, onClose);"
);

// Fix backdrop
content = content.replace(
  'className="fixed inset-0 bg-black/15 backdrop-blur-[2px] z-40 touch-none"',
  'className="fixed inset-0 w-screen h-screen bg-black/15 backdrop-blur-[2px] z-40 cursor-default touch-none"'
);

fs.writeFileSync('src/components/ContextMenu.tsx', content);
