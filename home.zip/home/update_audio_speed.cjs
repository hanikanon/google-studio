const fs = require('fs');
let content = fs.readFileSync('src/components/AudioMessage.tsx', 'utf-8');

// Add playbackRate state
content = content.replace("  const [currentTime, setCurrentTime] = useState('0:00');", "  const [currentTime, setCurrentTime] = useState('0:00');\n  const [playbackRate, setPlaybackRate] = useState(1);");

// Update playbackRate when it changes
content = content.replace("    audio.addEventListener('ended', handleEnded);", "    audio.addEventListener('ended', handleEnded);\n    audio.playbackRate = playbackRate;");
content = content.replace("  useEffect(() => {", "  useEffect(() => {\n    if (audioRef.current) {\n      audioRef.current.playbackRate = playbackRate;\n    }\n  }, [playbackRate]);\n\n  useEffect(() => {");

// Add toggle speed function
const toggleSpeedStr = `
  const toggleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPlaybackRate(prev => {
      if (prev === 1) return 1.5;
      if (prev === 1.5) return 2;
      return 1;
    });
  };
`;
content = content.replace("  const handleSeek = (e: React.PointerEvent) => {", toggleSpeedStr + "\n  const handleSeek = (e: React.PointerEvent) => {");

// Add speed button to UI
const oldTime = `<span className={cn(
              "text-[12px] font-medium tracking-wide",
              isMe ? "text-[#4FA953]" : "text-gray-500"
            )}>
              {isPlaying ? currentTime : (msg.audioDuration || '0:00')}
            </span>`;

const newTime = `<div className="flex items-center gap-2">
              <span className={cn(
                "text-[12px] font-medium tracking-wide",
                isMe ? "text-[#4FA953]" : "text-gray-500"
              )}>
                {isPlaying ? currentTime : (msg.audioDuration || '0:00')}
              </span>
              {isPlaying && (
                <button 
                  onClick={toggleSpeed}
                  className={cn(
                    "text-[10px] font-bold px-1.5 py-0.5 rounded-full transition-colors",
                    isMe ? "bg-[#4FA953]/20 text-[#4FA953] hover:bg-[#4FA953]/30" : "bg-blue-100 text-blue-600 hover:bg-blue-200"
                  )}
                >
                  {playbackRate}x
                </button>
              )}
            </div>`;

content = content.replace(oldTime, newTime);

fs.writeFileSync('src/components/AudioMessage.tsx', content);

