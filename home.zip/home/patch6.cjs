const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

const modals = `
        {showGallery && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowGallery(false)} className="absolute inset-0 z-[55] bg-black/90 backdrop-blur-sm" />
            <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 26, stiffness: 300, mass: 0.8 }} className="absolute inset-x-0 bottom-0 top-20 z-[60] bg-white rounded-t-[24px] flex flex-col overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b">
                <h3 className="font-semibold text-lg">Media Gallery</h3>
                <button onClick={() => setShowGallery(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 grid grid-cols-3 gap-2">
                {messages.filter(m => m.type === 'image' || m.type === 'video').map(m => (
                  <div key={m.id} className="aspect-square bg-gray-100 rounded-lg overflow-hidden relative">
                    {m.type === 'image' && <img src={m.imageUrl || m.image} className="w-full h-full object-cover" />}
                    {m.type === 'video' && <div className="absolute inset-0 flex items-center justify-center"><Play className="w-8 h-8 text-white drop-shadow-md" /></div>}
                  </div>
                ))}
                {messages.filter(m => m.type === 'image' || m.type === 'video').length === 0 && (
                  <div className="col-span-3 text-center text-gray-500 py-10">No media shared yet</div>
                )}
              </div>
            </motion.div>
          </>
        )}

        {showDocuments && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowDocuments(false)} className="absolute inset-0 z-[55] bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 26, stiffness: 300, mass: 0.8 }} className="absolute inset-x-0 bottom-0 top-20 z-[60] bg-white rounded-t-[24px] flex flex-col overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b">
                <h3 className="font-semibold text-lg">Shared Files</h3>
                <button onClick={() => setShowDocuments(false)} className="p-2 hover:bg-gray-100 rounded-full"><X className="w-5 h-5" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
                {messages.filter(m => m.type === 'document' || (m.type === 'file' && m.fileName)).map(m => (
                  <div key={m.id} className="flex items-center p-3 border rounded-xl hover:bg-gray-50">
                    <div className="w-10 h-10 bg-blue-100 text-blue-500 rounded-lg flex items-center justify-center mr-3">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{m.fileName || 'Document'}</div>
                      <div className="text-sm text-gray-500">{m.fileSize || 'Unknown size'}</div>
                    </div>
                    <button className="p-2 text-gray-400 hover:text-blue-500"><Download className="w-5 h-5" /></button>
                  </div>
                ))}
                {messages.filter(m => m.type === 'document' || (m.type === 'file' && m.fileName)).length === 0 && (
                  <div className="text-center text-gray-500 py-10">No documents shared yet</div>
                )}
              </div>
            </motion.div>
          </>
        )}

        {showClearConfirm && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowClearConfirm(false)} className="absolute inset-0 z-[65] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
              <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold mb-2">Clear Chat History?</h3>
                <p className="text-gray-600 mb-6">Are you sure you want to delete all messages in this chat? This cannot be undone.</p>
                <div className="flex justify-end gap-2">
                  <button onClick={() => setShowClearConfirm(false)} className="px-4 py-2 font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">Cancel</button>
                  <button onClick={() => { setMessages([]); setShowClearConfirm(false); }} className="px-4 py-2 font-medium text-white bg-red-500 hover:bg-red-600 rounded-lg transition-colors">Clear Chat</button>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}

        {showBlockConfirm && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowBlockConfirm(false)} className="absolute inset-0 z-[65] bg-black/50 backdrop-blur-sm" />
            <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 26, stiffness: 300, mass: 0.8 }} className="absolute bottom-0 left-0 right-0 z-[70] bg-white rounded-t-[24px] pb-8 pt-4 px-4 flex flex-col items-center">
              <div className="w-12 h-1.5 bg-gray-300 rounded-full mb-6" />
              <div className="w-full flex flex-col gap-2">
                <button onClick={() => { setIsBlocked(true); setShowBlockConfirm(false); }} className="w-full py-4 text-lg font-semibold text-red-500 bg-gray-50 hover:bg-red-50 rounded-xl transition-colors">Block User</button>
                <button onClick={() => setShowBlockConfirm(false)} className="w-full py-4 text-lg font-semibold text-gray-900 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors">Report User</button>
                <button onClick={() => setShowBlockConfirm(false)} className="w-full py-4 text-lg font-semibold text-gray-900 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors">Restrict User</button>
                <button onClick={() => setShowBlockConfirm(false)} className="w-full py-4 text-lg font-semibold text-gray-500 mt-2">Cancel</button>
              </div>
            </motion.div>
          </>
        )}
`;

c = c.replace(
  '{isAttachmentOpen && (',
  modals + '\n        {isAttachmentOpen && ('
);

fs.writeFileSync('src/components/MessagesPage.tsx', c);
