const fs = require('fs');
let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

const oldFunc = `  const handlePointerDown = (msgId: string, event: React.PointerEvent<HTMLDivElement>) => {
    pointerStartRef.current = { x: event.clientX, y: event.clientY };
    const rect = event.currentTarget.getBoundingClientRect();
    const windowHeight = window.innerHeight;
    const isNearBottom = rect.bottom > windowHeight / 2;
    
    longPressTimer.current = setTimeout(() => {
      setSelectedMessageId(msgId);
      setIsMoreMenuOpen(false); 
      setContextMenuPosition(isNearBottom ? 'top' : 'bottom');
      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
    }, 350);
  };`;

const newFunc = `  const handlePointerDown = (msgId: string, event: React.PointerEvent<HTMLDivElement>) => {
    pointerStartRef.current = { x: event.clientX, y: event.clientY };
    const currentTarget = event.currentTarget;
    
    longPressTimer.current = setTimeout(() => {
      const rect = currentTarget.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      
      const spaceAbove = rect.top - 60; // 60px approx header
      const spaceBelow = windowHeight - rect.bottom - 70; // 70px approx input
      
      const menuHeight = 350; // Approximated max height of context menu

      let position: 'top' | 'bottom' = 'top';

      if (spaceAbove >= menuHeight) {
        position = 'top';
      } else if (spaceBelow >= menuHeight) {
        position = 'bottom';
      } else {
        // If neither has enough space, pick the one with the most space
        position = spaceAbove > spaceBelow ? 'top' : 'bottom';
      }
      
      setSelectedMessageId(msgId);
      setIsMoreMenuOpen(false); 
      setContextMenuPosition(position);

      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
      
      // Auto-scroll to ensure message and menu are fully visible
      setTimeout(() => {
        const padding = 20;
        if (position === 'top' && spaceAbove < menuHeight) {
          const scrollAmount = menuHeight - spaceAbove + padding;
          scrollRef.current?.scrollBy({ top: -scrollAmount, behavior: 'smooth' });
        } else if (position === 'bottom' && spaceBelow < menuHeight) {
          const scrollAmount = menuHeight - spaceBelow + padding;
          scrollRef.current?.scrollBy({ top: scrollAmount, behavior: 'smooth' });
        }
      }, 50);

    }, 350);
  };`;

content = content.replace(oldFunc, newFunc);
fs.writeFileSync('src/components/MessagesPage.tsx', content);
