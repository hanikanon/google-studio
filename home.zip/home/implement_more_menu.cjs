const fs = require('fs');

let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

const oldMoreMenuCondition = `
                          {!isMoreMenuOpen ? (
                            <>
                              {contextMenuPosition === 'bottom' && (
                                <div className="flex items-center justify-between px-3 py-1.5 bg-gray-50/50 border-b border-gray-100/50 rounded-t-[16px]">
                                  {['👍', '❤️', '😂', '😮', '😢'].map((emoji, i) => (
                                    <button key={i} className="text-[20px] hover:scale-125 hover:-translate-y-1 transition-transform origin-bottom" onClick={() => setSelectedMessageId(null)}>
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                              <div className="flex flex-col p-1">
                                {[
                                  { icon: <CornerUpLeft className="w-[16px] h-[16px]" />, label: 'Reply', action: () => handleReply(msg) },
                                  { icon: <Copy className="w-[16px] h-[16px]" />, label: 'Copy', action: () => setSelectedMessageId(null) },
                                  { icon: <Share2 className="w-[16px] h-[16px]" />, label: 'Forward', action: () => setSelectedMessageId(null) },
                                  { icon: <MoreVertical className="w-[16px] h-[16px]" />, label: 'More', action: () => setIsMoreMenuOpen(true) },
                                ].map((item, i) => (
                                  <button 
                                    key={i} 
                                    className="w-full flex items-center px-3 py-2 rounded-[10px] hover:bg-gray-100/80 transition-colors gap-3"
                                    onClick={item.action}
                                  >
                                    <div className={item.textRed ? "text-red-500" : "text-gray-700"}>{item.icon}</div>
                                    <span className={cn("text-[14px] font-medium", item.textRed ? "text-red-500" : "text-gray-900")}>{item.label}</span>
                                  </button>
                                ))}
                              </div>

                              {contextMenuPosition === 'top' && (
                                <div className="flex items-center justify-between px-3 py-1.5 bg-gray-50/50 border-t border-gray-100/50 rounded-b-[16px]">
                                  {['👍', '❤️', '😂', '😮', '😢'].map((emoji, i) => (
                                    <button key={i} className="text-[20px] hover:scale-125 hover:-translate-y-1 transition-transform origin-bottom" onClick={() => setSelectedMessageId(null)}>
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="flex flex-col p-1">
                              {[
                                { icon: <Edit2 className="w-[16px] h-[16px]" />, label: 'Edit' },
                                { icon: <Trash2 className="w-[16px] h-[16px]" />, label: 'Delete', textRed: true },
                                { icon: <X className="w-[16px] h-[16px]" />, label: 'Cancel', action: () => setIsMoreMenuOpen(false) },
                              ].map((item, i) => (
                                <button 
                                  key={i} 
                                  className="w-full flex items-center px-3 py-2 rounded-[10px] hover:bg-gray-100/80 transition-colors gap-3"
                                  onClick={item.action || (() => setSelectedMessageId(null))}
                                >
                                  <div className={item.textRed ? "text-red-500" : "text-gray-700"}>{item.icon}</div>
                                  <span className={cn("text-[14px] font-medium", item.textRed ? "text-red-500" : "text-gray-900")}>{item.label}</span>
                                </button>
                              ))}
                            </div>
                          )}`;

const newMoreMenuCondition = `
                          {!isMoreMenuOpen ? (
                            <>
                              {contextMenuPosition === 'bottom' && (
                                <div className="flex items-center justify-between px-3 py-1.5 bg-gray-50/50 border-b border-gray-100/50 rounded-t-[16px]">
                                  {['👍', '❤️', '😂', '😮', '😢'].map((emoji, i) => (
                                    <button key={i} className="text-[20px] hover:scale-125 hover:-translate-y-1 transition-transform origin-bottom" onClick={() => setSelectedMessageId(null)}>
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                              <div className="flex flex-col p-1">
                                {[
                                  { icon: <CornerUpLeft className="w-[16px] h-[16px]" />, label: 'Reply', action: () => handleReply(msg) },
                                  { icon: <Copy className="w-[16px] h-[16px]" />, label: 'Copy', action: () => {
                                      if (msg.text) navigator.clipboard.writeText(msg.text);
                                      setSelectedMessageId(null);
                                  } },
                                  { icon: <Share2 className="w-[16px] h-[16px]" />, label: 'Forward', action: () => setSelectedMessageId(null) },
                                  { icon: <MoreVertical className="w-[16px] h-[16px]" />, label: 'More', action: () => setIsMoreMenuOpen(true) },
                                ].map((item, i) => (
                                  <button 
                                    key={i} 
                                    className="w-full flex items-center px-3 py-2 rounded-[10px] hover:bg-gray-100/80 transition-colors gap-3"
                                    onClick={item.action}
                                  >
                                    <div className={item.textRed ? "text-red-500" : "text-gray-700"}>{item.icon}</div>
                                    <span className={cn("text-[14px] font-medium", item.textRed ? "text-red-500" : "text-gray-900")}>{item.label}</span>
                                  </button>
                                ))}
                              </div>

                              {contextMenuPosition === 'top' && (
                                <div className="flex items-center justify-between px-3 py-1.5 bg-gray-50/50 border-t border-gray-100/50 rounded-b-[16px]">
                                  {['👍', '❤️', '😂', '😮', '😢'].map((emoji, i) => (
                                    <button key={i} className="text-[20px] hover:scale-125 hover:-translate-y-1 transition-transform origin-bottom" onClick={() => setSelectedMessageId(null)}>
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="flex flex-col p-1 max-h-[300px] overflow-y-auto">
                              {[
                                ...(isMe ? [{ icon: <Edit2 className="w-[16px] h-[16px]" />, label: 'Edit' }] : []),
                                { icon: <Check className="w-[16px] h-[16px]" />, label: 'Select' },
                                { icon: <Download className="w-[16px] h-[16px]" />, label: 'Save to Downloads' },
                                { icon: <ImageIcon className="w-[16px] h-[16px]" />, label: 'Save to Gallery' },
                                { icon: <Share2 className="w-[16px] h-[16px]" />, label: 'Share' },
                                { icon: <Copy className="w-[16px] h-[16px]" />, label: 'Copy Link' },
                                { icon: <FileText className="w-[16px] h-[16px]" />, label: 'View Info' },
                                { icon: <Pin className="w-[16px] h-[16px]" />, label: 'Pin Message' },
                                { icon: <Flag className="w-[16px] h-[16px]" />, label: 'Translate' },
                                { icon: <Bookmark className="w-[16px] h-[16px]" />, label: 'Add to Favorites' },
                                ...(!isMe ? [{ icon: <Flag className="w-[16px] h-[16px] text-red-500" />, label: 'Report', textRed: true }] : []),
                                { icon: <Trash2 className="w-[16px] h-[16px] text-red-500" />, label: 'Delete', textRed: true },
                                { divider: true },
                                { icon: <X className="w-[16px] h-[16px]" />, label: 'Back', action: () => setIsMoreMenuOpen(false) },
                              ].map((item, i) => 
                                item.divider ? (
                                  <div key={i} className="h-px bg-gray-100/80 my-1 mx-2" />
                                ) : (
                                  <button 
                                    key={i} 
                                    className="w-full flex items-center px-3 py-2 rounded-[10px] hover:bg-gray-100/80 transition-colors gap-3"
                                    onClick={item.action || (() => {
                                        if (item.label === 'Delete') {
                                            setMessages(prev => prev.filter(m => m.id !== msg.id));
                                        }
                                        setSelectedMessageId(null);
                                    })}
                                  >
                                    <div className={item.textRed ? "text-red-500" : "text-gray-700"}>{item.icon}</div>
                                    <span className={cn("text-[14px] font-medium", item.textRed ? "text-red-500" : "text-gray-900")}>{item.label}</span>
                                  </button>
                                )
                              )}
                            </div>
                          )}`;

if (content.includes(oldMoreMenuCondition)) {
    content = content.replace(oldMoreMenuCondition, newMoreMenuCondition);
    fs.writeFileSync('src/components/MessagesPage.tsx', content);
    console.log("Success: Replaced More menu perfectly.");
} else {
    console.log("Failed to find exact block. Let's try with a regex.");
    // Fallback: Use substring
    const p1 = `{!isMoreMenuOpen ? (`;
    const p2 = `                          )}`;
    const idx1 = content.indexOf(p1);
    if (idx1 !== -1) {
        const remaining = content.substring(idx1);
        const end = remaining.indexOf(')', remaining.indexOf('<Trash2')) + 150; // find the end of the block
        // It's tricky to replace manually. I'll just write a script that replaces everything between `{!isMoreMenuOpen ? (` and the end of that ternary.
    }
}
