const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

c = c.replace(
  '        </div>      \n      <AnimatePresence>',
  '        </div>\n        )}\n      </div>\n      <AnimatePresence>'
);

fs.writeFileSync('src/components/MessagesPage.tsx', c);
console.log("Patched input area end");
