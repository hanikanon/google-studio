const fs = require('fs');

let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

// Add states for the new menu items
const newStates = `
  const [showProfile, setShowProfile] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [isPinned, setIsPinned] = useState(chat.isPinned || false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [chatWallpaper, setChatWallpaper] = useState<string | null>(null);
  const [chatTheme, setChatTheme] = useState<'light' | 'dark' | 'auto'>('light');
`;

content = content.replace("  const [audioError, setAudioError] = useState<string | null>(null);", "  const [audioError, setAudioError] = useState<string | null>(null);" + newStates);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
