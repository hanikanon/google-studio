const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

const correctHeader = `      {/* Header */}
      <div className={cn("backdrop-blur-xl pt-2 px-1 flex flex-col z-50 shrink-0 shadow-[0_1px_3px_rgba(0,0,0,0.05)] relative", chatTheme === 'dark' ? 'bg-gray-900/95 border-b border-gray-800' : 'bg-white/95')}>
        <div className="flex items-center justify-between h-[52px]">
          {showSearch ? (
            <div className="flex items-center w-full px-2 gap-2">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="p-2 -ml-2 text-gray-500 hover:bg-gray-100 rounded-full">
                <ArrowLeft className="w-[22px] h-[22px]" />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search messages..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[15px]"
              />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-1">
                <button 
                  onClick={onBack}
                  className="p-2 -ml-1 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90"
                >
                  <ArrowLeft className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                <div className="flex items-center gap-2.5 cursor-pointer pl-1 active:opacity-70 transition-opacity">
                  <div className="relative">
                    <div className={cn(
                      "w-[38px] h-[38px] rounded-full overflow-hidden flex items-center justify-center relative",
                      chat.avatarType === 'icon' ? chat.avatarColor : "bg-gray-200"
                    )}>
                      {chat.avatarType === 'image' ? (
                        <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover pointer-events-none select-none" draggable={false} />
                      ) : null}
                    </div>
                    {chat.isOnline && (
                      <div className="absolute bottom-0 right-0 w-[12px] h-[12px] bg-[#22c55e] border-[2px] border-white rounded-full z-20"></div>
                    )}
                  </div>
                  <div className="flex flex-col justify-center">
                    <span className="font-semibold text-[16px] text-gray-900 leading-tight tracking-tight flex items-center gap-1">
                      {chat.name}
                      {isMuted && <BellOff className="w-3.5 h-3.5 text-gray-400" />}
                      {isPinned && <Pin className="w-3.5 h-3.5 text-gray-400 fill-gray-400" />}
                    </span>
                    <span className="text-[13px] text-gray-500 leading-tight mt-[2px] tracking-wide">
                      {isTyping ? <span className="text-blue-500 font-medium">typing...</span> : (chat.isOnline ? <span className="text-blue-500">online</span> : 'last seen recently')}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center pr-1 gap-1">
                <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90">
                  <Video className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90">
                  <Phone className="w-[22px] h-[22px]" strokeWidth={2.5} />
                </button>
                <div className="relative">
                  <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors active:scale-90">
                    <MoreVertical className="w-[22px] h-[22px]" strokeWidth={2.5} />
                  </button>
                  <AnimatePresence>
                    {isMenuOpen && (
                      <>
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          onClick={() => setIsMenuOpen(false)}
                          className="fixed inset-0 z-40"
                        />
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          transition={{ duration: 0.1 }}
                          className="absolute right-0 top-10 w-48 bg-white/95 backdrop-blur-xl rounded-[16px] shadow-lg py-1.5 z-50 border border-gray-100/80"
                        >
                          {[
                            { icon: <User className="w-[16px] h-[16px]" />, label: 'View Profile', action: () => { setShowProfile(true); setIsMenuOpen(false); } },
                            { icon: <Search className="w-[16px] h-[16px]" />, label: 'Search', action: () => { setShowSearch(true); setIsMenuOpen(false); } },
                            { icon: isMuted ? <BellOff className="w-[16px] h-[16px]" /> : <Bell className="w-[16px] h-[16px]" />, label: isMuted ? 'Unmute' : 'Mute', action: () => { setIsMuted(!isMuted); setIsMenuOpen(false); } },
                            { icon: <Pin className="w-[16px] h-[16px]" />, label: isPinned ? 'Unpin' : 'Pin Conversation', action: () => { setIsPinned(!isPinned); setIsMenuOpen(false); } },
                            { divider: true },
                            { icon: <Image className="w-[16px] h-[16px]" />, label: 'Media', action: () => { setShowGallery(true); setIsMenuOpen(false); } },
                            { icon: <FileText className="w-[16px] h-[16px]" />, label: 'Shared Files', action: () => { setShowDocuments(true); setIsMenuOpen(false); } },
                            { divider: true },
                            { icon: <Image className="w-[16px] h-[16px]" />, label: 'Wallpaper', action: () => { setChatWallpaper('bg-blue-50'); setIsMenuOpen(false); } },
                            { icon: <Palette className="w-[16px] h-[16px]" />, label: 'Theme', action: () => { setChatTheme(chatTheme === 'light' ? 'dark' : 'light'); setIsMenuOpen(false); } },
                            { divider: true },
                            { icon: <Trash2 className="w-[16px] h-[16px] text-red-500" />, label: 'Clear Chat', textRed: true, action: () => { setShowClearConfirm(true); setIsMenuOpen(false); } },
                            { icon: <XCircle className="w-[16px] h-[16px] text-red-500" />, label: isBlocked ? 'Unblock User' : 'Block User', textRed: true, action: () => { if(isBlocked) { setIsBlocked(false); setIsMenuOpen(false); } else { setShowBlockConfirm(true); setIsMenuOpen(false); } } },
                          ].map((item: any, i) => 
                            item.divider ? (
                              <div key={i} className="h-px bg-gray-100/80 my-1 mx-2" />
                            ) : (
                              <button key={i} onClick={item.action} className="w-full flex items-center px-3 py-2 hover:bg-gray-50 transition-colors gap-3">
                                <div className={item.textRed ? "text-red-500" : "text-gray-500"}>{item.icon}</div>
                                <span className={cn("text-[14px] font-medium", item.textRed ? "text-red-500" : "text-gray-800")}>{item.label}</span>
                              </button>
                            )
                          )}
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      <div`;

const startIndex = c.indexOf('{/* Header */}');
const endMarker = '</div>\n        </div>\n      </div>\n      <div';
const endIndex = c.indexOf(endMarker, startIndex) + endMarker.length - 10; 
// 10 is length of "\n      <div"

if (startIndex !== -1 && endIndex !== -1) {
  c = c.substring(0, startIndex) + correctHeader.substring(0, correctHeader.length - 10) + c.substring(endIndex);
  fs.writeFileSync('src/components/MessagesPage.tsx', c);
  console.log("Patched header area successfully.");
} else {
  console.log("Not found.", startIndex, endIndex);
}
