const fs = require('fs');
let content = fs.readFileSync('src/components/FAB.tsx', 'utf-8');

content = content.replace("import { cn } from '../utils';", "import { cn } from '../utils';\nimport { usePopupManager } from '../usePopupManager';");

content = content.replace(
  "export const FAB = ({ isVisible = true }: { isVisible?: boolean }) => {",
  "export const FAB = ({ isVisible = true }: { isVisible?: boolean }) => {\n  usePopupManager(isOpen, () => setIsOpen(false));\n  usePopupManager(isLongPressed, () => setIsLongPressed(false));"
);

// We should also modify the "Group" to "Settings"
content = content.replace(
  "import { MessageSquare, Users, User, FileText, Plus, X, Camera, Lock, Megaphone } from 'lucide-react';",
  "import { MessageSquare, Users, User, FileText, Plus, X, Camera, Lock, Megaphone, Settings } from 'lucide-react';"
);

content = content.replace(
  "{ icon: <Users className=\"w-[18px] h-[18px]\" />, label: 'Group', color: 'text-gray-600', bg: 'bg-gray-100', activeBg: 'active:bg-gray-200' },",
  "{ icon: <Settings className=\"w-[18px] h-[18px]\" />, label: 'Settings', color: 'text-gray-600', bg: 'bg-gray-100', activeBg: 'active:bg-gray-200' },"
);

// Fix backdrop for FAB
content = content.replace(
  '<motion.div\n            initial={{ opacity: 0 }}\n            animate={{ opacity: 1 }}\n            exit={{ opacity: 0 }}\n            className="fixed inset-0 bg-white/20 backdrop-blur-[1px] z-30 touch-none"\n            onClick={handleCloseAll}\n          />',
  '<motion.div\n            initial={{ opacity: 0 }}\n            animate={{ opacity: 1 }}\n            exit={{ opacity: 0 }}\n            className="fixed inset-0 w-screen h-screen bg-white/20 backdrop-blur-[1px] z-30 cursor-default touch-none"\n            onClick={handleCloseAll}\n          />'
);

fs.writeFileSync('src/components/FAB.tsx', content);
