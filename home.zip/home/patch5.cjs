const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

c = c.replace(
  "{ icon: <Image className=\"w-[16px] h-[16px]\" />, label: 'Media', action: () => { setShowProfile(true); setIsMenuOpen(false); } },",
  "{ icon: <Image className=\"w-[16px] h-[16px]\" />, label: 'Media', action: () => { setShowGallery(true); setIsMenuOpen(false); } },"
);

c = c.replace(
  "{ icon: <FileText className=\"w-[16px] h-[16px]\" />, label: 'Shared Files', action: () => { setShowProfile(true); setIsMenuOpen(false); } },",
  "{ icon: <FileText className=\"w-[16px] h-[16px]\" />, label: 'Shared Files', action: () => { setShowDocuments(true); setIsMenuOpen(false); } },"
);

fs.writeFileSync('src/components/MessagesPage.tsx', c);
