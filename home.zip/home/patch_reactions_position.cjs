const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf8');

c = c.replace(
`                className={cn(
                  "flex relative", 
                  isMe ? "justify-end" : "justify-start", `,
`                className={cn(
                  "flex flex-col relative w-full", 
                  isMe ? "items-end" : "items-start", `
);

// We need to move the reactions block out of the inner motion.div
// First, extract the reactions block
const reactionsBlockMatch = c.match(/ *\{msg\.reactions && msg\.reactions\.length > 0 && \([\s\S]*?<\/AnimatePresence>\s*<\/div>\s*\)\}/);

if (reactionsBlockMatch) {
  const reactionsBlock = reactionsBlockMatch[0];
  c = c.replace(reactionsBlock, ''); // remove from current position

  // Find the closing tag of the inner motion.div.
  // The context menu is right after the inner motion.div ends, but wait, the context menu is inside the outer motion.div.
  // Wait, let's look at the structure.
  
  const insertTarget = `{/* Context Menu Tooltip */}`;
  // Context Menu Tooltip is currently INSIDE the outer motion.div, AFTER the inner motion.div ends! Wait, let me verify.
}

console.log(!!reactionsBlockMatch);
