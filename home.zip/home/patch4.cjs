const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

c = c.replace(
  'const [showProfile, setShowProfile] = useState(false);',
  `const [showProfile, setShowProfile] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [showDocuments, setShowDocuments] = useState(false);`
);

fs.writeFileSync('src/components/MessagesPage.tsx', c);
