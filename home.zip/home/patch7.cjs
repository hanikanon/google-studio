const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

const blockedInput = `
      {/* Input Area */}
      <div className={cn("shrink-0 relative z-20 pb-[env(safe-area-inset-bottom)] border-t", chatTheme === 'dark' ? 'bg-gray-900 border-gray-800' : 'bg-[#f0f2f5] border-black/5')}>
        {isBlocked ? (
          <div className="flex flex-col items-center justify-center p-4">
            <p className={cn("text-sm mb-3", chatTheme === 'dark' ? 'text-gray-400' : 'text-gray-500')}>You blocked this user.</p>
            <button onClick={() => setIsBlocked(false)} className="px-6 py-2 rounded-full font-medium text-white bg-blue-500 hover:bg-blue-600 transition-colors">
              Unblock User
            </button>
          </div>
        ) : (
`;

c = c.replace(
  /\{\/\* Input Area \*\/\}\s*<div className="bg-\[#f0f2f5\] shrink-0 relative z-20 pb-\[env\(safe-area-inset-bottom\)\] border-t border-black\/5">/,
  blockedInput.trim()
);

// find where the Input Area ends.
// Let's count divs. Or maybe just insert closing brace before </motion.div> which ends the page.
