const fs = require('fs');

let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

// Import AudioMessage
content = content.replace("import { usePopupManager } from '../usePopupManager';", "import { usePopupManager } from '../usePopupManager';\nimport { AudioMessage } from './AudioMessage';");

const oldAudioMsg = `                  {/* Audio Message */}
                  {msg.type === 'audio' && (
                    <div className="px-2 py-2 w-[240px]">
                      <div className="flex items-center gap-3">
                        <button className={cn("w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 text-white shadow-sm transition-transform active:scale-90", isMe ? "bg-green-500" : "bg-blue-500")}>
                          <Play className="w-[20px] h-[20px] ml-0.5 fill-current" />
                        </button>
                        <div className="flex-1 flex flex-col justify-center gap-1">
                          {/* Fake waveform */}
                          <div className="flex items-center gap-[2px] h-[22px]">
                            {[2, 4, 3, 5, 8, 4, 2, 5, 7, 4, 3, 2, 4, 6, 8, 5, 3, 2, 4, 3].map((h, i) => (
                              <div key={i} className={cn("w-[3px] rounded-full", isMe ? "bg-green-600/30" : "bg-blue-500/30")} style={{ height: \`\${h * 10}%\` }}></div>
                            ))}
                          </div>
                          <div className="flex items-center justify-between">
                            <span className={cn("text-[12px] font-medium tracking-wide", isMe ? "text-green-700" : "text-gray-500")}>{msg.audioDuration}</span>
                            <div className={cn("flex items-center gap-[3px]", isMe ? "text-green-600" : "text-gray-400")}>
                              <span className="text-[11px] font-medium leading-none">{msg.time}</span>
                              {isMe && (msg.isRead ? <CheckCheck className="w-[16px] h-[16px] text-[#4FA953]" strokeWidth={2.5} /> : <Check className="w-[15px] h-[15px] text-[#53b259]" strokeWidth={2.5} />)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}`;

const newAudioMsg = `                  {/* Audio Message */}
                  {msg.type === 'audio' && (
                    <AudioMessage msg={msg as any} isMe={isMe} />
                  )}`;

if (content.includes(oldAudioMsg)) {
  content = content.replace(oldAudioMsg, newAudioMsg);
} else {
    console.log("Could not find the old audio message block perfectly");
    // let's try a regex or substring replace
}
fs.writeFileSync('src/components/MessagesPage.tsx', content);

