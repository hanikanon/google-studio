const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

const regex = /\{showSearch \? \([\s\S]*?\) : \(/;

c = c.replace(regex, (match) => {
  return match.replace(') : (', '} {!showSearch && (');
});

c = c.replace(/<\/div>\s*<\/div>\s*<\/div>\s*\)\s*\{!showSearch && \(/, '</div></div></div>} {!showSearch && (');

fs.writeFileSync('src/components/MessagesPage.tsx', c);
