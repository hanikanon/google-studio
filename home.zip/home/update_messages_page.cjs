const fs = require('fs');

let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

// Add import
content = content.replace("import { cn } from '../utils';", "import { cn } from '../utils';\nimport { usePopupManager } from '../usePopupManager';");

// Add hook calls inside MessagesPage
const hookCalls = `
  usePopupManager(isMenuOpen, () => setIsMenuOpen(false));
  usePopupManager(isAttachmentOpen, () => setIsAttachmentOpen(false));
  usePopupManager(!!selectedMessageId, () => { setSelectedMessageId(null); setIsMoreMenuOpen(false); });
  usePopupManager(showMediaPicker, () => setShowMediaPicker(false));
`;

content = content.replace(
  "const textareaRef = useRef<HTMLTextAreaElement>(null);",
  "const textareaRef = useRef<HTMLTextAreaElement>(null);\n" + hookCalls
);

// Fix overlays
content = content.replace(
  '<div className="fixed inset-0 z-40" onClick={() => setIsMenuOpen(false)}></div>',
  '<div className="fixed inset-0 w-screen h-screen z-40 cursor-default touch-none" onClick={() => setIsMenuOpen(false)}></div>'
);

content = content.replace(
  '<motion.div \n                    initial={{ opacity: 0 }}\n                    animate={{ opacity: 1 }}\n                    exit={{ opacity: 0 }}\n                    className="fixed inset-0 z-40 bg-black/30 backdrop-blur-[2px]" \n                    onClick={() => { setSelectedMessageId(null); setIsMoreMenuOpen(false); }}\n                  />',
  '<motion.div \n                    initial={{ opacity: 0 }}\n                    animate={{ opacity: 1 }}\n                    exit={{ opacity: 0 }}\n                    className="fixed inset-0 w-screen h-screen z-40 bg-black/30 backdrop-blur-[2px] cursor-default touch-none" \n                    onClick={() => { setSelectedMessageId(null); setIsMoreMenuOpen(false); }}\n                  />'
);

content = content.replace(
  '<motion.div \n              initial={{ opacity: 0 }}\n              animate={{ opacity: 1 }}\n              exit={{ opacity: 0 }}\n              onClick={() => setIsAttachmentOpen(false)}\n              className="fixed inset-0 z-20"\n            />',
  '<motion.div \n              initial={{ opacity: 0 }}\n              animate={{ opacity: 1 }}\n              exit={{ opacity: 0 }}\n              onClick={() => setIsAttachmentOpen(false)}\n              className="fixed inset-0 w-screen h-screen z-20 cursor-default touch-none"\n            />'
);

fs.writeFileSync('src/components/MessagesPage.tsx', content);
