const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

c = c.replace(
  '<span className="font-semibold text-[16px] text-gray-900 leading-tight tracking-tight">\n                  {chat.name}\n                </span>',
  `<span className="font-semibold text-[16px] text-gray-900 leading-tight tracking-tight flex items-center gap-1">
                  {chat.name}
                  {isMuted && <BellOff className="w-3.5 h-3.5 text-gray-400" />}
                  {isPinned && <Pin className="w-3.5 h-3.5 text-gray-400 fill-gray-400" />}
                </span>`
);

fs.writeFileSync('src/components/MessagesPage.tsx', c);
console.log("Patched header name icons");
