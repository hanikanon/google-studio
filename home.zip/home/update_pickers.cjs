const fs = require('fs');

let content = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

// 1. Remove showMediaPicker state and popup manager
content = content.replace("  const [showMediaPicker, setShowMediaPicker] = useState(false);\n", "");
content = content.replace("  usePopupManager(showMediaPicker, () => setShowMediaPicker(false));\n", "");

// 2. Add refs for file inputs
const refsToInsert = `  const fileInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      let msgType: any = 'file';
      
      if (file.type.startsWith('image/')) msgType = 'image';
      else if (file.type.startsWith('audio/')) msgType = 'audio';
      
      const newMsg: Message = {
        id: Date.now().toString(),
        senderId: 'me',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isRead: false,
        type: msgType,
      };

      if (msgType === 'image') {
        newMsg.imageUrl = url;
      } else {
        newMsg.fileName = file.name;
        if (file.size > 1024 * 1024) {
          newMsg.fileSize = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
        } else {
          newMsg.fileSize = (file.size / 1024).toFixed(0) + ' KB';
        }
        newMsg.fileType = file.type || 'Unknown';
      }

      setMessages(prev => [...prev, newMsg]);
    }
    e.target.value = '';
    setIsAttachmentOpen(false);
  };

  const handleLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        const newMsg: Message = {
          id: Date.now().toString(),
          senderId: 'me',
          text: \`📍 Location: \${latitude.toFixed(4)}, \${longitude.toFixed(4)}\\nhttps://maps.google.com/?q=\${latitude},\${longitude}\`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isRead: false,
          type: 'text'
        };
        setMessages(prev => [...prev, newMsg]);
        setIsAttachmentOpen(false);
      }, (error) => {
        alert("Unable to get location: " + error.message);
      });
    } else {
      alert("Geolocation is not supported by your browser");
    }
  };

  const handleContact = async () => {
    if ('contacts' in navigator && 'ContactsManager' in window) {
      try {
        const props = ['name', 'tel'];
        const contacts = await (navigator as any).contacts.select(props, { multiple: false });
        if (contacts.length > 0) {
          const contact = contacts[0];
          const name = contact.name?.[0] || 'Unknown';
          const phone = contact.tel?.[0] || 'No number';
          const newMsg: Message = {
            id: Date.now().toString(),
            senderId: 'me',
            text: \`👤 Contact: \${name}\\n📞 \${phone}\`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isRead: false,
            type: 'text'
          };
          setMessages(prev => [...prev, newMsg]);
          setIsAttachmentOpen(false);
        }
      } catch (ex: any) {
        alert("Unable to access contacts: " + ex.message);
      }
    } else {
      alert("Contact picker is not supported by your browser/device.");
    }
  };
`;

content = content.replace("  const [selectedMedia, setSelectedMedia] = useState<string[]>([]);\n", "  const [selectedMedia, setSelectedMedia] = useState<string[]>([]);\n\n" + refsToInsert);

// 3. Update the mapping in the attachment popup
const oldMapStart = `                {[
                  { icon: <Camera className="w-[28px] h-[28px] text-blue-500" strokeWidth={1.5} />, label: 'Camera', bg: 'bg-blue-50' },
                  { icon: <ImageIcon className="w-[28px] h-[28px] text-purple-500" strokeWidth={1.5} />, label: 'Gallery', bg: 'bg-purple-50' },
                  { icon: <FileText className="w-[28px] h-[28px] text-indigo-500" strokeWidth={1.5} />, label: 'Document', bg: 'bg-indigo-50' },
                  { icon: <Video className="w-[28px] h-[28px] text-rose-500" strokeWidth={1.5} />, label: 'Video', bg: 'bg-rose-50' },
                  { icon: <Music className="w-[28px] h-[28px] text-amber-500" strokeWidth={1.5} />, label: 'Audio', bg: 'bg-amber-50' },
                  { icon: <MapPin className="w-[28px] h-[28px] text-green-500" strokeWidth={1.5} />, label: 'Location', bg: 'bg-green-50' },
                  { icon: <User className="w-[28px] h-[28px] text-cyan-500" strokeWidth={1.5} />, label: 'Contact', bg: 'bg-cyan-50' },
                  { icon: <Folder className="w-[28px] h-[28px] text-slate-500" strokeWidth={1.5} />, label: 'Files', bg: 'bg-slate-50' },
                ].map((item, i) => (
                  <motion.button 
                    key={i}
                    initial={{ opacity: 0, y: 20, scale: 0.8 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ delay: i * 0.04, type: 'spring', stiffness: 400, damping: 25 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.92 }}
                    className="flex flex-col items-center gap-2 cursor-pointer group outline-none"
                    onClick={() => {
                      if (item.label === 'Gallery') {
                        setShowMediaPicker(true);
                      }
                      setIsAttachmentOpen(false);
                    }}
                  >`;

const newMapStart = `                {[
                  { icon: <Camera className="w-[28px] h-[28px] text-blue-500" strokeWidth={1.5} />, label: 'Camera', bg: 'bg-blue-50', action: () => cameraInputRef.current?.click() },
                  { icon: <ImageIcon className="w-[28px] h-[28px] text-purple-500" strokeWidth={1.5} />, label: 'Gallery', bg: 'bg-purple-50', action: () => galleryInputRef.current?.click() },
                  { icon: <FileText className="w-[28px] h-[28px] text-indigo-500" strokeWidth={1.5} />, label: 'Document', bg: 'bg-indigo-50', action: () => documentInputRef.current?.click() },
                  { icon: <Video className="w-[28px] h-[28px] text-rose-500" strokeWidth={1.5} />, label: 'Video', bg: 'bg-rose-50', action: () => videoInputRef.current?.click() },
                  { icon: <Music className="w-[28px] h-[28px] text-amber-500" strokeWidth={1.5} />, label: 'Audio', bg: 'bg-amber-50', action: () => audioInputRef.current?.click() },
                  { icon: <MapPin className="w-[28px] h-[28px] text-green-500" strokeWidth={1.5} />, label: 'Location', bg: 'bg-green-50', action: handleLocation },
                  { icon: <User className="w-[28px] h-[28px] text-cyan-500" strokeWidth={1.5} />, label: 'Contact', bg: 'bg-cyan-50', action: handleContact },
                  { icon: <Folder className="w-[28px] h-[28px] text-slate-500" strokeWidth={1.5} />, label: 'Files', bg: 'bg-slate-50', action: () => fileInputRef.current?.click() },
                ].map((item, i) => (
                  <motion.button 
                    key={i}
                    initial={{ opacity: 0, y: 20, scale: 0.8 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ delay: i * 0.04, type: 'spring', stiffness: 400, damping: 25 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.92 }}
                    className="flex flex-col items-center gap-2 cursor-pointer group outline-none"
                    onClick={item.action}
                  >`;

content = content.replace(oldMapStart, newMapStart);

// 4. Remove the fake media picker UI
const fakeMediaStart = `<AnimatePresence>\n        {showMediaPicker && (`;
const idx = content.indexOf(fakeMediaStart);
if (idx !== -1) {
  // Finding the end of the fake media picker
  const endIdx = content.indexOf('</AnimatePresence>', idx + 1);
  if (endIdx !== -1) {
    const toRemove = content.substring(idx, endIdx + '</AnimatePresence>'.length);
    content = content.replace(toRemove, '');
  }
}

// 5. Add hidden inputs to the end of the component before </motion.div>
const inputs = `
      {/* Hidden File Inputs */}
      <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} />
      <input type="file" ref={galleryInputRef} accept="image/*,video/*" className="hidden" onChange={handleFileChange} />
      <input type="file" ref={cameraInputRef} accept="image/*,video/*" capture="environment" className="hidden" onChange={handleFileChange} />
      <input type="file" ref={videoInputRef} accept="video/*" className="hidden" onChange={handleFileChange} />
      <input type="file" ref={audioInputRef} accept="audio/*" className="hidden" onChange={handleFileChange} />
      <input type="file" ref={documentInputRef} accept=".pdf,.doc,.docx,.txt,.rtf,.xls,.xlsx" className="hidden" onChange={handleFileChange} />
    `;

content = content.replace('    </motion.div>\n  );\n};', inputs + '    </motion.div>\n  );\n};');

fs.writeFileSync('src/components/MessagesPage.tsx', content);

