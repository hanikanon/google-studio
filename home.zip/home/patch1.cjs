const fs = require('fs');
let c = fs.readFileSync('src/components/MessagesPage.tsx', 'utf-8');

// 1. Update background class
c = c.replace(
  'className="absolute inset-0 bg-[#e4e2de] z-50 flex flex-col w-full h-full"',
  'className={cn("absolute inset-0 z-50 flex flex-col w-full h-full", chatTheme === "dark" ? "bg-gray-900" : (chatWallpaper || "bg-[#e4e2de]"))}'
);

// 2. Add header search
const headerSearchRepl = `
      {/* Header */}
      <div className={cn("backdrop-blur-xl pt-2 px-1 flex flex-col z-50 shrink-0 shadow-[0_1px_3px_rgba(0,0,0,0.05)] relative", chatTheme === 'dark' ? 'bg-gray-900/95 border-b border-gray-800' : 'bg-white/95')}>
        <div className="flex items-center justify-between h-[52px]">
          {showSearch ? (
            <div className="flex items-center w-full px-2 gap-2">
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="p-2 -ml-2 text-gray-500 hover:bg-gray-100 rounded-full">
                <ArrowLeft className="w-[22px] h-[22px]" />
              </button>
              <input 
                autoFocus
                type="text" 
                placeholder="Search messages..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[15px]"
              />
            </div>
          ) : (
          <div className="flex items-center gap-1">
            <button 
`;
c = c.replace(
  /\{\/\* Header \*\/\}\s*<div className="bg-white\/95 backdrop-blur-xl pt-2 px-1 flex flex-col z-50 shrink-0 shadow-\[0_1px_3px_rgba\(0,0,0,0\.05\)\] relative">\s*<div className="flex items-center justify-between h-\[52px\]">\s*<div className="flex items-center gap-1">\s*<button/,
  headerSearchRepl.trim()
);

// 3. Fix the unclosed search condition in header
const headerSearchCloseRepl = `
                  {isTyping ? <span className="text-blue-500 font-medium">typing...</span> : (chat.isOnline ? <span className="text-blue-500">online</span> : 'last seen recently')}
                </span>
              </div>
            </div>
          </div>
          )}
          {!showSearch && (
          <div className="flex items-center gap-0.5 pr-1">
`;

c = c.replace(
  /\{isTyping \? <span className="text-blue-500 font-medium">typing\.\.\.<\/span> : \(chat\.isOnline \? <span className="text-blue-500">online<\/span> : 'last seen recently'\)\}\s*<\/span>\s*<\/div>\s*<\/div>\s*<\/div>\s*<div className="flex items-center gap-0\.5 pr-1">/,
  headerSearchCloseRepl.trim()
);

fs.writeFileSync('src/components/MessagesPage.tsx', c);
console.log("Patched header");
