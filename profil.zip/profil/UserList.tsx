import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, ChevronDown, CheckCircle, UserPlus, MoreHorizontal, ArrowLeft, Loader2, RefreshCw, X, ShieldAlert, Flag, VolumeX } from 'lucide-react';

export interface User {
  id: string;
  displayName: string;
  username: string;
  avatarUrl: string;
  isVerified: boolean;
  isOnline: boolean;
  isFollowing: boolean;
  isRequested?: boolean;
  category: 'mutual' | 'suggested' | 'none';
  isBlocked?: boolean;
  isMuted?: boolean;
  isRemoved?: boolean;
}

const getPersistedUsersState = () => {
  try {
    const data = localStorage.getItem('nightowl-users-state');
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
};

const savePersistedUsersState = (state: any) => {
  localStorage.setItem('nightowl-users-state', JSON.stringify(state));
};

const generateMockUsers = (type: 'followers' | 'following'): User[] => {
  const users: User[] = [
    { id: '1', displayName: 'Elena Rostova', username: 'elena_r', avatarUrl: 'https://i.pravatar.cc/150?u=1', isVerified: true, isOnline: true, isFollowing: type === 'following', category: 'none' },
    { id: '2', displayName: 'Marcus Chen', username: 'marcus.c', avatarUrl: 'https://i.pravatar.cc/150?u=2', isVerified: false, isOnline: false, isFollowing: true, category: 'mutual' },
    { id: '3', displayName: 'Sarah Jenkins', username: 'sarahj', avatarUrl: 'https://i.pravatar.cc/150?u=3', isVerified: false, isOnline: true, isFollowing: true, category: 'mutual' },
    { id: '4', displayName: 'Alex Rivera', username: 'arivera99', avatarUrl: 'https://i.pravatar.cc/150?u=4', isVerified: true, isOnline: false, isFollowing: false, category: 'suggested' },
    { id: '5', displayName: 'David Kim', username: 'dkim_dev', avatarUrl: 'https://i.pravatar.cc/150?u=5', isVerified: false, isOnline: true, isFollowing: false, category: 'none' },
    { id: '6', displayName: 'Emma Watson', username: 'emma.w', avatarUrl: 'https://i.pravatar.cc/150?u=6', isVerified: true, isOnline: false, isFollowing: true, category: 'mutual' },
    { id: '7', displayName: 'Lucas Silva', username: 'lucass', avatarUrl: 'https://i.pravatar.cc/150?u=7', isVerified: false, isOnline: false, isFollowing: type === 'following', category: 'none' },
    { id: '8', displayName: 'Tech Insider', username: 'techinsider', avatarUrl: 'https://i.pravatar.cc/150?u=8', isVerified: true, isOnline: true, isFollowing: true, category: 'mutual' },
    { id: '9', displayName: 'Design UI', username: 'design_ui', avatarUrl: 'https://i.pravatar.cc/150?u=9', isVerified: false, isOnline: false, isFollowing: type === 'following', category: 'suggested' },
    { id: '10', displayName: 'Crypto King', username: 'cryptoking', avatarUrl: 'https://i.pravatar.cc/150?u=10', isVerified: true, isOnline: true, isFollowing: false, category: 'none' },
  ];
  
  const persisted = getPersistedUsersState();
  const mergedUsers = users.map(u => ({
    ...u,
    isFollowing: persisted[u.id]?.isFollowing ?? u.isFollowing,
    isBlocked: persisted[u.id]?.isBlocked ?? false,
    isMuted: persisted[u.id]?.isMuted ?? false,
    isRemoved: persisted[u.id]?.isRemoved ?? false,
  }));

  if (type === 'followers') {
    return mergedUsers.slice(0, 8);
  }
  return mergedUsers.slice(1, 9);
};

interface UserListProps {
  type: 'followers' | 'following';
  onBack: () => void;
  onUserClick: (user: User) => void;
  onUpdateFollowers: (delta: number) => void;
  onUpdateFollowing: (delta: number) => void;
}

export const UserList: React.FC<UserListProps> = ({ type, onBack, onUserClick, onUpdateFollowers, onUpdateFollowing }) => {
  const [activeTab, setActiveTab] = useState<'followers' | 'following' | 'mutual'>(type === 'followers' ? 'followers' : 'following');
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'default' | 'alphabetical' | 'recent'>('default');
  const [isSortMenuOpen, setIsSortMenuOpen] = useState(false);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [reportDialogUserId, setReportDialogUserId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{ message: string, onUndo?: () => void } | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{ type: 'block' | 'remove', userId: string } | null>(null);
  const [reportReason, setReportReason] = useState<string | null>(null);

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  useEffect(() => {
    setLoading(true);
    // Simulate network request
    const timer = setTimeout(() => {
      if (activeTab === 'mutual') {
        const followers = generateMockUsers('followers');
        const following = generateMockUsers('following');
        // Mock mutual logic
        setUsers([...followers, ...following].filter((v,i,a)=>a.findIndex(t=>(t.id === v.id))===i).filter(u => u.category === 'mutual' || u.isFollowing));
      } else {
        setUsers(generateMockUsers(activeTab));
      }
      setLoading(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [activeTab]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    setRefreshing(false);
  };

  const updateUserState = (userId: string, updates: Partial<User>) => {
    setUsers(prev => {
      const next = prev.map(u => u.id === userId ? { ...u, ...updates } : u);
      const persisted = getPersistedUsersState();
      persisted[userId] = { ...(persisted[userId] || {}), ...updates };
      savePersistedUsersState(persisted);
      return next;
    });
  };

  const handleFollowToggle = (userId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const user = users.find(u => u.id === userId);
    if (user) {
      updateUserState(userId, { isFollowing: !user.isFollowing });
      onUpdateFollowing(user.isFollowing ? -1 : 1);
    }
  };

  const handleBlock = (userId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const user = users.find(u => u.id === userId);
    if (!user) return;
    
    if (user.isBlocked) {
      // Unblock directly
      updateUserState(userId, { isBlocked: false });
      setToastMessage({ message: `Unblocked ${user.username}` });
    } else {
      // Show confirmation dialog
      setConfirmDialog({ type: 'block', userId });
    }
    setOpenMenuId(null);
  };

  const confirmBlock = () => {
    if (!confirmDialog || confirmDialog.type !== 'block') return;
    const userId = confirmDialog.userId;
    const user = users.find(u => u.id === userId);
    if (user) {
      const wasFollowing = user.isFollowing;
      updateUserState(userId, { isBlocked: true });
      if (wasFollowing) {
        onUpdateFollowing(-1);
        updateUserState(userId, { isFollowing: false });
      }

      setToastMessage({
        message: `User blocked successfully.`,
        onUndo: () => {
          updateUserState(userId, { isBlocked: false });
          if (wasFollowing) {
            updateUserState(userId, { isFollowing: true });
            onUpdateFollowing(1);
          }
          setToastMessage(null);
        }
      });
    }
    setConfirmDialog(null);
  };

  const handleRemoveFollower = (userId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDialog({ type: 'remove', userId });
    setOpenMenuId(null);
  };

  const confirmRemoveFollower = () => {
    if (!confirmDialog || confirmDialog.type !== 'remove') return;
    const userId = confirmDialog.userId;
    updateUserState(userId, { isRemoved: true });
    onUpdateFollowers(-1);
    setToastMessage({ message: `Follower removed.` });
    setConfirmDialog(null);
  };

  const handleCopyLink = (username: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(`https://nightowl.app/${username}`);
    setOpenMenuId(null);
  };

  const handleShare = async (username: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.share({
        title: `${username} on nightowl`,
        url: `https://nightowl.app/${username}`
      });
    } catch (err) {}
    setOpenMenuId(null);
  };

  const filteredUsers = users
    .filter(u => !u.isRemoved)
    .filter(u => 
      (u.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
       u.displayName.toLowerCase().includes(searchQuery.toLowerCase()))
    )
    .sort((a, b) => {
      if (sortOrder === 'alphabetical') return a.displayName.localeCompare(b.displayName);
      if (sortOrder === 'recent') return parseInt(b.id) - parseInt(a.id);
      return 0; // default
    });

  const highlightText = (text: string, highlight: string) => {
    if (!highlight.trim()) return text;
    const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
    return (
      <>
        {parts.map((part, i) => 
          part.toLowerCase() === highlight.toLowerCase() ? 
            <span key={i} className="text-blue-500 bg-blue-500/10 rounded-sm px-[1px]">{part}</span> : part
        )}
      </>
    );
  };

  return (
    <motion.div
      key={`${type}-view`}
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      transition={{ type: "spring", stiffness: 400, damping: 30 }}
      className="fixed inset-0 bg-white z-50 flex flex-col overflow-hidden"
    >
      {/* Header */}
      <div className="sticky top-0 bg-white/90 backdrop-blur-md z-20 flex items-center justify-between px-4 py-3 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <motion.button 
            whileTap={{ scale: 0.9 }}
            onClick={onBack}
            className="p-1 -ml-1 rounded-full hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#111827]" />
          </motion.button>
          <div className="flex flex-col">
            <h2 className="text-[17px] font-bold text-[#111827] leading-tight">nightowl</h2>
            <span className="text-gray-500 text-[12px] capitalize font-medium">{activeTab}</span>
          </div>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleRefresh}
          className="p-2 rounded-full hover:bg-gray-100 transition-colors"
        >
          <RefreshCw className={`w-5 h-5 text-[#111827] ${refreshing ? 'animate-spin' : ''}`} />
        </motion.button>
      </div>

      {/* Search and Filters */}
      <div className="px-4 py-3 flex flex-col gap-3 bg-white z-10 shrink-0">
        <div className="relative">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Search" 
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-[#f3f4f6] text-[#111827] rounded-xl py-2.5 pl-10 pr-10 text-[15px] outline-none placeholder:text-gray-500 font-medium transition-colors focus:bg-gray-200/60"
          />
          <AnimatePresence>
            {searchQuery && (
              <motion.button
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 bg-gray-200 hover:bg-gray-300 text-gray-500 rounded-full transition-colors"
              >
                <X className="w-3 h-3" strokeWidth={3} />
              </motion.button>
            )}
          </AnimatePresence>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex gap-2 overflow-x-auto [&::-webkit-scrollbar]:hidden">
            <button 
              onClick={() => setActiveTab('followers')}
              className={`px-4 py-1.5 rounded-full text-[13px] font-semibold transition-colors whitespace-nowrap ${activeTab === 'followers' ? 'bg-[#111827] text-white' : 'bg-gray-100 text-[#111827]'}`}
            >
              Followers
            </button>
            <button 
              onClick={() => setActiveTab('following')}
              className={`px-4 py-1.5 rounded-full text-[13px] font-semibold transition-colors whitespace-nowrap ${activeTab === 'following' ? 'bg-[#111827] text-white' : 'bg-gray-100 text-[#111827]'}`}
            >
              Following
            </button>
            <button 
              onClick={() => setActiveTab('mutual')}
              className={`px-4 py-1.5 rounded-full text-[13px] font-semibold transition-colors whitespace-nowrap ${activeTab === 'mutual' ? 'bg-[#111827] text-white' : 'bg-gray-100 text-[#111827]'}`}
            >
              Mutual
            </button>
          </div>

          <div className="relative shrink-0 ml-2">
            <button 
              onClick={() => setIsSortMenuOpen(!isSortMenuOpen)}
              className="flex items-center gap-1 text-[13px] font-semibold text-[#111827] p-1.5"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
            
            <AnimatePresence>
              {isSortMenuOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setIsSortMenuOpen(false)} />
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    className="absolute right-0 top-full mt-1 w-40 bg-white border border-gray-100 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] py-1.5 z-40 overflow-hidden"
                  >
                    {[
                      { id: 'default', label: 'Default' },
                      { id: 'recent', label: 'Date followed' },
                      { id: 'alphabetical', label: 'Alphabetical' }
                    ].map(option => (
                      <button 
                        key={option.id}
                        onClick={() => { setSortOrder(option.id as any); setIsSortMenuOpen(false); }}
                        className={`w-full text-left px-4 py-2.5 text-[14px] transition-colors flex items-center justify-between ${sortOrder === option.id ? 'font-bold text-[#111827]' : 'font-medium text-gray-500 hover:bg-gray-50'}`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* List content */}
      <div className="flex-1 overflow-y-auto relative overscroll-y-contain">
        {/* Pull to refresh indicator */}
        <AnimatePresence>
          {refreshing && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 50, opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="flex justify-center items-center py-2 text-gray-400"
            >
              <RefreshCw className="w-5 h-5 animate-spin" />
            </motion.div>
          )}
        </AnimatePresence>

        {loading ? (
          <div className="flex flex-col gap-4 p-4">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="flex items-center gap-3 w-full animate-pulse">
                <div className="w-[52px] h-[52px] rounded-full bg-gray-200 shrink-0" />
                <div className="flex flex-col gap-2 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-24" />
                  <div className="h-3 bg-gray-200 rounded w-32" />
                </div>
                <div className="w-24 h-8 bg-gray-200 rounded-lg shrink-0" />
              </div>
            ))}
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4 pb-20">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
              <UserPlus className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-[20px] font-bold text-[#111827] mb-2">Users not found</h3>
            <p className="text-[15px] text-gray-500 max-w-[250px]">We couldn't find anyone matching your search criteria.</p>
          </div>
        ) : (
          <div className="flex flex-col pb-6">
            {filteredUsers.map(user => (
              <motion.div 
                key={user.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                onClick={() => onUserClick(user)}
                className="flex items-center gap-3 px-4 py-2 hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <div className="relative shrink-0">
                  <img src={user.avatarUrl} alt={user.username} className="w-[52px] h-[52px] rounded-full object-cover border border-gray-100" />
                  {user.isOnline && (
                    <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white" />
                  )}
                </div>
                
                <div className="flex flex-col flex-1 min-w-0 justify-center">
                  <div className="flex items-center gap-1">
                    <span className="font-bold text-[14.5px] text-[#111827] truncate leading-tight">
                      {highlightText(user.username, searchQuery)}
                    </span>
                    {user.isVerified && <CheckCircle className="w-3.5 h-3.5 text-blue-500 fill-blue-500/20 shrink-0" />}
                  </div>
                  <span className="text-[13.5px] text-gray-500 truncate leading-tight mt-0.5">
                    {highlightText(user.displayName, searchQuery)}
                  </span>
                </div>

                <div className="shrink-0 flex items-center gap-2 relative">
                  <AnimatePresence mode="wait">
                    {user.isBlocked ? (
                      <motion.button 
                        key="unblock"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        transition={{ duration: 0.15 }}
                        whileTap={{ scale: 0.92 }}
                        onClick={(e) => handleBlock(user.id, e)}
                        className="px-5 py-1.5 rounded-lg text-[14px] font-semibold transition-colors bg-red-100 text-red-600 hover:bg-red-200"
                      >
                        Unblock
                      </motion.button>
                    ) : (
                      <motion.button 
                        key="follow"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        transition={{ duration: 0.15 }}
                        whileTap={{ scale: 0.92 }}
                        onClick={(e) => handleFollowToggle(user.id, e)}
                        className={`px-5 py-1.5 rounded-lg text-[14px] font-semibold transition-colors ${user.isFollowing ? 'bg-gray-100 text-[#111827] hover:bg-gray-200' : 'bg-[#3b82f6] text-white hover:bg-blue-600'}`}
                      >
                        {user.isFollowing ? 'Following' : 'Follow'}
                      </motion.button>
                    )}
                  </AnimatePresence>
                  <motion.button 
                    whileTap={{ scale: 0.92 }}
                    onClick={(e) => { e.stopPropagation(); setOpenMenuId(openMenuId === user.id ? null : user.id); }}
                    className="p-1.5 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors relative"
                  >
                    <MoreHorizontal className="w-5 h-5" />
                  </motion.button>
                  
                  <AnimatePresence>
                    {openMenuId === user.id && (
                      <>
                        <div className="fixed inset-0 z-30" onClick={(e) => { e.stopPropagation(); setOpenMenuId(null); }} />
                        <motion.div
                          initial={{ opacity: 0, scale: 0.95, y: -10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95, y: -10 }}
                          className="absolute right-0 top-full mt-2 w-48 bg-white border border-gray-100 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] py-1.5 z-40 overflow-hidden"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {activeTab === 'followers' && (
                            <button 
                              onClick={(e) => handleRemoveFollower(user.id, e)}
                              className="w-full text-left px-4 py-2.5 text-[14px] font-medium text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2"
                            >
                              <X className="w-4 h-4" /> Remove Follower
                            </button>
                          )}
                          {activeTab === 'following' && user.isFollowing && (
                            <button 
                              onClick={(e) => handleFollowToggle(user.id, e)}
                              className="w-full text-left px-4 py-2.5 text-[14px] font-medium text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2"
                            >
                              <UserPlus className="w-4 h-4" /> Unfollow
                            </button>
                          )}
                          <button 
                            onClick={(e) => handleBlock(user.id, e)}
                            className="w-full text-left px-4 py-2.5 text-[14px] font-medium text-[#111827] hover:bg-gray-50 transition-colors flex items-center gap-2"
                          >
                            <ShieldAlert className="w-4 h-4" /> {user.isBlocked ? 'Unblock' : 'Block'}
                          </button>
                          {!user.isBlocked && (
                            <button 
                              onClick={(e) => { e.stopPropagation(); setReportDialogUserId(user.id); setReportReason(null); setOpenMenuId(null); }}
                              className="w-full text-left px-4 py-2.5 text-[14px] font-medium text-[#111827] hover:bg-gray-50 transition-colors flex items-center gap-2"
                            >
                              <Flag className="w-4 h-4" /> Report
                            </button>
                          )}
                          <div className="h-[1px] bg-gray-100 my-1 mx-2" />
                          <button 
                            onClick={(e) => handleCopyLink(user.username, e)}
                            className="w-full text-left px-4 py-2.5 text-[14px] font-medium text-[#111827] hover:bg-gray-50 transition-colors flex items-center gap-2"
                          >
                            Copy Profile Link
                          </button>
                          <button 
                            onClick={(e) => handleShare(user.username, e)}
                            className="w-full text-left px-4 py-2.5 text-[14px] font-medium text-[#111827] hover:bg-gray-50 transition-colors flex items-center gap-2"
                          >
                            Share Profile
                          </button>
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Report Dialog */}
      <AnimatePresence>
        {reportDialogUserId && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setReportDialogUserId(null)}
              className="fixed inset-0 bg-black/50 z-[60]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed left-4 right-4 top-1/2 -translate-y-1/2 bg-white rounded-2xl z-[70] overflow-hidden shadow-xl"
            >
              <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                <h3 className="font-bold text-[17px] text-[#111827]">Report @{users.find(u => u.id === reportDialogUserId)?.username}</h3>
                <button onClick={() => setReportDialogUserId(null)} className="p-1 text-gray-400 hover:bg-gray-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4 flex flex-col">
                <p className="text-[14px] text-gray-500 mb-4">Please select a reason for reporting. Your report will be reviewed by our moderation team.</p>
                <div className="flex flex-col gap-2 mb-6 max-h-[300px] overflow-y-auto">
                  {[
                    "Spam",
                    "Harassment or bullying",
                    "Inappropriate content",
                    "Hate speech or symbols",
                    "False information",
                    "Scam or fraud"
                  ].map((reason) => (
                    <button
                      key={reason}
                      onClick={() => setReportReason(reason)}
                      className={`w-full text-left px-4 py-3 text-[15px] font-medium rounded-xl transition-colors border ${reportReason === reason ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 text-[#111827] hover:bg-gray-50'}`}
                    >
                      <div className="flex items-center justify-between">
                        {reason}
                        {reportReason === reason && <CheckCircle className="w-5 h-5 text-blue-500" />}
                      </div>
                    </button>
                  ))}
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setReportDialogUserId(null)}
                    className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-[#111827] font-semibold rounded-full transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => {
                      if (!reportReason) return;
                      setReportDialogUserId(null);
                      setToastMessage({ message: 'Report submitted.' });
                    }}
                    disabled={!reportReason}
                    className="flex-1 py-3 bg-red-500 hover:bg-red-600 disabled:bg-red-300 disabled:cursor-not-allowed text-white font-semibold rounded-full transition-colors"
                  >
                    Report
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Confirmation Dialogs */}
      <AnimatePresence>
        {confirmDialog && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setConfirmDialog(null)}
              className="fixed inset-0 bg-black/50 z-[60]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed left-6 right-6 top-1/2 -translate-y-1/2 bg-white rounded-2xl z-[70] overflow-hidden shadow-xl"
            >
              <div className="p-6 flex flex-col items-center text-center">
                <h3 className="font-bold text-[20px] text-[#111827] mb-2">
                  {confirmDialog.type === 'block' ? `Block @${users.find(u => u.id === confirmDialog.userId)?.username}?` : 'Remove follower?'}
                </h3>
                <p className="text-[15px] text-gray-500 mb-6">
                  {confirmDialog.type === 'block' 
                    ? "They won't be able to find your profile, follow you, or message you." 
                    : "This person will no longer follow you. They won't be notified."}
                </p>
                <div className="flex flex-col gap-3 w-full">
                  <button 
                    onClick={confirmDialog.type === 'block' ? confirmBlock : confirmRemoveFollower}
                    className={`w-full py-3.5 text-[16px] font-bold text-white rounded-xl transition-colors ${confirmDialog.type === 'block' ? 'bg-red-500 hover:bg-red-600' : 'bg-[#111827] hover:bg-gray-800'}`}
                  >
                    {confirmDialog.type === 'block' ? 'Block' : 'Remove'}
                  </button>
                  <button 
                    onClick={() => setConfirmDialog(null)}
                    className="w-full py-3.5 text-[16px] font-bold text-[#111827] bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Action Toast with Undo */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-[#111827] text-white px-5 py-3 rounded-full shadow-lg z-[80] flex items-center justify-between gap-4 font-medium text-[14px] min-w-[200px]"
          >
            <span>{toastMessage.message}</span>
            {toastMessage.onUndo && (
              <button 
                onClick={toastMessage.onUndo}
                className="text-[#3b82f6] hover:text-blue-400 font-bold ml-2 transition-colors active:scale-95"
              >
                Undo
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
