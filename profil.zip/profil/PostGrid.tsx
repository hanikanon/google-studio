import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_POSTS } from '../lib/mockPosts';
import { PostViewer } from './PostViewer';
import { Grid, TrendingUp, Search } from 'lucide-react';
import { LongPressContextMenu } from './LongPressContextMenu';
import { useRef, useCallback } from 'react';

export const PostGrid = () => {
  
  const [activePostIndex, setActivePostIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPosts = MOCK_POSTS.filter(post => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return post.content.toLowerCase().includes(q) || post.timestamp.toLowerCase().includes(q);
  });


  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [savedPosts, setSavedPosts] = useState<Set<string>>(new Set());

  const toggleLike = (postId: string) => {
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) newSet.delete(postId);
      else newSet.add(postId);
      return newSet;
    });
  };

  const toggleSave = (postId: string) => {
    setSavedPosts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(postId)) newSet.delete(postId);
      else newSet.add(postId);
      return newSet;
    });
  };

  
  const handlePostClick = (e: React.MouseEvent, index: number) => {
    // If context menu is open, don't open the post
    if (contextMenuPost || longPressTriggered.current) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    setActivePostIndex(index);
  };
  const [contextMenuPost, setContextMenuPost] = useState<{ post: any, position: { x: number, y: number } } | null>(null);
  const timerRef = useRef<any>(null);
  const longPressTriggered = useRef(false);
  
  const handleTouchStart = (e: any, post: any) => {
    e.persist?.();
    const touch = e.touches ? e.touches[0] : e;
    longPressTriggered.current = false;
    const x = touch.clientX;
    const y = touch.clientY;
    
    timerRef.current = setTimeout(() => {
      longPressTriggered.current = true;
      setContextMenuPost({ post, position: { x, y } });
    }, 500); // 500ms long press
  };

  const handleTouchEnd = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
  };

  const handleContextMenu = (e: any, post: any) => {
    e.preventDefault();
    setContextMenuPost({ post, position: { x: e.clientX, y: e.clientY } });
  };


  return (
    <>
      <div className="max-w-4xl mx-auto px-4 mb-4 mt-2">
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none transition-colors duration-200">
            <Search className="h-5 w-5 text-gray-400 group-focus-within:text-blue-500" />
          </div>
          <input
            type="text"
            className="block w-full pl-11 pr-4 py-2.5 border border-gray-200 rounded-2xl leading-5 bg-gray-50/50 placeholder-gray-400 focus:outline-none focus:bg-white focus:ring-4 focus:ring-blue-500/15 focus:border-blue-500 sm:text-[15px] transition-all duration-200 shadow-sm"
            placeholder="Search posts by keyword or date..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      {filteredPosts.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-20 px-4 text-center max-w-md mx-auto"
        >
          <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
            <Search className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-[17px] font-bold text-[#111827] mb-2">No posts found</h3>
          <p className="text-[15px] text-gray-500 mb-6">
            We couldn't find any posts matching "{searchQuery}". Try using different keywords or clear your search.
          </p>
          <button
            onClick={() => setSearchQuery('')}
            className="px-6 py-2.5 bg-gray-100 hover:bg-gray-200 active:bg-gray-300 text-[#111827] font-semibold rounded-full transition-colors"
          >
            Clear search
          </button>
        </motion.div>
      ) : (
        <motion.div 
          key="posts-grid"

        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.2 }}
        className="grid grid-cols-3 gap-1 px-1 md:gap-2 md:px-4 max-w-4xl mx-auto"
      >
        {filteredPosts.map((post, index) => (
          <motion.div
            key={post.id}
            onClick={(e) => handlePostClick(e, index)}
            onContextMenu={(e) => handleContextMenu(e, post)}
            onTouchStart={(e) => handleTouchStart(e, post)}
            onTouchEnd={handleTouchEnd}
            onTouchMove={handleTouchEnd}
            onMouseDown={(e) => handleTouchStart(e, post)}
            onMouseUp={handleTouchEnd}
            onMouseLeave={handleTouchEnd}
            whileTap={{ scale: 0.98 }}
            className="aspect-square relative cursor-pointer overflow-hidden bg-gray-100 group rounded-md md:rounded-lg"
          >
            {post.image ? (
              <motion.img
                layoutId={`post-image-${post.id}`}
                src={post.image}
                alt="Post thumbnail"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                loading="lazy"
              />
            ) : post.linkPreview ? (
              <motion.div 
                layoutId={`post-image-${post.id}`}
                className="w-full h-full bg-gradient-to-br from-blue-50 to-blue-100 flex flex-col items-center justify-center p-2 text-center"
              >
                <TrendingUp className="w-8 h-8 text-blue-500 mb-2" />
                <span className="text-[11px] font-bold text-[#111827]">{post.linkPreview.symbol}</span>
              </motion.div>
            ) : (
              <motion.div 
                layoutId={`post-image-${post.id}`}
                className="w-full h-full bg-gradient-to-br from-gray-50 to-gray-200 flex items-center justify-center p-3"
              >
                <p className="text-[10px] sm:text-[12px] font-medium text-gray-500 text-center line-clamp-4">
                  {post.content}
                </p>
              </motion.div>
            )}
            
            {/* Hover overlay */}
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity hidden md:flex" />
          </motion.div>
        ))}
      </motion.div>
      )}

      <AnimatePresence>
        {activePostIndex !== null && (
          <PostViewer
            posts={filteredPosts}
            initialIndex={activePostIndex}
            onClose={() => setActivePostIndex(null)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {contextMenuPost && (

          <LongPressContextMenu 
            post={contextMenuPost.post}
            position={contextMenuPost.position}
            isLiked={likedPosts.has(contextMenuPost.post.id)}
            isSaved={savedPosts.has(contextMenuPost.post.id)}
            onClose={() => setContextMenuPost(null)}
            onAction={(action, message) => {
              setContextMenuPost(null);
              if (action === 'Liked' || action === 'Unliked') {
                toggleLike(contextMenuPost.post.id);
              } else if (action === 'Saved' || action === 'Unsaved') {
                toggleSave(contextMenuPost.post.id);
              }
              // Dispatch custom event to App.tsx to show toast
              window.dispatchEvent(new CustomEvent('showToast', { detail: { message } }));
              if (action === 'Report') {
                window.dispatchEvent(new CustomEvent('openReportDialog'));
              }
            }}
          />

        )}
      </AnimatePresence>
    </>
  );
};
