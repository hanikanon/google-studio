with open('src/App.tsx', 'r') as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if "const [liked1" in line:
        continue
    if "const [likes1" in line:
        continue
    if "const [liked2" in line:
        continue
    if "const [likes2" in line:
        continue
    if "const toggleLike1 = () => {" in line:
        skip = True
    if skip and "};" in line and "setLikes1" not in lines[i-1] and "setLikes2" not in lines[i-1]:
        pass # end of something else?
    
    if skip:
        if "  };" in line and ("setLikes1" in lines[i-1] or "setLikes2" in lines[i-1]):
            skip = False
        continue

    new_lines.append(line)

with open('src/App.tsx', 'w') as f:
    f.writelines(new_lines)
