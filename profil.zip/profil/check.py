with open('src/App.tsx', 'r') as f:
    text = f.read()

c = 0
for ch in text:
    if ch == '{': c += 1
    elif ch == '}': c -= 1
print("Curly:", c)

p = 0
for ch in text:
    if ch == '(': p += 1
    elif ch == ')': p -= 1
print("Parens:", p)

a = 0
for ch in text:
    if ch == '<': a += 1
    elif ch == '>': a -= 1
print("Angle:", a)
