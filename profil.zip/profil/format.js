const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');
// Just want to find out where the bracket mismatch happens by removing JSX.
// Or we can just use prettier to find it.
