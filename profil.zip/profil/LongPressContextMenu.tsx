import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PostData } from '../lib/mockPosts';
import { Heart, MessageCircle, Repeat, Share2, Bookmark, Link as LinkIcon, Flag } from 'lucide-react';

export const LongPressContextMenu = ({ 
  post, 
  position, 
  onClose, onAction, isLiked, isSaved 
}: { 
  post: PostData, 
  position: { x: number, y: number }, 
  onClose: () => void,
  isLiked?: boolean,
  isSaved?: boolean,
  onAction: (action: string, message: string) => void
}) => {

  const handleLike = () => {
    onAction(isLiked ? 'Unliked' : 'Liked', isLiked ? 'Post removed from likes.' : 'Post added to your likes.');
  };
  const handleComment = () => {
    onAction('Comment', 'Opening comments...');
  };
  const handleRepost = () => {
    onAction('Reposted', 'Post has been reposted to your followers.');
  };
  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Nightowl Post', text: post.content, url: 'https://cryptvora.com/post/' + post.id });
      } else {
        onAction('Share', 'Share sheet opened.');
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        /* ignore */
      }
    } finally {
      onClose();
    }
  };
  const handleSave = () => {
    onAction(isSaved ? 'Unsaved' : 'Saved', isSaved ? 'Post removed from bookmarks.' : 'Post saved to your bookmarks.');
  };
  const handleCopyLink = () => {
    navigator.clipboard.writeText('https://cryptvora.com/post/' + post.id);
    onAction('Link Copied', 'Post URL copied to clipboard.');
  };
  const handleReport = () => {
    onAction('Report', 'Opening report flow...');
  };

  const menuRef = useRef<HTMLDivElement>(null);
  const [adjustedPos, setAdjustedPos] = useState(position);
  
  useEffect(() => {
    if (menuRef.current) {
      const rect = menuRef.current.getBoundingClientRect();
      let newX = position.x;
      let newY = position.y;
      
      // Keep inside screen
      if (newX + rect.width > window.innerWidth - 16) {
        newX = window.innerWidth - rect.width - 16;
      }
      if (newY + rect.height > window.innerHeight - 16) {
        newY = window.innerHeight - rect.height - 16;
      }
      
      // Ensure minimum spacing from top/left
      newX = Math.max(16, newX);
      newY = Math.max(16, newY);
      
      setAdjustedPos({ x: newX, y: newY });
    }
    
    if (navigator.vibrate) {
      navigator.vibrate(50);
    }
  }, [position]);

  return (
    <div 
      className="fixed inset-0 z-[100]"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/40 backdrop-blur-md" />
      
      {/* Enlarged post preview */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 max-w-md pointer-events-none"
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
      >
        {post.image ? (
          <img src={post.image} alt="" className="w-full h-auto rounded-xl shadow-2xl" />
        ) : (
          <div className="w-full aspect-square bg-white rounded-xl shadow-2xl p-4 flex items-center justify-center text-center">
            {post.content}
          </div>
        )}
      </motion.div>

      {/* Floating Menu */}
      <motion.div
        ref={menuRef}
        initial={{ opacity: 0, scale: 0.8, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: 10 }}
        style={{ left: adjustedPos.x, top: adjustedPos.y }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        className="absolute bg-white/90 backdrop-blur-xl rounded-2xl shadow-2xl overflow-hidden min-w-[220px] flex flex-col p-1 z-10 origin-top-left"
        onClick={(e) => e.stopPropagation()}
      >
        <MenuButton icon={<Heart className={`w-5 h-5 ${isLiked ? "fill-red-500 text-red-500" : ""}`} />} label={isLiked ? "Unlike" : "Like"} onClick={handleLike} />
        <MenuButton icon={<MessageCircle className="w-5 h-5" />} label="Comment" onClick={handleComment} />
        <MenuButton icon={<Repeat className="w-5 h-5" />} label="Repost" onClick={handleRepost} />
        <MenuButton icon={<Share2 className="w-5 h-5" />} label="Share" onClick={handleShare} />
        <MenuButton icon={<Bookmark className={`w-5 h-5 ${isSaved ? "fill-black text-black" : ""}`} />} label={isSaved ? "Remove from Saved" : "Save"} onClick={handleSave} />
        <MenuButton icon={<LinkIcon className="w-5 h-5" />} label="Copy Link" onClick={handleCopyLink} />
        <div className="h-px bg-gray-200/50 my-1 mx-2" />
        <MenuButton icon={<Flag className="w-5 h-5 text-red-500" />} label="Report" className="text-red-500" onClick={handleReport} />
      </motion.div>
    </div>
  );
};

const MenuButton = ({ icon, label, className = "text-gray-800", onClick }: any) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 hover:bg-black/5 active:bg-black/10 rounded-xl transition-colors font-medium text-[15px] ${className}`}
  >
    {icon}
    {label}
  </button>
);
