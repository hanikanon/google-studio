with open('src/App.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    "import { UserList } from './components/UserList';",
    "import { UserList } from './components/UserList';\nimport { PostGrid } from './components/PostGrid';"
)

content = content.replace("const PinkBadgeIcon", "export const PinkBadgeIcon")
content = content.replace("const OwlLogo", "export const OwlLogo")
content = content.replace("const ReadMoreText", "export const ReadMoreText")

with open('src/App.tsx', 'w') as f:
    f.write(content)
