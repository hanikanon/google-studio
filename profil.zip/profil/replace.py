import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

# The regex matches from the exact start of the POSTS tab rendering block down to just before VIDEOS.
# Using a precise multiline regex or just string replacement.
start_str = "          {activeTab === 'POSTS' && ("
end_str = "          {activeTab === 'VIDEOS' && ("

start_idx = content.find(start_str)
end_idx = content.find(end_str)

if start_idx != -1 and end_idx != -1:
    new_content = content[:start_idx] + "          {activeTab === 'POSTS' && <PostGrid />}\n\n" + content[end_idx:]
    with open('src/App.tsx', 'w') as f:
        f.write(new_content)
    print("Success")
else:
    print("Failed to find boundaries")
